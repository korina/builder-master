$(window).load(function () {
	$().fluxui.initialise({
		debug : true
	});
	var movie1 = {
		assets : {
			'arrow_previous.png' : {
				type : 'image',
				url : 'jplayer_images/previous.png',
				height : 100,
				width : 40
			},
			'arrow_next.png' : {
				type : 'image',
				url : 'jplayer_images/next.png',
				height : 100,
				width : 40
			},
			jpaudio1 : {
				m4a:"http://www.jplayer.org/audio/m4a/TSP-01-Cro_magnon_man.m4a",
				oga:"http://www.jplayer.org/audio/ogg/TSP-01-Cro_magnon_man.ogg"
			},
			jpvideo1 : {
				m4v: "http://download.blender.org/peach/bigbuckbunny_movies/big_buck_bunny_480p_surround-fix.avi",
				ogv: "http://mirrorblender.top-ix.org/peach/bigbuckbunny_movies/big_buck_bunny_480p_stereo.ogg"
			},
			jpaudiolist1 : [
		{
			title:"Cro Magnon Man",
			artist:"Lee Sylvester",
			mp3:"http://www.jplayer.org/audio/mp3/TSP-01-Cro_magnon_man.mp3",
			oga:"http://www.jplayer.org/audio/ogg/TSP-01-Cro_magnon_man.ogg",
			poster: "http://www.jplayer.org/audio/poster/The_Stark_Palace_640x360.png"
		},
		{
			title:"Your Face",
			artist:"The Stark Palace",
			mp3:"http://www.jplayer.org/audio/mp3/TSP-05-Your_face.mp3",
			oga:"http://www.jplayer.org/audio/ogg/TSP-05-Your_face.ogg",
			poster: "http://www.jplayer.org/audio/poster/The_Stark_Palace_640x360.png"
		},
		{
			title:"Hidden",
			artist:"Miaow",
			mp3:"http://www.jplayer.org/audio/mp3/Miaow-02-Hidden.mp3",
			oga:"http://www.jplayer.org/audio/ogg/Miaow-02-Hidden.ogg",
			poster: "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
		},
		{
			title:"Tempered Song",
			artist:"Miaow",
			mp3:"http://www.jplayer.org/audio/mp3/Miaow-01-Tempered-song.mp3",
			oga:"http://www.jplayer.org/audio/ogg/Miaow-01-Tempered-song.ogg",
			poster: "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
		},
		{
			title:"Lentement",
			artist:"Miaow",
			mp3:"http://www.jplayer.org/audio/mp3/Miaow-03-Lentement.mp3",
			oga:"http://www.jplayer.org/audio/ogg/Miaow-03-Lentement.ogg",
			poster: "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
		}
			],
			'play.png' : {
				type : 'image',
				url : 'jplayer_images/play.png',
				height : '28',
				width : '28'
			},
			'pause.png' : {
				type : 'image',
				url : 'jplayer_images/pause.png',
				height : '28',
				width : '28'
			},
			'stop.png' : {
				type : 'image',
				url : 'jplayer_images/stop.png',
				height : '28',
				width : '28'
			},
			'shuffle.png' : {
				type : 'image',
				url : 'jplayer_images/shuffle.png',
				height : '20',
				width : '28'
			},
			'film.png' : {
				type : 'image',
				url : 'jplayer_images/film.png',
				height : '23',
				width : '17'
			},
			'full_screen.png' : {
				type : 'image',
				url : 'jplayer_images/full_screen.png',
				height : '28',
				width : '28'
			},
			'loop.png' : {
				type : 'image',
				url : 'jplayer_images/loop.png',
				height : '26',
				width : '30'
			},
			'unloop.png' : {
				type : 'image',
				url : 'jplayer_images/unloop.png',
				height : '26',
				width : '30'
			},
			'mute.png' : {
				type : 'image',
				url : 'jplayer_images/mute.png',
				height : '28',
				width : '28'
			},
			'unmute.png' : {
				type : 'image',
				url : 'jplayer_images/unmute.png',
				height : '28',
				width : '28'
			}
		},
		library : {},
		movie : {
			states : {
				_default : {
					props : {
						'overflow-y' : 'hidden',
						'overflow-x' : 'hidden',
						top : 0,
						left : 0,
						height : 600,
						width : 800,
						'border-radius' : 40,
						fill : {
							type : 'solid',
							colors : [
								{ rgb : '#343434' }
							]
						}
					},
					frames : {
						keys : ['_default', 'frame_1', 'frame_2', 'frame_3'],
						hash : {
							frame_1 : {},
							_default : {},
							frame_2 : {},
							frame_3 : {}
						}
					},
					children : {
						keys : ['test', 'next', 'previous', 'audio-player-simple', 'video-player-simple', 'audio-player-list'],
						hash : {
							'test' : {
								type : 'element',
								states : {
									_default : {
										props : {
											height : 40,
											width : 720,
											fill : {
												type : 'linear',
												colors : [
													{
														rgb : '#bbbbbb',
														opacity : 0.1
													},
													{
														rgb : '#ffffff'
													}
												]
											},
											'border-radius' : 19
										}
									}
								}
							},
							'next' : {
								type : 'button',
								states : {
									frame_1 : {},
									_default : {
										props : {
											'overflow-y' : 'hidden',
											'overflow-x' : 'hidden',
											top : 250,
											left : 760,
											height : 100,
											width : 40
										},
										behaviour : {
											click : {
												action : 'gotoNextState'
											}
										},
										frames : {
											keys : ['_default', '_over', '_down', '_selected'],
											hash : {
												_over : {},
												_default : {},
												_down : {
													transition : {
														duration : 0,
														easing : 'linearTween',
														after : 'stop'
													}
												},
												_selected : {}
											}
										},
										children : {
											keys : ['child_1'],
											hash : {
												child_1 : {
													type : 'image',
													states : {
														_over : {
															props : {
																opacity : 1
															}
														},
														_default : {
															src : 'arrow_next.png',
															props : {
																opacity : .5,
																top : 0,
																height : 100,
																width : 40,
																left : 0
															}
														},
														_down : {
															props : {
																opacity : 1,
																top : 0,
																left : 5
															}
														}
													}
												}
											}
										}
									},
									frame_2 : {},
									frame_3 : {
										props : {
											left : 800
										}
									}
								}
							},
							'previous' : {
								type : 'button',
								states : {
									frame_1 : {
										props : {
											top : 250,
											left : 0
										}
									},
									_default : {
										props : {
											'overflow-y' : 'hidden',
											'overflow-x' : 'hidden',
											top : 250,
											height : 100,
											width : 40,
											left : -40
										},
										behaviour : {
											click : {
												action : 'gotoPrevState'
											}
										},
										frames : {
											keys : ['_default', '_over', '_down', '_selected'],
											hash : {
												_over : {},
												_default : {},
												_down : {},
												_selected : {}
											}
										},
										children : {
											keys : ['child_1'],
											hash : {
												child_1 : {
													type : 'image',
													states : {
														_over : {
															props : {
																opacity : 1
															}
														},
														_default : {
															src : 'arrow_previous.png',
															props : {
																opacity : .5,
																top : 0,
																height : 100,
																width : 40,
																left : 0
															}
														},
														_down : {
															props : {
																opacity : 1,
																top : 0,
																left : -5
															}
														}
													}
												}
											}
										}
									},
									frame_2 : {
										props : {
											left : 0
										}
									},
									frame_3 : {
										props : {
											left : 0
										}
									}
								}
							},
							'audio-player-simple' : {
								type : 'element',
								states : {
									frame_1 : {
										props : {
											top : 280,
											left : -800
										}
									},
									_default : {
										props : {
											top : 280,
											height : 40,
											width : 720,
											left : 40,
											'border-radius' : 19
										},
										attr : {
											id : 'jp_container_1',
											class : 'jp-audio',
										},
										children : {
											keys : ['controls'],
											hash : {
												'controls' : {
													type : 'element',
													states : {
														_default : {
															props : {
																height : 40,
																width : 720,
																fill : {
																	type : 'linear',
																	colors : [
																		{
																			rgb : '#bbbbbb',
																			opacity : 0.1
																		},
																		{
																			rgb : '#ffffff'
																		}
																	]
																},
																'border-radius' : 19
															},
															attr : {
																class : 'jp-type-single'
															},
															children : {



																keys : ['player-audio1', 'stop-audio1', 'pause-audio1', 'play-audio1', 'progress-audio1', 'loop-audio1', 'unloop-audio1', 'mute-audio1', 'unmute-audio1', 'volume-audio1'],
																hash : {
																	'player-audio1' : {
																		type : 'element',
																		states : {
																			_default : {
																				attr : {
																					id : 'jquery_jplayer_1',
																					class : 'jp-player'
																				}
																			}
																		}
																	},
																	'stop-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'stop.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 6,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-stop'
																				}
																			}
																		}
																	},
																	'pause-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'pause.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-pause'
																				}
																			}
																		}
																	},
																	'play-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'play.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-play'
																				}
																			}
																		}
																	},
																	'progress-audio1' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 76,
																					height : 26,
																					width : 461,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-progress'
																				},
																				children : {
																					keys : ['seek-bar-audio1', 'current-time-audio1', 'duration-audio1'],
																					hash : {
																						'seek-bar-audio1' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										width : 461
																									},
																									attr : {
																										class : 'jp-seek-bar'
																									},
																									children : {
																										keys : ['play-bar-audio1'],
																										hash : {
																											'play-bar-audio1' : {
																												type : 'element',
																												states : {
																													_default : {
																														props : {
																															height : 26,
																															'border-radius' : 14,
																															fill : {
																																type : 'solid',
																																colors : [
																																	{ rgb : '#343434' }
																																]
																															}
																														},
																														attr : {
																															class : 'jp-play-bar'
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						},
																						'current-time-audio1' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left: 10,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-current-time'
																									}
																								}
																							}
																						},
																						'duration-audio1' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left : 424,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-duration'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	},
																	'loop-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'loop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer'
																				},
																				attr : {
																					class : 'jp-repeat'
																				}
																			}
																		}
																	},
																	'unloop-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unloop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-repeat-off'
																				}
																			}
																		}
																	},
																	'mute-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'mute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-mute'
																				}
																			}
																		}
																	},
																	'unmute-audio1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unmute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-unmute'
																				}
																			}
																		}
																	},
																	'volume-audio1' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 612,
																					height : 26,
																					width : 100,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-volume-bar'
																				},
																				children : {
																					keys : ['set-volume-audio1'],
																					hash : {
																						'set-volume-audio1' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										'border-radius' : 14,
																										fill : {
																											type : 'solid',
																											colors : [
																												{ rgb : '#343434' }
																											]
																										}
																									},
																									attr : {
																										class : 'jp-volume-bar-value'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									},
									frame_2 : {
										props : {
											top : 280,
											left : -800
										}
									},
									frame_3 : {
										props : {
											top : 280,
											left : -800
										}
									}
								}
							},
							'video-player-simple' : {
								type : 'element',
								states : {
									frame_1 : {
										props : {
											top : 40,
											left : 40
										}
									},
									_default : {
										props : {
											top : 40,
											height : 520,
											width : 720,
											left : 800,
											'border-radius' : 19,
											fill : {
												type : 'linear',
												colors : [
													{
														rgb : '#ffffff',
														opacity : 0.1
													}
												]
											}
										},
										attr : {
											id : 'jp_container_2',
											class : 'jp-video',
										},
										children : {
											keys : ['player-video1', 'controls-video1'],
											hash : {
												'player-video1' : {
													type : 'element',
													states : {
														_default : {
															attr : {
																id : 'jquery_jplayer_2',
																class : 'jp-player'
															}
														}
													}
												},
												'controls-video1' : {
													type : 'element',
													states : {
														_default : {
															props : {
																top : 480,
																height : 40,
																width : 720,
																fill : {
																	type : 'linear',
																	colors : [
																		{
																			rgb : '#bbbbbb'
																		},
																		{
																			rgb : '#ffffff'
																		}
																	]
																},
																'border-bottom-left-radius' : 19,
																'border-bottom-right-radius' : 19
															},
															children : {
																keys : ['stop-video1', 'pause-video1', 'play-video1', 'progress-video1', 'loop-video1', 'unloop-video1', 'mute-video1', 'unmute-video1', 'volume-video1'],
																hash : {
																	'stop-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'stop.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 6,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-stop'
																				}
																			}
																		}
																	},
																	'pause-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'pause.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-pause'
																				}
																			}
																		}
																	},
																	'play-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'play.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-play'
																				}
																			}
																		}
																	},
																	'progress-video1' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 76,
																					height : 26,
																					width : 461,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-progress'
																				},
																				children : {
																					keys : ['seek-bar-video1', 'current-time-video1', 'duration-video1'],
																					hash : {
																						'seek-bar-video1' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										width : 461
																									},
																									attr : {
																										class : 'jp-seek-bar'
																									},
																									children : {
																										keys : ['play-bar-video1'],
																										hash : {
																											'play-bar-video1' : {
																												type : 'element',
																												states : {
																													_default : {
																														props : {
																															height : 26,
																															'border-radius' : 14,
																															fill : {
																																type : 'solid',
																																colors : [
																																	{ rgb : '#343434' }
																																]
																															}
																														},
																														attr : {
																															class : 'jp-play-bar'
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						},
																						'current-time-video1' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left: 10,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-current-time'
																									}
																								}
																							}
																						},
																						'duration-video1' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left : 424,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-duration'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	},
																	'loop-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'loop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer'
																				},
																				attr : {
																					class : 'jp-repeat'
																				}
																			}
																		}
																	},
																	'unloop-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unloop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-repeat-off'
																				}
																			}
																		}
																	},
																	'mute-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'mute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-mute'
																				}
																			}
																		}
																	},
																	'unmute-video1' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unmute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-unmute'
																				}
																			}
																		}
																	},
																	'volume-video1' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 612,
																					height : 26,
																					width : 100,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-volume-bar'
																				},
																				children : {
																					keys : ['set-volume-video1'],
																					hash : {
																						'set-volume-video1' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										'border-radius' : 14,
																										fill : {
																											type : 'solid',
																											colors : [
																												{ rgb : '#343434' }
																											]
																										}
																									},
																									attr : {
																										class : 'jp-volume-bar-value'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									},
									frame_2 : {
										props : {
											top : 40,
											left : -800
										}
									},
									frame_3 : {
										props : {
											top : 40,
											left : -800
										}
									}
								}
							},
							'audio-player-list' : {
								type : 'element',
								states : {
									frame_1 : {
										props : {
											top : 150,
											left : 800
										}
									},
									_default : {
										props : {
											top : 148,
											height : 304,
											width : 720,
											left : 800,
											fill : {
												type : 'linear',
												colors : [
													{
														rgb : '#ffffff',
														opacity : 0.1
													}
												]
											},
											'border-radius' : 19
										},
										attr : {
											id : 'jp_container_3',
											class : 'jp-audio',
										},
										children : {
											keys : ['playlist-audio2', 'controls-audio2'],
											hash : {
												'playlist-audio2' : {
													type : 'element',
													states : {
														_default : {
															attr : {
																class : 'jp-playlist'
															},
															props : {
																height : 284,
																width : 720,
																overflow : 'auto',
																'border-radius' : 19
															},
															children : {
																keys : ['tracks-audio2'],
																hash : {
																	'tracks-audio2' : {
																		type : 'unorderedList',
																		states : {
																			_default : {
																				props : {
																					left : 20,
																					top : 58,
																					width : 680,
																					'border-radius' : 12,
																				},
																				attr : {
																					class : 'jp-playlist-ul'
																				},
																				children : {
																					keys : ['dummy-track-audio2'],
																					hash : {
																						'dummy-track-audio2' : {
																							type : 'item',
																							states : {
																								_default : {}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												},
												'controls-audio2' : {
													type : 'element',
													states : {
														_default : {
															props : {
																height : 40,
																width : 720,
																fill : {
																	type : 'linear',
																	colors : [
																		{
																			rgb : '#bbbbbb'
																		},
																		{
																			rgb : '#ffffff'
																		}
																	]
																},
																'border-radius' : 19
															},
															children : {
																keys : ['player-audio2', 'stop-audio2', 'pause-audio2', 'play-audio2', 'progress-audio2', 'loop-audio2', 'unloop-audio2', 'mute-audio2', 'unmute-audio2', 'volume-audio2'],
																hash : {
																	'player-audio2' : {
																		type : 'element',
																		states : {
																			_default : {
																				attr : {
																					id : 'jquery_jplayer_3',
																					class : 'jp-player'
																				}
																			}
																		}
																	},
																	'stop-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'stop.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 6,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-stop'
																				}
																			}
																		}
																	},
																	'pause-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'pause.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-pause'
																				}
																			}
																		}
																	},
																	'play-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'play.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 40,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-play'
																				}
																			}
																		}
																	},
																	'progress-audio2' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 76,
																					height : 26,
																					width : 461,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-progress'
																				},
																				children : {
																					keys : ['seek-bar-audio2', 'current-time-audio2', 'duration-audio2'],
																					hash : {
																						'seek-bar-audio2' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										width : 461
																									},
																									attr : {
																										class : 'jp-seek-bar'
																									},
																									children : {
																										keys : ['play-bar-audio2'],
																										hash : {
																											'play-bar-audio2' : {
																												type : 'element',
																												states : {
																													_default : {
																														props : {
																															height : 26,
																															'border-radius' : 14,
																															fill : {
																																type : 'solid',
																																colors : [
																																	{ rgb : '#343434' }
																																]
																															}
																														},
																														attr : {
																															class : 'jp-play-bar'
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						},
																						'current-time-audio2' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left: 10,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-current-time'
																									}
																								}
																							}
																						},
																						'duration-audio2' : {
																							type : 'label',
																							states : {
																								_default : {
																									props : {
																										top : 8,
																										left : 424,
																										'font-size' : 11,
																										'font-weight' : 'bold',
																										'line-height' : 11,
																										color : '#dd00aa'
																									},
																									attr : {
																										class : 'jp-duration'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	},
																	'loop-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'loop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer'
																				},
																				attr : {
																					class : 'jp-repeat'
																				}
																			}
																		}
																	},
																	'unloop-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unloop.png',
																				props : {
																					top : 7,
																					height : 26,
																					width : 30,
																					left : 543,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-repeat-off'
																				}
																			}
																		}
																	},
																	'mute-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'mute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-mute'
																				}
																			}
																		}
																	},
																	'unmute-audio2' : {
																		type : 'image',
																		states : {
																			_default : {
																				src : 'unmute.png',
																				props : {
																					top : 6,
																					height : 28,
																					width : 28,
																					left : 578,
																					'cursor' : 'pointer',
																				},
																				attr : {
																					class : 'jp-unmute'
																				}
																			}
																		}
																	},
																	'volume-audio2' : {
																		type : 'element',
																		states : {
																			_default : {
																				props : {
																					top : 7,
																					left : 612,
																					height : 26,
																					width : 100,
																					'border-radius' : 14,
																					'cursor' : 'pointer',
																					fill : {
																						type : 'solid',
																						colors : [
																							{ rgb : '#egegeg' }
																						]
																					}
																				},
																				attr : {
																					class : 'jp-volume-bar'
																				},
																				children : {
																					keys : ['set-volume-audio2'],
																					hash : {
																						'set-volume-audio2' : {
																							type : 'element',
																							states : {
																								_default : {
																									props : {
																										height : 26,
																										'border-radius' : 14,
																										fill : {
																											type : 'solid',
																											colors : [
																												{ rgb : '#343434' }
																											]
																										}
																									},
																									attr : {
																										class : 'jp-volume-bar-value'
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									},
									frame_2 : {
										props : {
											top : 148,
											left : 40
										}
									},
									frame_3 : {
										props : {
											top : 148,
											left : -800
										}
									}
								}
							},
						}
					}
				}
			}
		}
	};
	$( '#movie-container' ).fluxui(movie1);
	
	// Architypal single audio track player
	$( '#jquery_jplayer_1' ).jPlayer({
		ready: function (event) {
			$(this).jPlayer('setMedia', {
				m4a : movie1.assets.jpaudio1.m4a,
				oga : movie1.assets.jpaudio1.oga
			});
		},
		swfPath : 'js',
		supplied : 'm4a, oga',
		wmode : 'window',
		cssSelectorAncestor : '#jp_container_1'
	});
	// Architypal single video player
	$( '#jquery_jplayer_2' ).jPlayer({
		ready: function (event) {
			$(this).jPlayer('setMedia', {
				ogv : movie1.assets.jpvideo1.ogv,
				m4v : movie1.assets.jpvideo1.m4v
			});
		},
		swfPath : 'js',
		supplied : 'ogv, m4v',
		wmode : 'window',
		size : {
			width : '854px',
			height : '480px'
		},
		cssSelectorAncestor : '#jp_container_2'
	});
	// Architypal audio playlist
	new jPlayerPlaylist({
		jPlayer: "#jquery_jplayer_3",
		cssSelectorAncestor: "#jp_container_3"
	}, movie1.assets.jpaudiolist1, {
		swfPath: "js",
		supplied: "oga, mp3",
		wmode: "window"
	});
	// Full screen video support (can be asigned to any element). Current browsers provide only patchy support.
	$( 'video' ).click( function (){
		this.removeAttribute( 'controls' );
		if (this.requestFullscreen)
			this.requestFullscreen();
		else if (this.mozRequestFullScreen)
			this.mozRequestFullScreen();
		else if (docElm.webkitRequestFullScreen)
			this.webkitRequestFullScreen();
	});
});

