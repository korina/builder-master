( function( $ ) {
	
	$().fluxui.initialise( { debug : true } );

	var propertyFrames = {
		keys: [ 'stage-props', 'element-props', 'image-props', 'label-props' ],
		hash: {
			'stage-props': {
				type: 'element',
				states: {
					_default: {
						props: {
							fill: {
								type: 'linear',
								direction: 'top',
								colors: [
									{
										rgb: '#cccccc',
										opacity: 1,
										pos: 0
									},
									{
										rgb: '#cccccc',
										opacity: 1,
										pos: 0.63
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.635
									},
									{
										rgb: '#cccccc',
										opacity: 1,
										pos: 0.64
									}
								]
							},
							position: 'relative',
							width: 300,
							height: 100,
							overflow: 'hidden'
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [ 'width', 'width-label', 'height', 'height-label', 'stage-color-picker', 'stage-color-label', 'transparent', 'transparent-label', 'id', 'id-label', 'class', 'class-label' ],
							hash: {
								width: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.stage.width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.width'
												}
											}
										}
									}
								},
								'width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'w',
											props: {
												left: 70,
												top: 10,
												width: 20
											}
										}
									}
								},
								height: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.stage.height.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.height'
												}
											}
										}
									}
								},
								'height-label': {
									type: 'label',
									states: {
										_default: {
											text: 'h',
											props: {
												left: 70,
												top: 40,
												width: 20
											}
										}
									}
								},
								'stage-color-picker': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 100,
												top: 8
											},
											attr: {
												allowGradient: true
											},
											bind: {
												color: {
													event: 'events.stage.color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'stage-color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'bgcolor',
											props: {
												left: 130,
												top: 10,
												width: 100
											}
										}
									}
								},
								'transparent': {
									type: 'checkbox',
									states: {
										_default: {
											checked: true,
											props: {
												left: 104,
												top: 40
											},
											bind: {
												text: {
													event: 'events.stage.transparent.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.transparent'
												}
											}
										}
									}
								},
								'transparent-label': {
									type: 'label',
									states: {
										_default: {
											text: 'transparent',
											props: {
												left: 130,
												top: 40
											}
										}
									}
								},
								'id': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 70,
												width: 80
											},
											bind: {
												text: {
													event: 'events.stage.id.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.id'
												}
											}
										}
									}
								},
								'id-label': {
									type: 'label',
									states: {
										_default: {
											text: 'id',
											props: {
												left: 100,
												top: 70,
												width: 20
											}
										}
									}
								},
								'class': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 130,
												top: 70,
												width: 80
											},
											bind: {
												text: {
													event: 'events.stage.class.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.stage.class'
												}
											}
										}
									}
								},
								'class-label': {
									type: 'label',
									states: {
										_default: {
											text: 'class',
											props: {
												left: 220,
												top: 70,
												width: 40
											}
										}
									}
								}
							}
						}
					}
				}
			},
			'element-props': {
				type: 'element',
				states: {
					_default: {
						props: {
							fill: {
								type: 'linear',
								direction: 'top',
								colors: [
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.38
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.385
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.39
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.77
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.775
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.78
									}

								]
							},
							position: 'relative',
							width: 300,
							height: 160
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [ 'x', 'x-label', 'y', 'y-label', 'width', 'width-label', 'height', 'height-label', 'bgcolor', 'bgcolor-label', 'border-width', 'border-width-label', 'border-color', 'border-color-label', 'border-radius', 'border-radius-label', 'id', 'id-label', 'class', 'class-label' ],
							hash: {
								x: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.x.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.x'
												}
											}
										}
									}
								},
								'x-label': {
									type: 'label',
									states: {
										_default: {
											text: 'x',
											props: {
												left: 70,
												top: 10,
												width: 20
											}
										}
									}
								},
								y: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.y.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.y'
												}
											}
										}
									}
								},
								'y-label': {
									type: 'label',
									states: {
										_default: {
											text: 'y',
											props: {
												left: 70,
												top: 40,
												width: 20
											}
										}
									}
								},
								width: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.width'
												}
											}
										}
									}
								},
								'width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'w',
											props: {
												left: 160,
												top: 10,
												width: 20
											}
										}
									}
								},
								height: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.height.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.height'
												}
											}
										}
									}
								},
								'height-label': {
									type: 'label',
									states: {
										_default: {
											text: 'h',
											props: {
												left: 160,
												top: 40,
												width: 20
											}
										}
									}
								},
								'bgcolor': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 190,
												top: 8
											},
											attr: {
												allowGradient: true
											},
											bind: {
												color: {
													event: 'events.element.bgcolor.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.bgcolor'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'bgcolor-label': {
									type: 'label',
									states: {
										_default: {
											text: 'bgcolor',
											props: {
												left: 220,
												top: 10
											}
										}
									}
								},
								'border-color': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 100,
												top: 68
											},
											bind: {
												color: {
													event: 'events.element.border-color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'border-color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border color',
											props: {
												left: 130,
												top: 70
											}
										}
									}
								},
								'border-width': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 70,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.border-width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-width'
												}
											}
										}
									}
								},
								'border-width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border weight',
											props: {
												left: 70,
												top: 70
											}
										}
									}
								},
								'border-color': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 160,
												top: 68
											},
											bind: {
												color: {
													event: 'events.element.border-color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'border-color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border color',
											props: {
												left: 190,
												top: 70
											}
										}
									}
								},
								'border-radius': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 100,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.border-radius.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-radius'
												}
											}
										}
									}
								},
								'border-radius-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border radius',
											props: {
												left: 70,
												top: 100
											}
										}
									}
								},
								'id': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.id.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.id'
												}
											}
										}
									}
								},
								'id-label': {
									type: 'label',
									states: {
										_default: {
											text: 'id',
											props: {
												left: 100,
												top: 130,
												width: 20
											}
										}
									}
								},
								'class': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 130,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.class.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.class'
												}
											}
										}
									}
								},
								'class-label': {
									type: 'label',
									states: {
										_default: {
											text: 'class',
											props: {
												left: 220,
												top: 130,
												width: 40
											}
										}
									}
								}
							}
						}
					}
				}
			},
			'image-props': {
				type: 'element',
				states: {
					_default: {
						props: {
							fill: {
								type: 'linear',
								direction: 'top',
								colors: [
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.38
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.385
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.39
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.77
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.775
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.78
									}

								]
							},
							position: 'relative',
							width: 300,
							height: 160
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [ 'x', 'x-label', 'y', 'y-label', 'width', 'width-label', 'height', 'height-label', 'border-width', 'border-width-label', 'border-color', 'border-color-label', 'border-radius', 'border-radius-label', 'id', 'id-label', 'class', 'class-label' ],
							hash: {
								x: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.x.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.x'
												}
											}
										}
									}
								},
								'x-label': {
									type: 'label',
									states: {
										_default: {
											text: 'x',
											props: {
												left: 70,
												top: 10,
												width: 20
											}
										}
									}
								},
								y: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.y.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.y'
												}
											}
										}
									}
								},
								'y-label': {
									type: 'label',
									states: {
										_default: {
											text: 'y',
											props: {
												left: 70,
												top: 40,
												width: 20
											}
										}
									}
								},
								width: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.width'
												}
											}
										}
									}
								},
								'width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'w',
											props: {
												left: 160,
												top: 10,
												width: 20
											}
										}
									}
								},
								height: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.height.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.height'
												}
											}
										}
									}
								},
								'height-label': {
									type: 'label',
									states: {
										_default: {
											text: 'h',
											props: {
												left: 160,
												top: 40,
												width: 20
											}
										}
									}
								},
								'border-color': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 100,
												top: 68
											},
											bind: {
												color: {
													event: 'events.element.border-color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'border-color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border color',
											props: {
												left: 130,
												top: 70
											}
										}
									}
								},
								'border-width': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 70,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.border-width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-width'
												}
											}
										}
									}
								},
								'border-width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border weight',
											props: {
												left: 70,
												top: 70
											}
										}
									}
								},
								'border-color': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 160,
												top: 68
											},
											bind: {
												color: {
													event: 'events.element.border-color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'border-color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border color',
											props: {
												left: 190,
												top: 70
											}
										}
									}
								},
								'border-radius': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 100,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.border-radius.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.border-radius'
												}
											}
										}
									}
								},
								'border-radius-label': {
									type: 'label',
									states: {
										_default: {
											text: 'border radius',
											props: {
												left: 70,
												top: 100
											}
										}
									}
								},
								'id': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.id.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.id'
												}
											}
										}
									}
								},
								'id-label': {
									type: 'label',
									states: {
										_default: {
											text: 'id',
											props: {
												left: 100,
												top: 130,
												width: 20
											}
										}
									}
								},
								'class': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 130,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.class.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.class'
												}
											}
										}
									}
								},
								'class-label': {
									type: 'label',
									states: {
										_default: {
											text: 'class',
											props: {
												left: 220,
												top: 130,
												width: 40
											}
										}
									}
								}
							}
						}
					}
				}
			},
			'label-props': {
				type: 'element',
				states: {
					_default: {
						props: {
							fill: {
								type: 'linear',
								direction: 'top',
								colors: [
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.38
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.385
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.39
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.77
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.775
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.78
									}

								]
							},
							position: 'relative',
							width: 300,
							height: 400
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [ 'x', 'x-label', 'y', 'y-label', 'width', 'width-label', 'height', 'height-label', 'color', 'color-label', 'border-width', 'border-width-label', 'border-color', 'border-color-label', 'border-radius', 'border-radius-label', 'id', 'id-label', 'class', 'class-label', 'text-content', 'text-content-label', 'typeface', 'typeface-label', 'align', 'align-label', 'decoration', 'decoration-label', 'font-size', 'font-size-label', 'weight', 'weight-label' ],
							hash: {
								x: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.x.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.x'
												}
											}
										}
									}
								},
								'x-label': {
									type: 'label',
									states: {
										_default: {
											text: 'x',
											props: {
												left: 70,
												top: 10,
												width: 20
											}
										}
									}
								},
								y: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.y.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.y'
												}
											}
										}
									}
								},
								'y-label': {
									type: 'label',
									states: {
										_default: {
											text: 'y',
											props: {
												left: 70,
												top: 40,
												width: 20
											}
										}
									}
								},
								width: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 10,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.width.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.width'
												}
											}
										}
									}
								},
								'width-label': {
									type: 'label',
									states: {
										_default: {
											text: 'w',
											props: {
												left: 160,
												top: 10,
												width: 20
											}
										}
									}
								},
								height: {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 100,
												top: 40,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.height.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.height'
												}
											}
										}
									}
								},
								'height-label': {
									type: 'label',
									states: {
										_default: {
											text: 'h',
											props: {
												left: 160,
												top: 40,
												width: 20
											}
										}
									}
								},
								'color': {
									type: 'colorpicker',
									states: {
										_default: {
											props: {
												left: 190,
												top: 8
											},
											attr: {
												allowGradient: true
											},
											bind: {
												color: {
													event: 'events.element.color.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.color'
												},
												click: {
													event: 'color.request'
												}
											}
										}
									}
								},
								'color-label': {
									type: 'label',
									states: {
										_default: {
											text: 'color',
											props: {
												left: 220,
												top: 10
											}
										}
									}
								},
								'font-family': {
									type: 'textfield',
									states: {
										_default: {
											text: 'Arial',
											props: {
												left: 10,
												top: 70,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.font-family.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.font-family'
												}
											}
										}
									}
								},
								'font-family-label': {
									type: 'label',
									states: {
										_default: {
											text: 'face',
											props: {
												left: 100,
												top: 70
											}
										}
									}
								},
								'font-size': {
									type: 'textfield',
									states: {
										_default: {
											text: '12',
											props: {
												left: 10,
												top: 100,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.font-size.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.font-size'
												}
											}
										}
									}
								},
								'font-size-label': {
									type: 'label',
									states: {
										_default: {
											text: 'size',
											props: {
												left: 70,
												top: 100
											}
										}
									}
								},
								'id': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 10,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.id.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.id'
												}
											}
										}
									}
								},
								'id-label': {
									type: 'label',
									states: {
										_default: {
											text: 'id',
											props: {
												left: 100,
												top: 130,
												width: 20
											}
										}
									}
								},
								'class': {
									type: 'textfield',
									states: {
										_default: {
											props: {
												left: 130,
												top: 130,
												width: 80
											},
											bind: {
												text: {
													event: 'events.element.class.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.class'
												}
											}
										}
									}
								},
								'class-label': {
									type: 'label',
									states: {
										_default: {
											text: 'class',
											props: {
												left: 220,
												top: 130,
												width: 40
											}
										}
									}
								},
								'text-content': {
									type: 'textarea',
									states: {
										_default: {
											props: {
												left: 10,
												top: 160,
												width: 200,
												height: 50
											},
											bind: {
												text: {
													event: 'events.element.textcontent.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.textcontent'
												}
											}
										}
									}
								},
								'text-content-label': {
									type: 'label',
									states: {
										_default: {
											text: 'html content',
											props: {
												left: 220,
												top: 160,
												width: 40
											}
										}
									}
								},
								'typeface' : {
									type : 'dropdown',
									states : {
										_default : {
											subElems : ['Arial', 'Courier New', 'Georgia', 'Impact', 'Times New Roman', 'Trebuchet MS', 'Verdana'],
											subElVals : ['Arial', 'Courier New', 'Georgia', 'Impact', 'Times New Roman', 'Trebuchet MS', 'Verdana'],
											props : {
												left: 10,
												top: 224,
												width: 200
											},
											bind : {
												text : {
													event : 'events.element.typeface.changed'
												}
											},
											behaviour : {
												change : {
													event : 'properties.element.typeface'
												}
											}
										}
									}
								},
								'typeface-label': {
									type: 'label',
									states: {
										_default: {
											text: 'typeface',
											props: {
												left: 220,
												top: 224
											}
										}
									}
								},
								'align' : {
									type : 'dropdown',
									states : {
										_default : {
											subElems : ['Left', 'Right', 'Center', 'Justify'],
											subElVals : ['left', 'right', 'center', 'justify'],
											props : {
												left: 10,
												top: 254,
												width: 65
											},
											bind : {
												text : {
													event : 'events.element.align.changed'
												}
											},
											behaviour : {
												change : {
													event : 'properties.element.align'
												}
											}
										}
									}
								},
								'align-label': {
									type: 'label',
									states: {
										_default: {
											text: 'align',
											props: {
												left: 85,
												top: 254
											}
										}
									}
								},
								'decoration' : {
									type : 'dropdown',
									states : {
										_default : {
											subElems : ['None', 'Underline', 'Overline', 'Line-through', 'Blink'],
											subElVals : ['none', 'underline', 'overline', 'line-through', 'blink'],
											props : {
												left: 125,
												top: 254,
												width: 100
											},
											bind : {
												text : {
													event : 'events.element.decoration.changed'
												}
											},
											behaviour : {
												change : {
													event : 'properties.element.decoration'
												}
											}
										}
									}
								},
								'decoration-label': {
									type: 'label',
									states: {
										_default: {
											text: 'decorate',
											props: {
												left: 235,
												top: 254
											}
										}
									}
								},
								'font-size': {
									type: 'textfield',
									states: {
										_default: {
											text: '12',
											props: {
												left: 10,
												top: 284,
												width: 50
											},
											bind: {
												text: {
													event: 'events.element.font-size.changed'
												}
											},
											behaviour: {
												change: {
													event: 'properties.element.font-size'
												}
											}
										}
									}
								},
								'font-size-label': {
									type: 'label',
									states: {
										_default: {
											text: 'font-size',
											props: {
												left: 70,
												top: 284
											}
										}
									}
								},
								'weight' : {
									type : 'dropdown',
									states : {
										_default : {
											subElems : ['Normal', 'Bold'],
											subElVals : ['normal', 'bold'],
											props : {
												left: 125,
												top: 284,
												width: 100
											},
											bind : {
												text : {
													event : 'events.element.weight.changed'
												}
											},
											behaviour : {
												change : {
													event : 'properties.element.weight'
												}
											}
										}
									}
								},
								'weight-label': {
									type: 'label',
									states: {
										_default: {
											text: 'weight',
											props: {
												left: 235,
												top: 284
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	};

	var colorPanel = {
		keys: [ 'color-panel' ],
		hash: {
			'color-panel': {
				type: 'element',
				states: {
					_default: {
						props: {
							position: 'relative',
							width: 300,
							height: 325
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [],
							hash: {

							}
						}
					}
				}
			}
		}
	};

	alignmentPanel = {
		keys: [ 'align-panel' ],
		hash: {
			'align-panel': {
				type: 'element',
				states: {
					_default: {
						props: {
							fill: {
								type: 'linear',
								direction: 'top',
								colors: [
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.423
									},
									{
										rgb: '#000000',
										opacity: 1,
										pos: 0.425
									},
									{
										rgb: '#d6d6d6',
										opacity: 1,
										pos: 0.427
									}
								]
							},
							position: 'relative',
							width: 300,
							height: 275
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [ 'realtime-label', 'box', 'type', 'top', 'right', 'bottom', 'left', 'align-label', 'align-left', 'align-center-x', 'align-right', 'align-top', 'align-center-y', 'align-bottom', 'distribute-label', 'distribute-left', 'distribute-center-x', 'distribute-right', 'distribute-top', 'distribute-center-y', 'distribute-bottom', 'match-label', 'match-width', 'match-height', 'match-both', 'space-label', 'space-x', 'space-y' ],
							hash: {
								'realtime-label': {
									type: 'label',
									states: {
										_default: {
											text: 'Realtime:',
											props: {
												left: 10,
												top: 10
											}
										}
									}
								},
								box: {
									type: 'element',
									states: {
										_default: {
											props: {
												top: 40,
												left: 15,
												width: 120,
												height: 60,
												'border-style': 'solid',
												'border-color': '#333333',
												'border-width': 1
											}
										}
									}
								},
								type: {
									type: 'dropdown',
									states: {
										_default: {
											props: {
												top: 60,
												left: 30
											},
											subElems: [ 'none', 'anchoring', 'center x', 'center y', 'center both' ],
											subElVals: [ 'none', 'anchor', 'horz', 'vert', 'both' ]
										}
									}
								},
								top: {
									type: 'checkbox',
									states: {
										_default: {
											props: {
												left: 70,
												top: 33
											}
										}
									}
								},
								right: {
									type: 'checkbox',
									states: {
										_default: {
											props: {
												left: 130,
												top: 63
											}
										}
									}
								},
								bottom: {
									type: 'checkbox',
									states: {
										_default: {
											props: {
												left: 70,
												top: 95
											}
										}
									}
								},
								left: {
									type: 'checkbox',
									states: {
										_default: {
											props: {
												left: 8,
												top: 63
											}
										}
									}
								},
								'align-label': {
									type: 'label',
									states: {
										_default: {
											text: 'Align:',
											props: {
												top: 125,
												left: 10
											}
										}
									}
								},
								'align-left': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 10,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.left'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-left-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'align-center-x': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 40,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.center.x'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-center-x-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'align-right': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 70,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.right'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-right-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'align-top': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 120,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.top'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-top-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'align-center-y': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 150,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.center.y'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-center-y-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'align-bottom': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 145,
												left: 180,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.align.bottom'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'align-bottom-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-label': {
									type: 'label',
									states: {
										_default: {
											text: 'Distribute:',
											props: {
												top: 175,
												left: 10
											}
										}
									}
								},
								'distribute-left': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 10,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.left'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-left-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-center-x': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 40,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.center.x'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-center-x-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-right': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 70,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.right'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-right-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-top': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 120,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.top'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-top-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-center-y': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 150,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.center.y'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-center-y-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'distribute-bottom': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 195,
												left: 180,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.distribute.bottom'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'distribute-bottom-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'match-label': {
									type: 'label',
									states: {
										_default: {
											text: 'Match size:',
											props: {
												top: 225,
												left: 10
											}
										}
									}
								},
								'match-width': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 245,
												left: 10,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.match.width'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'match-width-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'match-height': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 245,
												left: 40,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.match.height'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'match-height-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'match-both': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 245,
												left: 70,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.match.both'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'match-both-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'space-label': {
									type: 'label',
									states: {
										_default: {
											text: 'Space:',
											props: {
												top: 225,
												left: 120
											}
										}
									}
								},
								'space-x': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 245,
												left: 120,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.space.x'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'space-x-img'
															}
														}
													}
												}
											}
										}
									}
								},
								'space-y': {
									type: 'button',
									states: {
										_default: {
											props: {
												top: 245,
												left: 150,
												width: 19,
												height: 19
											},
											behaviour: {
												click: {
													event: 'properties.space.y'
												}
											},
											frames: {
												keys: [],
												hash: {}
											},
											children: {
												keys: [ 'img' ],
												hash: {
													img: {
														type: 'image',
														states: {
															_default: {
																src: 'space-y-img'
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	};

	var libraryPanel = {
		keys: [ 'library-panel' ],
		hash: {
			'library-panel': {
				type: 'element',
				states: {
					_default: {
						props: {
							position: 'relative',
							width: 300,
							height: 200
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [],
							hash: {

							}
						}
					}
				}
			}
		}
	};

	var componentPanel = {
		keys: [ 'component-panel' ],
		hash: {
			'component-panel': {
				type: 'element',
				states: {
					_default: {
						props: {
							position: 'relative',
							width: 300,
							height: 200
						},
						frames: {
							keys: [],
							hash: {}
						},
						children: {
							keys: [],
							hash: {

							}
						}
					}
				}
			}
		}
	};

	var editor =  {
		assets : {
			'align-left-img': {
				url: 'assets/align-left.gif'
			},
			'align-center-x-img': {
				url: 'assets/align-center-x.gif'
			},
			'align-right-img': {
				url: 'assets/align-right.gif'
			},
			'align-top-img': {
				url: 'assets/align-top.gif'
			},
			'align-center-y-img': {
				url: 'assets/align-center-y.gif'
			},
			'align-bottom-img': {
				url: 'assets/align-bottom.gif'
			},
			'distribute-left-img': {
				url: 'assets/distribute-left.gif'
			},
			'distribute-center-x-img': {
				url: 'assets/distribute-center-x.gif'
			},
			'distribute-right-img': {
				url: 'assets/distribute-right.gif'
			},
			'distribute-top-img': {
				url: 'assets/distribute-top.gif'
			},
			'distribute-center-y-img': {
				url: 'assets/distribute-center-y.gif'
			},
			'distribute-bottom-img': {
				url: 'assets/distribute-bottom.gif'
			},
			'match-width-img': {
				url: 'assets/match-width.gif'
			},
			'match-height-img': {
				url: 'assets/match-height.gif'
			},
			'match-both-img': {
				url: 'assets/match-both.gif'
			},
			'space-x-img': {
				url: 'assets/space-x.gif'
			},
			'space-y-img': {
				url: 'assets/space-y.gif'
			},
			'accordion-btn': {
				url: 'assets/accordion-btn.gif'
			},
			'accordion-btn-selected': {
				url: 'assets/accordion-btn-selected.gif'
			},
			'accordion-right-arrow': {
				url: 'assets/accordion-right-arrow.gif'
			},
			'accordion-down-arrow': {
				url: 'assets/accordion-down-arrow.gif'
			},
			'placeholder': {
				url: 'assets/spacer.gif'
			},
			'ico-properties': {
				url: 'assets/ico-properties.png'
			},
			'ico-palette': {
				url: 'assets/ico-palette.png'
			},
			'ico-align': {
				url: 'assets/ico-align.png'
			},
			'ico-library': {
				url: 'assets/ico-library.png'
			},
			'ico-components': {
				url: 'assets/ico-components.png'
			},
			'logo': {
				url: 'assets/logo.gif'
			},
			'btn-div': {
				url: 'assets/btn-div.png'
			},
			'btn-img': {
				url: 'assets/btn-img.png'
			},
			'btn-lbl': {
				url: 'assets/btn-lbl.png'
			}
		},
		library: {

		},
		movie : {
			states: {
				_default: {
					props: {
						width: 520,
						height: 468,
						fill: {
							type: 'solid',
							colors: [
								{
									rgb: '#000000',
									opacity: 1
								}
							]
						}
					},
					attr: {
						anchor: [ 1, 1, 1, 1 ]
					},
					frames: {
						keys: [],
						hash: {}
					},
					children: {
						keys: [ 'header', 'left-sidebar', 'workspace', 'right-sidebar' ],
						hash: {
							header: {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'solid',
												colors: [
													{
														rgb: '#373737',
														opacity: 1,
														pos: 0
													}
												]
											},
											width: 520,
											height: 68
										},
										attr: {
											anchor: [ 1, 1, 0, 1 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children: {
											keys: [ 'logo' ],
											hash: {
												'logo': {
													type: 'image',
													states: {
														_default: {
															src: 'logo',
															props: {
																left: 20,
																top: 17
															}
														}
													}
												}
											}
										}
									}
								}
							},
							'left-sidebar': {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'solid',
												colors: [
													{
														rgb: '#373737',
														opacity: 1
													}
												]
											},
											top: 68,
											width: 340,
											height: 400
										},
										attr: {
											anchor: [ 1, 0, 1, 1 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children: {
											keys: [ 'panels' ],
											hash: {
												panels: {
													type: 'accordion',
													states: {
														_default: {
															props: {
																fill: {
																	type: 'solid',
																	colors: [
																		{
																			rgb: '#373737',
																			opacity: 1
																		}
																	]
																},
																width: 300,
																height: 400,
																left: 20,
																'overflow-y': 'auto'
															},
															attr: {
																anchor: [ 1, 1, 1, 1 ]
															},
															data: {
																keys: [ 'button' ],
																hash: {
																	button: {
																		type: 'button',
																		states: {
																			_default: {
																				props: {
																					width: 300,
																					height: 36
																				},
																				frames: {
																					keys: [ '_default', '_over', '_selected' ],
																					hash: {
																						_default: {},
																						_over: {},
																						_selected: {}
																					}
																				},
																				children: {
																					keys: [ 'background', 'icon', 'label', 'state-icon' ],
																					hash: {
																						background: {
																							type: 'image',
																							states: {
																								_default: {
																									src: 'accordion-btn',
																									props: {
																										width: 300,
																										height: 36
																									}
																								},
																								_over: {
																									src: 'accordion-btn-selected'
																								},
																								_selected: {
																									src: 'accordion-btn-selected'
																								}
																							}
																						},
																						'icon': {
																							type: 'image',
																							states: {
																								_default: {
																									src: 'placeholder',
																									props: {
																										top: 8,
																										left: 9
																									}
																								}
																							}
																						},
																						label: {
																							type: 'label',
																							states: {
																								_default: {
																									text: 'Button',
																									props: {
																										color: '#ffffff',
																										top: 9,
																										left: 40,
																										'font-size': 13
																									}
																								}
																							}
																						},
																						'state-icon': {
																							type: 'image',
																							states: {
																								_default: {
																									src: 'accordion-right-arrow',
																									props: {
																										width: 8,
																										height: 8,
																										left: 260,
																										top: 14
																									}
																								},
																								_selected: {
																									src: 'accordion-down-arrow'
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															},
															frames: {
																keys: [],
																hash: {}
															},
															children: {
																keys: [ 'acc-property-panel', 'acc-color-panel', 'acc-align-panel', 'acc-library-panel', 'acc-component-panel' ],
																hash: {
																	'acc-property-panel': {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Properties',
																				icon: 'ico-properties',
																				props: {
																					position: 'relative',
																					width: 300,
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#d6d6d6',
																								opacity: 1
																							}
																						]
																					}
																				},
																				attr: {
																					id: 'propertiesPanel'
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: propertyFrames
																			}
																		}
																	},
																	'acc-color-panel': {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Color',
																				icon: 'ico-palette',
																				props: {
																					width: 300,
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#d6d6d6',
																								opacity: 1
																							}
																						]
																					}
																				},
																				attr: {
																					id: 'colorPanel'
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: colorPanel
																			}
																		}
																	},
																	'acc-align-panel': {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Alignment',
																				icon: 'ico-align',
																				props: {
																					width: 300,
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#d6d6d6',
																								opacity: 1
																							}
																						]
																					}
																				},
																				attr: {
																					id: 'alignPanel'
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: alignmentPanel
																			}
																		}
																	},
																	'acc-library-panel': {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Library',
																				icon: 'ico-library',
																				props: {
																					width: 300,
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#d6d6d6',
																								opacity: 1
																							}
																						]
																					}
																				},
																				attr: {
																					id: 'libraryPanel'
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: libraryPanel
																			}
																		}
																	},
																	'acc-component-panel': {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Components',
																				icon: 'ico-components',
																				props: {
																					width: 300,
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#d6d6d6',
																								opacity: 1
																							}
																						]
																					}
																				},
																				attr: {
																					id: 'componentPanel'
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: componentPanel
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							},
							workspace: {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'solid',
												colors: [
													{
														rgb: '#666666',
														opacity: 1
													}
												]
											},
											top: 68,
											left: 340,
											width: 90,
											height: 400,
											'overflow': 'auto'
										},
										attr: {
											anchor: [ 1, 1, 1, 1 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children:{
											keys: [ 'stage-container' ],
											hash: {
												'stage-container': {
													type: 'element',
													states: {
														_default: {
															props: {
																fill: {
																	type: 'solid',
																	colors: [
																		{
																			rgb: '#666666',
																			opacity: 1
																		}
																	]
																},
																'min-height': 2000,
																'min-width': 2000
															},
															frames: {
																keys: [],
																hash: {}
															},
															children: {
																keys: [ 'stage', 'hud' ],
																hash: {
																	stage: {
																		type: 'element',
																		states: {
																			_default: {
																				props: {
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#FFFFFF',
																								opacity: 1
																							}
																						]
																					},
																					width: 400,
																					height: 300
																				},
																				attr: {
																					center: 'both'
																				}
																			}
																		}
																	},
																	hud: {
																		type: 'element',
																		states: {
																			_default: {
																				props: {
																					overflow: 'visible',
																					width: 1,
																					height: 1
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							},
							'right-sidebar': {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'solid',
												colors: [
													{
														rgb: '#373737',
														opacity: 1,
														pos: 0
													}
												]
											},
											top: 68,
											left: 430,
											width: 90,
											height: 400
										},
										attr: {
											anchor: [ 1, 1, 1, 0 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children: {
											keys: [ 'btn-div', 'btn-img', 'btn-lbl' ],
											hash: {
												'btn-div': {
													type: 'image',
													states: {
														_default: {
															src: 'btn-div',
															props: {
																top: 4,
																left: 16,
																cursor: 'pointer'
															},
															behaviour: {
																click: {
																	event: 'controls.add.div'
																}
															}
														}
													}
												},
												'btn-img': {
													type: 'image',
													states: {
														_default: {
															src: 'btn-img',
															props: {
																top: 4,
																left: 50,
																cursor: 'pointer'
															},
															behaviour: {
																click: {
																	event: 'controls.add.img'
																}
															}
														}
													}
												},
												'btn-lbl': {
													type: 'image',
													states: {
														_default: {
															src: 'btn-lbl',
															props: {
																top: 30,
																left: 16,
																cursor: 'pointer'
															},
															behaviour: {
																click: {
																	event: 'controls.add.lbl'
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	$.fn.fluxui.evt().addListener( 'app.loaded', function() {
		var data = $('#movie-container').fluxui( editor );
		var movie = new data.types.editor();
	} );
} )(jQuery);
