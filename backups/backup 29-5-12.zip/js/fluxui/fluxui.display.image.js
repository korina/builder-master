/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Image class
	 * Provides for the HTML img tag
	 **/
	$class.create( {
		namespace : 'image',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.entity( 'image' );
			if ( !!$state.src ) {
				var src = 'http://placehold.it/100x100';
				if ( !!assets[$state.src] ) {
					src = assets[$state.src].url;
					if ( assets[$state.src].height ) this.$node().attr( 'height', assets[$state.src].height );
					if ( assets[$state.src].width ) this.$node().attr( 'width', assets[$state.src].width );
				}
				this.$node().attr( 'src', src );
			}
		},
		fields : {
			markup : '<img />'
		},
		methods : {
			applyProperties : function( $props, $state ) {
				if ( !!$props.props )
					types.tween.animate( this.node, $props.props, !!$state ? $state.duration : null, !!$state ? $state.easing : null, !!$state ? $state.complete : null );
				if ( !!$props && !!$props.src && !!assets[$props.src] )
					this.$node().attr( 'src', assets[$props.src].url );
			}
		}
	} );
	
} )(jQuery,this);