/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Core system class
	 * Provides system level functions
	 * Requires:
	 *		fluxui.display.element.js
	 **/
	$class.create( {
		namespace : 'core',
		statics : {
			// load all images used in the movie. likely not needed, but future proofs code
			preload : function( $assets ) {
				for ( a in $assets )
					$('<img/>')[0].src = $assets[a].url;
			},
			// guarantees a unique movie id
			nextMovieCounter : function() {
				fdata.counter = fdata.counter || 0;
				return fdata.counter++;
			},
			nextElementCounter : function() {
				fdata.elmCounter = fdata.elmCounter || 0;
				return fdata.elmCounter++;
			},
			// helps kickstart movie parsing into HTML nodes
			createMovie : function( $clip, $movieId, $state ) {
				$state = $state || '_default';
				var node = new types.element( 'root_' + $movieId, $clip.states[$state] );
				$(node).attr( 'entity', 'movie' );
				return node.node;
			},
			// encodes HTML to a valid string
			htmlEncode : function(value){
				return $('<div/>').text(value).html();
			},
			// Decodes a string to valid HTML
			htmlDecode : function(value){
				return $('<div/>').html(value).text();
			},
			// Clones an object
			clone : function( $obj ) {
				var newObj = ( $obj instanceof Array ) ? [] : {};
				for ( i in $obj ) {
					if ( $obj[i] && typeof $obj[i] == "object" ) {
						newObj[i] = types.core.clone( $obj[i] );
					} else newObj[i] = $obj[i]
				}
				return newObj;
			},
			map : function( arr, fun /*, thisp*/) {
				var len = arr.length;
				if ( typeof fun != "function" )
					throw new TypeError();
				
				var res = new Array( len );
				var thisp = arguments[2];
				for ( var i = 0; i < len; i++ ) {
					if ( i in arr )
						res[i] = fun.call( thisp, arr[i], i, arr);
				}
				
				return res;
			},
			// Non-global polluting array.indexOf function
			indexOf : function( $array, $value ) {
				for ( var i = 0; i < $array.length; i++ ) {
					if ( $array[i] == $value ) return true;
				}
				return false;
			},
			// Returns true if $val is an Object. This includes any complex object, including Arrays.
			isObject : function( $val ) {
				return $val === Object( $val );
			},
			// Returns true if $val is an array.
			isArray : function( $val ) {
				return $val.constructor == Array;
			},
			// Returns true if $val is a string
			isString : function( $val ) {
				return toString.call( $val ) == '[object String]';
			},
			// Returns true if item has no length or own properties.
			isEmpty : function( $val ) {
				if ( types.core.isArray( $val ) || types.core.isString( $val ) ) return $val.length === 0;
				for ( var key in $val ) if ( $val.hasOwnProperty( key ) ) return false;
				return true;
			}
		}
	} );
	
} )(jQuery,this);