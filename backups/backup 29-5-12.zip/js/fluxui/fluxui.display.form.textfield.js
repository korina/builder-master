/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Text class
	 * Provides for the input text and password HTML tags. If the 'text' field is not 'password' then its text input
	 **/
	$class.create( {
		namespace : 'textfield',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( $state.text === "password" ) {
				this.$node().attr( 'type', 'password' );
			} else {
				this.$node().attr( 'type', 'text' );
				if ( !!$state.text )
					this.$node().val( types.core.htmlEncode( $state.text ) );
			}
		},
		fields : {
			markup : '<input />'
		},
		inherits : types.input
	} );
	
} )(jQuery,this);