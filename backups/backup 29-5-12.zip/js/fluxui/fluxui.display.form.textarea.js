/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * TextArea class
	 * Provides for the textarea HTML tag
	 **/
	$class.create( {
		namespace : 'textarea',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			var me = this;
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !!$state.text )
				me.$node().val( types.core.htmlEncode( types.core.htmlEncode( $state.text ) ) );
			var b = $state.bind;
			if ( !!b )
				for ( var i in b ) {
					if ( b.hasOwnProperty( i ) ) {
						if ( !!b[i].event )
							$.fn.fluxui.evt().addListener( b[i].event, function( $ns, $data ) {
								if ( i == 'text' )
									me.$node().val( $data );
								else
									me.$node().attr( i, $data );
							} );
					}
				}
		},
		fields : {
			markup : '<textarea />'
		},
		inherits : types.element
	} );
	
} )(jQuery,this);