/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	/**
	 * Style class
	 * Provides functions specific to parsing and understanding styles / css values
	 **/
	$class.create( {
		namespace : 'style',
		statics : {
			css : function( $node, $style, $value ) {
				switch( $style ) {
					case 'fill' :
						var fill = types.style.normaliseFill( $value );
						$($node).css( 'filter', fill.filter );
						for ( var i = 0; i < fill.background.length; i++ )
							$($node).css( 'background', fill.background[i] );
						return;
						break;
				}
				$($node).css( $style, $value );
			},
			decorate : function( $key, $value ) {
				return ( types.style.isNumeric( $key ) && $value > 0 ) ? $value + 'px' : $value;
			},
			raw : function( $value ) {
				return Number( String( $value ).split( 'px' ).join( '' ) );
			},
			// Normalises single color gradient parsing (solid fills)
			normaliseFill : function( $data ) {
				var fillType = $data.type || 'solid';
				if ( $data.colors.length <= 1 )
					fillType = 'solid';
				return types.style.normaliseBackground( fillType, $data.direction || 'top', $data.colors );
			},
			// Provides css for border radius for different browser types
			normaliseBorder : function( $size ) {
				return { "border-radius" : $size,
				"-moz-border-radius" : $size,
				"-webkit-border-radius" : $size };
			},
			// Provides css for gradient backgrounds for different browser types
			normaliseBackground : function( $fillType, $direction, $colors ) {
				if ( $colors.length == 1 )
					$colors[1] = $colors[0];
				var fromIE_RGBA = types.color.RGBAToHex( types.color.objToRGBA( $colors[0].rgb ), true );
				var toColor = $colors[$colors.length-1].rgb;
				var toIE_RGBA = types.color.RGBAToHex( types.color.objToRGBA( toColor ), true );
				var clrList = '';
				var grdList = '';
				var grdDir = 'left top, left bottom';
				switch( $direction ) {
					case 'top':
						break;
					case 'left':
						grdDir = 'left top, right top';
						break;
					case '-45deg':
						grdDir = 'left top, right bottom';
						break;
					case '45deg':
						grdDir = 'left bottom, right top';
						break;
					case 'center':
						grdDir = 'center center, 0px, center center';
						break;
				}
				$colors.sort( function( a, b ) {
					if ( !a.pos || !b.pos || ( a.pos < b.pos ) )
						return -1;
					else if ( a.pos > b.pos )
						return 1;
					else
						return 0;
				} );
				for ( var i = 0; i < $colors.length; i++ ) {
					if ( isNaN( $colors[i].pos ) ) {
						var lastPos = 0;
						if ( $colors.length == 1 ) lastPos = $colors[i].pos = 0;
						else if ( i == $colors.length - 1 ) lastPos = $colors[i].pos = 1;
						else lastPos = $colors[i].pos = ( 1 - lastPos ) / ( $colors.length - ( i - 1 ) ) + lastPos;
					} else lastPos = $colors[i].pos;
					clrList += types.color.RGBAToString( types.color.objToRGBA( $colors[i].rgb ) ) + " " + ($colors[i].pos * 100) + "%";
					grdList += "color-stop(" + ($colors[i].pos * 100) + "%" + " " + types.color.RGBAToHex( types.color.objToRGBA( $colors[i].rgb ) ) + ")";
					if ( i < $colors.length - 1 ) {
						clrList += ", ";
						grdList += ", ";
					}
				}
				var ret = { filter : "progid:DXImageTransform.Microsoft.gradient(startColorStr='" + fromIE_RGBA + "', EndColorStr='" + toIE_RGBA + "')",
					background : ["-webkit-gradient(" + ( $direction == 'center' ? 'radial' : 'linear' ) + ", " + grdDir + ", " + grdList + ")",
					"-webkit-linear-gradient(" + $direction + ", " + clrList + ")",
					"-moz-linear-gradient(" + $direction + ", " + clrList + ")",
					"-ms-linear-gradient(" + $direction + ", " + clrList + ")",
					"-o-linear-gradient(" + $direction + ", " + clrList + ")",
					"linear-gradient(" + $direction + ", " + clrList + ")"] };
				return ret;
			},
			// Gets those properties in $nextProps that are different or not
			// present in $curProps and adds them to $merged.  If differences are found,
			// true is returned, else false.
			getPropertyDiff : function( $curProps, $nextProps, $merged ) {
				var diff = false;
				if ( !$curProps )
					$curProps = {};
				for ( var prop in $nextProps ) {
					if ( $nextProps.hasOwnProperty( prop ) ) {
						if ( !$curProps[prop] && typeof $nextProps[prop] != 'object' ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
							continue;
						}
						if ( typeof $nextProps[prop] === 'object'  ) {
							var obj = {};
							if ( types.style.getPropertyDiff( $curProps[prop], $nextProps[prop], obj ) ) {
								if ( !$merged[prop] ) $merged[prop] = {}
								if ( prop == "fill" )
									$.extend( true, $merged[prop], $nextProps[prop] );
								else
									$.extend( true, $merged[prop], obj );
								diff = true;
							}
						} else if ( $curProps[prop] != $nextProps[prop] ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
						}
					}
				}
				return diff;
			},
			// Lists all css types that can be animated
			canAnimate : function( $prop ) {
				return types.core.indexOf( ['opacity', 'color', 'fill', 'background-color', 'border-color', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'], $prop );
			},
			// Lists all css types that are a color type
			isColor : function( $prop ) {
				return types.core.indexOf( ['color', 'fill', 'background-color', 'border-color'], $prop );
			},
			// Lists all css types that are numeric
			isNumeric : function( $prop ) {
				return types.core.indexOf( ['opacity', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'], $prop );
			}
		}
	} );
	
} )(jQuery,this);