/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Label class (Given that 'label' is a HTML element, should we change this class' name?)
	 **/
	$class.create( {
		namespace : 'label',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.entity( 'label' );
			if ( !!$state.text )
				this.$node().html( $state.text );
		},
		props : {
			'overflow' : 'hidden',
			'font-family' : 'arial',
			'font-size' : 12
		}
	} );
	
} )(jQuery,this);