/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	/**
	 * Color class
	 * Provides color specific functions, including color conversion.
	 **/
	$class.create( {
		namespace : 'color',
		statics : {
			// Converts a decimal number to a hexidecimal number
			base16 : function( $num ) {
				return 16 > $num ? "0" + $num.toString(16) : $num.toString(16);
			},
			// Converts a hexidecimal number to a decimal number
			base10 : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !Math.isNaN( Number( $hex ) ) ? $hex : parseInt( $hex[1], 16 ) << 16 + parseInt( $hex[2], 16 ) << 8 + parseInt( $hex[3], 16 );
			},
			// Converts a hexidecimal number to an RGBA array.
			hexToRGBA : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !$hex ? $hex : [ parseInt( $hex[1], 16 ), parseInt( $hex[2], 16 ), parseInt( $hex[3], 16 ), 255 ];
			},
			// Converts a color object to an RGBA array
			objToRGBA : function( $obj ) {
				if ( $obj == "transparent" ) return [255, 255, 255, 0];
				if ( $obj.constructor == Array ) return $obj;
				var hex = types.color.hexToRGBA( $obj );
				return hex ? hex : ( hex = types.color.rgbaStringToRGBA( $obj ) ) ? hex : [255, 255, 255, 150];
			},
			// Converts an RGBA array to a string representaion (not hex).
			RGBAToString : function( $num ) {
				if ( $num.constructor == Array ) {
					var a = new Array();
					for ( i = 0; i < $num.length && i < 4; i++ )
						a.push( ( i == 3 ) ? $num[i] / 255 : $num[i] );
					return "rgba(" + a.join() + ")";
				}
			},
			// Converts string representation of RGBA to an RGBA array.
			rgbaStringToRGBA : function( $str ) {
				$str = /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/.exec( $str );
				return !$str ? $str : [ parseInt( $str[1], 10 ), parseInt( $str[2], 10 ), parseInt( $str[3], 10 ), parseInt( void 0 == $str[4] ? 255 : $str[4], 10 )];
			},
			// Converts an RGBA array to a hexidecimal string.
			RGBAToHex : function( $num, $useAlpha ) {
				if ( $num.constructor == Array ) {
					var c = [];
					for ( var i = 0; i < $num.length; i++ )
						c[i] = $num[i];
					if ( c.length > 3 ) {
						var alpha = c.pop();
						if ( $useAlpha )
							c.unshift( alpha );
					}
					var hashed = new Array();
					for ( i in c )
						hashed.push( types.color.base16( c[i] ) );
					return '#' + hashed.join(''); 
				}
			},
			// Converts a color object to an RGBA array
			colorObjToRGBA : function( $color, $opacity ) {
				if ( !$color || $color == 'transparent' )
					return [255,255,255,0];
				else if ( $color.constructor == Array )
					return $color;
				else if ( "string" == typeof $color ) {
					if ( $color.substr( 0, 3 ) == "rgb" ) {
						var re = /rgb?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/;
						var segs = re.exec( $color );
						return !segs ? segs : [parseInt(segs[1], 10), parseInt(segs[2], 10), parseInt(segs[3], 10), parseInt(void 0 == segs[4] ? 255 : segs[4], 10)];
					} else {
						var c = types.color.hexToRGBA( $color );
						if ( $opacity != null )
							c[3] = Math.round( $opacity * 255 );
						return c;
					}
				} else if ( typeof $color === 'array' ) {
					var c = $color;
					if ( $opacity != null )
						c[3] = Math.round( $opacity * 255 );
					return c;
				}
			},
			arrayOfColors : function( $value ) {
				if ( typeof $value.constructor != Array ) {
					if ( !!$value.rgb )
						$value = [types.color.objToRGBA( $value.rgb )];
					else
						$value = [types.color.objToRGBA( $value )];
				} else
					for ( var i = 0; i < $value.length; i++ ) {
						if ( !!$value[i].rgb )
							$value[i] = types.color.objToRGBA( $value[i].rgb );
						else
							$value[i] = types.color.objToRGBA( $value[i] );
					}
				return $value;
			}
		}
	} );
	
} )(jQuery,this);