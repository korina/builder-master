/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Checkbox class
	 * Provides for the input checkbox HTML tag
	 **/
	$class.create( {
		namespace : 'checkbox',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			this.$node().attr( 'type', 'checkbox' );
			if ( $state.checked )
				this.$node().attr( 'checked', 'checked' );
		},
		inherits : types.input
	} );
	
} )(jQuery,this);