/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Unordered list class
	 * Provides for the select HTML tag
	 **/
	$class.create( {
		namespace : 'list.unordered',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'li', elText, $state.subElVals[subElem], text );
			}
		},
		fields : {
			markup : '<ul />'
		},
		inherits : types.input
	} );
	
	/**
	 * Ordered list class
	 * Provides for the select HTML tag
	 **/
	$class.create( {
		namespace : 'orderedList',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
		},
		fields : {
			markup : '<ol />'
		},
		inherits : types.element
	} );
	
	/**
	 * List item class
	 * Provides the item tag for both ordered and unordered lists
	 **/
	$class.create( {
		namespace : 'item',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
		},
		fields : {
			markup : '<li />'
		},
		inherits : types.element
	} );
	
} )(jQuery,this);