/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Openselect class
	 * Provides for multiple lined select HTML tag
	 **/
	$class.create( {
		namespace : 'openselect',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			this.$node().attr( 'size', $state.subElems.length );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'option', elText, $state.subElVals[subElem], text );
			}
		},
		fields : {
			markup : '<select />'
		},
		inherits : types.input
	} );
	
} )(jQuery,this);