/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/

( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	/**
	 * Tween class
	 * Handles all tweening / animation tasks.
	 **/
	$class.create( {
		namespace : 'tween',
		statics : {
			// From $start color to $end color using tween percentage $pc, returns
			// a new color that is the $pc (percentage) of both colors, where 0% is $start
			// and 100% is $end.
			getRGBTransition : function( $start, $end, $pc ) {
				var r1 = $start[0],
					g1 = $start[1],
					b1 = $start[2],
					a1 = $start[3];

				var r2 = $end[0],
					g2 = $end[1],
					b2 = $end[2],
					a2 = $end[3];

				return [Math.floor( r1 + ( $pc * ( r2 - r1 ) ) + .5 ),
						Math.floor( g1 + ( $pc * ( g2 - g1 ) ) + .5 ),
						Math.floor( b1 + ( $pc * ( b2 - b1 ) ) + .5 ),
						Math.floor( a1 + ( $pc * ( a2 - a1 ) ) + .5 )];
			},
			// Prepares to animate $props on $node for $duration using the ease function $easing.
			// once complete, $callback in invoked.
			animate : function( $node, $props, $duration, $easing, $callback ) {
				if ( !$easing ) $easing = "linearTween";
				var aprops = {};
				var hasProps = false;
				var inst = types.element.getInstance( $node );
				for ( var key in $props ) {
					if ( !!$duration && $props.hasOwnProperty( key ) && types.style.canAnimate( key ) ) {
						aprops[key] = $props[key];
						hasProps = true;
					} else {
						if ( !!$props[key] && $props[key].constructor == Array )
							for ( j in $props[key] ) {


								if ( !inst || !inst.setStyle )
									types.style.css( $node, key, types.style.decorate( key, $props[key][j] ) );
								else
									inst.setStyle( key, $props[key][j] );
							}
						else
							if ( !inst || !inst.setStyle )
								types.style.css( $node, key, types.style.decorate( key, $props[key] ) );
							else
								inst.setStyle( key, $props[key] );
					}
				}
				if ( hasProps ) {
					types.tween.doAnimation( $node, aprops, $duration, $easing, $callback );
				} else if ( !!$callback ) $callback();

			},
			// Performs the actual animation. See "animate" above.
			doAnimation : function( $node, $props, $duration, $easing, $callback ) {
				var startTime = new Date().getTime();
				var ease = types.tween[$easing];
				var inst = types.element.getInstance( $node );
				inst.props = inst.props || {};
				var fills = [], colors = [], css = [];
				for ( var prop in $props ) {
					if ( types.style.isColor( prop ) ) {
						if ( prop == 'fill' ) {
							if ( inst.props.fill == null )
								inst.props.fill = { colors : [ { rgb : '#ffffff', opacity: 0 }, { rgb : '#ffffff', opacity: 0 } ], type : 'solid' };
							if ( typeof inst.props.fill.colors[1] === 'undefined' )
								inst.props.fill.colors[1] = inst.props.fill.colors[0];
							if ( typeof $props[prop].colors[1] === 'undefined' )
								$props[prop].colors[1] = $props[prop].colors[0];
							var pc1 = types.color.colorObjToRGBA( inst.props.fill.colors[0].rgb, inst.props.fill.colors[0].opacity ),
								pc2 = types.color.colorObjToRGBA( inst.props.fill.colors[1].rgb, inst.props.fill.colors[1].opacity ),
								nc1 = types.color.colorObjToRGBA( $props[prop].colors[0].rgb, $props[prop].colors[0].opacity ),
								nc2 = types.color.colorObjToRGBA( $props[prop].colors[1].rgb, $props[prop].colors[1].opacity );
							if ( !( pc1 == nc1 && pc2 == nc2 ) ) {
								fills.push( {
									type : $props[prop].type || 'solid', 
									from1 : pc1,
									from2 : pc2, 
									to1 : nc1,
									to2 : nc2
								} );
							}
							continue;
						} else {
							var val = inst.props[prop] || inst.$node().css( prop );
							if ( !val || val == '' || val == 'initial' )
								var val = 'transparent';
							if ( val != $props[prop] ) {
								var pcolor = types.color.colorObjToRGBA( val );
								var ncolor = types.color.colorObjToRGBA( $props[prop].rgb, $props[prop].opacity );
								colors.push( { prop : prop, from : pcolor, to : ncolor } );
							}
							continue;
						}
					}
					if ( types.style.isNumeric( prop ) ) {
						var val = ( inst.props[prop] || inst.$node().css( prop ) ),
							newProp = $props[prop];
						val = types.style.raw( val );
						if ( val != newProp )
							css.push( { prop : prop, from : val, to : newProp } );
					}
				}
				// If there's a duration, then create a timer function and animate
				if ( $duration > 0 ) {
					types.timer.add( function() {
						var time = Math.min( new Date().getTime() - startTime, $duration );
						var perc = ease( time, 0, 1, $duration );
						if ( fills.length > 0 ) {
							for ( var i = 0; i < fills.length; i++ ) {
								inst.setStyle( 'background-image', { 
									color1 : types.tween.getRGBTransition( fills[i].from1, fills[i].to1, perc ), 
									color2 : types.tween.getRGBTransition( fills[i].from2, fills[i].to2, perc ), 
									type : fills[i].type
								} );
							}
						}
						if ( colors.length > 0 ) {
							for ( var i = 0; i < colors.length; i++ ) {
								inst.setStyle(
									colors[i].prop,
									types.tween.getRGBTransition( colors[i].from, colors[i].to, perc )
								);
							}
						}
						if ( css.length > 0 ) {
							for ( var i = 0; i < css.length; i++ ) {
								var nv = Math.floor( css[i].from + ( perc * ( css[i].to - css[i].from ) ) + .5 );
								inst.setStyle( css[i].prop, nv );
							}
						}
						if ( time >= $duration ) {
							$callback();
							return false;
						}
					} );
				// If no duration, just change the properties here and now.
				} else {
					for ( var i = 0; i < fills.length; i++ )
						inst.setStyle( 'background-image', { 
							color1 : fills[i].to1, 
							color2 : fills[i].to2, 
							type : fills[i].type
						} );
					for ( var i = 0; i < colors.length; i++ )
						inst.setStyle( colors[i].prop, colors[i].to );
					for ( var i = 0; i < css.length; i++ )
						inst.setStyle( css[i].prop, css[i].to );
				}
			},
			// --- LIST OF TWEEN FUNCTIONS --- //
			// t: current time, b: beginning value, c: change in value, d: duration
			// t and d can be in frames or seconds/milliseconds
			linearTween : function( t, b, c, d ) {
				return c * t / d + b;
			},
			easeInQuad : function( t, b, c, d ) {
				return c * ( t /= d ) * t + b;
			},
			easeOutQuad : function( t, b, c, d ) {
				return -c * ( t /= d ) * ( t - 2 ) + b;
			},
			easeInOutQuad : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t + b;
				return -c / 2 * ( ( --t ) * ( t - 2 ) - 1 ) + b;
			},
			easeInCubic : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t + b;
			},
			easeOutCubic : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t + 1 ) + b;
			},
			easeInOutCubic : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t + 2 ) + b;
			},
			easeInQuart : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t + b;
			},
			easeOutQuart : function( t, b, c, d ) {
				return -c * ( ( t = t / d - 1 ) * t * t * t - 1 ) + b;
			},
			easeInOutQuart : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t + b;
				return -c / 2 * ( ( t -= 2 ) * t * t * t - 2 ) + b;
			},
			easeInQuint : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t * t + b;
			},
			easeOutQuint : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t * t * t + 1 ) + b;
			},
			easeInOutQuint : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t * t * t + 2 ) + b;
			},
			easeInSine : function( t, b, c, d ) {
				return -c * Math.cos( t / d * ( Math.PI / 2 ) ) + c + b;
			},
			easeOutSine : function( t, b, c, d ) {
				return c * Math.sin( t / d * ( Math.PI / 2 ) ) + b;
			},
			easeInOutSine : function( t, b, c, d ) {
				return -c / 2 * ( Math.cos( Math.PI * t / d ) - 1 ) + b;
			},
			easeInExpo : function( t, b, c, d ) {
				return ( t == 0 ) ? b : c * Math.pow( 2, 10 * ( t / d - 1 ) ) + b;
			},
			easeOutExpo : function( t, b, c, d ) {
				return ( t == d ) ? b + c : c * ( - Math.pow( 2, -10 * t / d ) + 1 ) + b;
			},
			easeInOutExpo : function( t, b, c, d ) {
				if ( t == 0 ) return b;
				if ( t == d ) return b + c;
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * Math.pow( 2, 10 * ( t - 1 ) ) + b;
				return c / 2 * ( - Math.pow( 2, -10 * --t ) + 2 ) + b;
			},
			easeInCirc : function( t, b, c, d ) {
				return -c * ( Math.sqrt( 1 - ( t /= d ) * t ) - 1 ) + b;
			},
			easeOutCirc : function( t, b, c, d ) {
				return c * Math.sqrt( 1 - ( t = t / d - 1 ) * t ) + b;
			},
			easeInOutCirc : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return -c / 2 * ( Math.sqrt( 1 - t * t ) - 1 ) + b;
				return c / 2 * ( Math.sqrt( 1 - ( t -= 2 ) * t ) + 1) + b;
			},
			easeInElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return -( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
			},
			easeOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return a * Math.pow( 2, -10 * t ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) + c + b;
			},
			easeInOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d / 2 ) == 2 ) return b + c;  if ( !p ) p = d * ( .3 * 1.5 );
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				if ( t < 1 ) return -.5 * ( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
				return a * Math.pow( 2 , -10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) * .5 + c + b;
			},
			easeInBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( t /= d ) * t * ( ( s + 1 ) * t - s ) + b;
			},
			easeOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( ( t = t / d - 1 ) * t * ( ( s + 1 ) * t + s ) + 1 ) + b;
			},
			easeInOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158; 
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * ( t * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t - s ) ) + b;
				return c / 2 * ( ( t -= 2 ) * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t + s ) + 2 ) + b;
			},
			easeInBounce : function( t, b, c, d ) {
				return c - types.tween.easeOutBounce( d - t, 0, c, d ) + b;
			},
			easeOutBounce : function( t, b, c, d ) {
				if ( ( t /= d ) < ( 1 / 2.75 ) ) {
					return c * ( 7.5625 * t * t ) + b;
				} else if ( t < ( 2 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 1.5 / 2.75 ) ) * t + .75 ) + b;
				} else if ( t < ( 2.5 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 2.25 / 2.75 ) ) * t + .9375 ) + b;
				} else {
					return c * ( 7.5625 * ( t -= ( 2.625 / 2.75 ) ) * t + .984375 ) + b;
				}
			},
			easeInOutBounce : function( t, b, c, d ) {
				if ( t < d / 2 ) return types.tween.easeInBounce( t * 2, 0, c, d ) * .5 + b;
				return types.tween.easeOutBounce( t * 2 - d, 0, c, d ) * .5 + c * .5 + b;
			}
		}
	} );
	
} )(jQuery,this);