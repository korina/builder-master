/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Radiogroup class
	 * Provides for the input radio HTML tag
	 **/
	$class.create( {
		namespace : 'radiogroup',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'input', elText, $state.subElVals[subElem], 'radio', text );
			}
		},
		fields : {
			markup : '<div class="radiogroup" />'

		},
		inherits : types.input
	} );
	
} )(jQuery,this);