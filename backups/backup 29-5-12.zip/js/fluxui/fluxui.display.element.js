/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	/**
	 * Element class
	 * This is the base class for all display objects
	 *
	 * Requires:
	 *		fluxui.color.js
	 *		fluxui.core.js
	 *		fluxui.style.js
	 *		fluxui.tween.js
	 **/
	$class.create( { 
		namespace : 'element',
		constructor : function( $id, $state ) {
			var np = ( !!$state ) ? $state.props : null;
			var p = {};
			$.extend( true, p, this.props );
			$.extend( true, p, np );
			this.node = $(this.markup).get( 0 );
			this.entity( this.className );
			this.fluxid( $id );
			//types.style.normalisePropStack( p );
			this.applyProperties( { props : p } );
			this.data( $state );
			//this.stateName();
			this.$node().data( 'currentInstance', this );
			this.playhead( { direction: 1 } );
			if ( !!$state && $state.children ) {
				for ( indx in $state.children.keys ) {
					var child = $state.children.hash[$state.children.keys[indx]];
					if ( !!child ) {
						var l = new types[child.type]( $state.children.keys[indx], child.states._default );
						this.$node().append( l.node );
						if ( !!l.initialise )
							l.initialise( child.states._default );
					}
				}
			}
			this.gotoState( '_default' );
			var b = $state.behaviour;
			if ( !!b )
				for ( var i in b ) {
					if ( b.hasOwnProperty( i ) ) {
						if ( !!b[i].action ) 
							this.$node().bind( i, { caller : this, event : b[i] }, function( e ) {
								// Passing 'doAction' the action, event, and also the whole event object for pageX &c. and 'this' hack
								e.data.caller.parentInstance().doAction( e.data.event.action, e.data.event, e );
							} );
						if ( !!b[i].event )
							$.fn.fluxui.evt().bind( this.$node(), i, b[i].event );
					}
				}
		},
		fields : {
			markup : '<div />'
		},
		props : {
			'position' : 'absolute',
			'top' : 0,
			'left' : 0,
			'padding' : 0,
			'margin' : 0,
			'box-sizing' : 'border-box',
			'vertical-align' : 'baseline',
			'word-wrap' : 'break-word',
			'max-width' : 'none',
			'max-height' : 'none',
			'zoom' : 1,
			'overflow' : 'hidden',
			'border' : 'solid',
			'border-radius' : 0,
			'border-width' : 0,
			'border-color' : { rgb: [0,0,0,0] },
			'border-style' : 'solid'
		},
		methods : {
			// The individual object id
			fluxid : function( value ) {
				if ( !!value )
					this.$node().attr( 'fluxid', value );
				return this.$node().attr( 'fluxid' );
			},
			// The string representation of its class
			entity : function( value ) {
				if ( !!value )
					this.$node().attr( 'entity', value );
				return this.$node().attr( 'entity' );
			},
			// Any element's entity
			elementsEntity : function( $elem ) {
				return $elem.context.attributes[ 0 ].value;
			},
			// The class nodes parent --- Lee, I've changed 'node()' to '$node()'
			parentNode : function() {
				return this.$node().parent();
			},
			// The class of the class nodes parent
			parentInstance : function() {
				return types.element.getInstance( this.$node().parent().get( 0 ) );
			},
			// data (JSON segment relative to this class instance) for this node.
			data : function( $data ) {
				if ( !!$data )
					this.$node().data( 'nodeData', $data );
				return this.$node().data( 'nodeData' );
			},
			// The class' underlying HTML node.
			$node : function() {
				return $(this.node);
			},
			// Perform any actions required after this object has been appended to the DOM
			initialise : function( $state ) {
				if ( !!$state && !!$state.attr )
					this.applyAttributes( $state.attr );
			},
			// Set the playhead direction
			playhead : function( $data ) {
				if ( !!$data )
					this.$node().data( 'playhead', $data );
				return this.$node().data( 'playhead' );
			},
			// The current state name
			stateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'currentState', $stateName );
				return this.$node().data( 'currentState' );
			},
			// The state name this node is currently transitioning to
			// or has transitioned to (if stateName === nextStateName)
			nextStateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'nextState', $stateName );
				return this.$node().data( 'nextState' );
			},
			// Applies a given list of properties to the node via animation.
			applyProperties : function( $props, $state ) {
				if ( !!$props && $props.props )
					types.tween.animate( this.node, $props.props, ( !!$state ? $state.duration : null ), ( !!$state ? $state.easing : null ), ( !!$state ? $state.complete : null ) );
			},
			// Applies attributes to the current node (currently, only anchoring is supported)
			applyAttributes : function( $attr ) {
				if ( $attr == null || this.parentNode().length < 1 ) return;
				if ( $attr.anchor != null && $attr.anchor.constructor == Array ) {
					var $a = $attr.anchor.slice(0);
					switch ( $a.length ) {
						case 1:
							var v = $a[0];
							$a = [v,v,v,v];
							break;
						case 2:
							var v = $a[0], w = $a[1];
							$a = [v,w,v,w];
							break;
						case 3:
							$a[3] = $a[2];
							break;
						default:
							break;
					}
					var p = this.$node().parent();
					var t = this.$node();
					var top = ( isNaN( parseInt( t.css( 'top' ), 10 ) ) ) ? 0 : parseInt( t.css( 'top' ), 10 );
					var left = ( isNaN( parseInt( t.css( 'left' ), 10 ) ) ) ? 0 : parseInt( t.css( 'left' ), 10 );
					var loc = [top, p.width() - t.width() - left, p.height() - t.height() - top, left];
					p.resize( function() {
						if ( $a[1] != 0 ) {
							if ( $a[3] != 0 )
								t.width( p.width() - left - loc[1] );
							else
								t.css( { left: p.width() - t.width() - loc[1] } );
						}
						if ( $a[2] != 0 ) {
							if ( $a[0] != 0 )
								t.height( p.height() - top - loc[2] );
							else
								t.css( { top: p.height() - t.height() - loc[2] } );
						}
					} );
				} else if ( $attr.center != null && typeof $attr.center == 'string' ) {
					this.center( $attr.center );
				}
				// Set an element as draggable
				if ( $attr.drag ) { if ( $attr.drag !== false ) {
					// We need to make sure that no more than one event for drag and drop are called
					if ( $attr.drag.onDrag )  {
						$.fn.fluxui.evt().unbind( this.$node(), 'dragged', $attr.drag.onDrag );
						$.fn.fluxui.evt().bind( this.$node(), 'dragged', $attr.drag.onDrag );
					}
					if ( $attr.drag.onDrop ) {
						$.fn.fluxui.evt().unbind( this.$node(), 'dropped', $attr.drag.onDrop );
						$.fn.fluxui.evt().bind( this.$node(), 'dropped', $attr.drag.onDrop );
					}
					// Check for mobile events support, else use mouse events
					if ( this.eventSupport( 'touchstart' ) === true ) {
						this.$node().unbind( 'touchstart', this.dragHandler ) // Reset to avoid multiples when using 'overlay'
						this.$node().bind( 'touchstart', { params : $attr.drag, caller : this, mobile : true }, this.dragHandler );
					} else {
						this.$node().unbind( 'mousedown', this.dragHandler ) // Reset to avoid multiples when using 'overlay'
						this.$node().bind( 'mousedown', { params : $attr.drag, caller : this }, this.dragHandler );
					}
				} }
				// Applying swipe and touch detection for mobile browsers
				if ( $attr.touch || $attr.swipe ) {
					if ( $attr.touch )
						$.fn.fluxui.evt().bind( this.$node(), 'touched', $attr.touch );
					if ( $attr.swipe ) {
						$.fn.fluxui.evt().bind( this.$node(), 'swiped', $attr.swipe, types.element.touches );
						//$.fn.fluxui.evt().addListener( $attr.swipe, function( a, b ){
						//	for ( i in b )
						//		window.alert( i );
						//} );
					}
					this.$node().bind( 'touchstart', this.swipeStart );
					this.$node().bind( 'touchmove', this.swipeMove );
					this.$node().bind( 'touchend', { caller : this }, this.swipeEnd );
				}
				// Give an element a class
				if ( !!$attr.__class ) {
					this.$node().addClass( $attr.__class );
				}
				// Set element's id
				if ( !!$attr.__id ) {
					this.$node().attr( 'id', $attr.__id );
				}
			},
			// Mouse dragging handler
			dragHandler : function( $event ) {
				var sk = $event.shiftKey, d = $event.data, c = d.caller,
				    m = d.mobile, mp = c.mousePosition( $event ), p = ( typeof d.params === 'object' ) ? d.params : {},
				    r = p.restraint || c.parentInstance().$node().attr( 'fluxid' ), t = p.target; 
				if ( m !== true ) $event.preventDefault();
				c.select( c, sk, t );
				if ( sk === false ) {
				// Starting positions
					for ( t in types.element.targets ) {
						types.element.targetsRelativePos.x[t] = mp.x - parseInt( types.element.targets[t].css( 'left' ) );
						types.element.targetsRelativePos.y[t] = mp.y - parseInt( types.element.targets[t].css( 'top' ) );
						types.element.targets[t].trigger( 'dragged' ); // Trigger for each target with an 'onDrag'
					}
					var data = { c : c, r : r, sk : sk };
					if ( m === true ) {
						$( 'body' ).bind( 'touchmove', data, c.moveHandler );
						$( 'body' ).bind( 'touchend', data, c.dropHandler );
					} else {
						$( 'body' ).bind( 'mousemove', data, c.moveHandler );
						$( 'body' ).bind( 'mouseup', data, c.dropHandler );
					}
				}
				if ( $event )
					$event.stopPropagation();
				if ( window.event )
					window.event.cancelBubble = true;
			},
			moveHandler : function( $event ) {
				$event.preventDefault();
				var c = $event.data.c, r = $event.data.r, mp = c.mousePosition( $event );
				$( 'body' ).css( 'cursor', 'move' );
				var move = c.move( r, mp );
				if ( move === 'drop' )
					c.dropHandler( $event );
			},
			dropHandler : function( $event ) {
				var d = $event.data, c = d.c, r = d.r, sk = d.sk;
				if ( sk === false ) {
					c.positionWithinRestraint( r );
					for ( t in types.element.targets )
						types.element.targets[t].fadeTo( 0, 1 );
					$( 'body' ).unbind( 'touchmove', c.moveHandler );
					$( 'body' ).unbind( 'touchstop', c.dropHandler );
					$( 'body' ).unbind( 'mousemove', c.moveHandler );
					$( 'body' ).unbind( 'mouseup', c.dropHandler );
					$( 'body' ).css( 'cursor', 'default' );
				}
				if ( $event )
					$event.stopPropagation();
				if ( window.event )
					window.event.cancelBubble = true;

				if ( $event.ctrlKey === true ) {
					for ( i = 0; i < 12; i++ )
						c.move( false, false, { x : 40, y : -4 } );
					c.positionWithinRestraint( r );
				}
				
			},
			// Returns mouse position for both desktop and mobile browsers
			mousePosition : function( $event ) {
				var e = $event ? $event : window.event,
				    m = this.eventSupport( 'touchstart' );
				return {
					x : m === true ? e.originalEvent.touches[0].pageX : e.pageX,
					y : m === true ? e.originalEvent.touches[0].pageY : e.pageY
			   	}
			},
			// Selects elements to be manipulated. Arguments: element, multiselect, target
			select : function( $c, $ms, $t ) {
				if ( !$t ) $t = $c.$node().attr( 'fluxid' );
				if ( !$ms || $ms === false )
					$c.clearTargets;
				$c.addTargets( $t );
			},
			// Defining edges of movement relative to the document
			restrain : function( $r ) {
				if ( !$r || $r === false )
					var $r = [-99999,99999,-99999,99999];
				else if ( typeof $r === 'string' ) {
					$r = $( '[fluxid="' + $r + '"]' );
					var o = $r.offset();
					$r = [ o.left, o.left + $r.outerWidth(), o.top, o.top + $r.outerHeight()];
				}
				return $r;
			},
			// Moves elements ( also should drop if mouse goes offscreen ) Arguments: restraint (array of left, right,
			// top, bottom), mouse position (relative to document or false), movement (relative to targets or undefined)
			move : function( $r, $mp, $m ) {
				$r = this.restrain( $r );
				if ( $mp !== false ) {
					if ( $mp.x >= $r[0] && $mp.x > 10 && $mp.x <= $r[1] && $mp.y >= $r[2] && $mp.y > 10 && $mp.y <= $r[3] )
						for ( t in types.element.targets ) {
							types.element.targets[t].fadeTo( 0, 0.6 );
							types.element.targets[t].css( 'left', $mp.x - types.element.targetsRelativePos.x[t] );
							types.element.targets[t].css( 'top', $mp.y - types.element.targetsRelativePos.y[t] );
						}
					else return 'drop';	
				} else if ( $m )
					for ( t in types.element.targets ) {
						types.element.targets[t].css( 'left', parseInt( types.element.targets[t].css( 'left' ) ) + $m.x ) ;
						types.element.targets[t].css( 'top', parseInt( types.element.targets[t].css( 'top' ) ) + $m.y ) ;
					}
			},
			// Positions elements if they fall outside of restraint
			positionWithinRestraint : function( $r ) {
				var targs = types.element.targets;
				$r = this.restrain( $r );
				for ( t in targs ) {
					var targ = targs[t], o = targ.offset(), diff = 0; 
					targ.trigger( 'dropped' );
					if ( o.left > $r[1] ) {
						diff = o.left - $r[1] + 5;
						targ.css( 'left', parseInt( targ.css( 'left' ) ) - diff )
					} else if ( o.left + targ.width() < $r[0] ) {
						diff = $r[0] - o.left - targ.width() + 5;
						targ.css( 'left', parseInt( targ.css( 'left' ) ) + diff )
					}
					if ( o.top > $r[3] ) {
						diff = o.top - $r[3] + 5;
						targ.css( 'top', parseInt( targ.css( 'top' ) ) - diff )
					} else if ( o.top + targ.height() < $r[2] ) {
						diff = $r[2] - o.top - targ.height() + 5;
						targ.css( 'top', parseInt( targ.css( 'top' ) ) + diff )
					}
				}
			},
			// Sets elements to be effected by drag
			addTargets : function( $t ) {
				var pushIt = true;
				if ( typeof $t === 'string' )
					for ( ct in types.element.targets ) {
						if ( types.element.targets[ct].attr( 'fluxid' ) ===  $t )
							var pushIt = false;
					}
					if ( pushIt === true )
						types.element.targets.push( $( '[fluxid="' + $t + '"]' ) );
				else
					for ( t in $t ) {
						for ( ct in types.element.targets )
							if ( types.element.targets[ct].attr( 'fluxid' ) ===  $t[t] )
								var pushIt = false;
						if ( pushIt === true )
							types.element.targets.push( $( '[fluxid="' + $t[t] + '"]' ) );
					}
			},
			clearTargets : function() {
				types.element.targets = [];
				types.element.targetsRelativePos = { x : [], y : [] };
			},
			sortTargets : function( $evt ) {
				var ts = types.element.targets, nts = [];
				nts.splice(0, 0, ts[0] );
				if ( $evt === 'x' )
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
							for ( nt in nts )
								if ( parseInt( ts[t].css( 'left' ) ) + ( ts[t].outerWidth() / 2 ) < parseInt( nts[nt].css( 'left' ) ) + ( nts[nt].outerWidth() / 2 ) ) {
									nts.splice( nt, 0, ts[t] );
									break;
								} else if ( nt == nts.length - 1 && t != 0 )
									nts.splice( nt + 1, 0, ts[t] );
				if ( $evt === 'y' )
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
							for ( nt in nts )
								if ( parseInt( ts[t].css( 'top' ) ) + ( ts[t].outerHeight() / 2 ) < parseInt( nts[nt].css( 'top' ) ) + ( nts[nt].outerHeight() / 2 ) ) {
									nts.splice( nt, 0, ts[t] );
									break;
								} else if ( nt == nts.length - 1 && t != 0 )
									nts.splice( nt + 1, 0, ts[t] );
				return nts;
			},
			// Detect browser support for events ( used to detect mobiles, among other things )
			// Does not work for detecting 'contextMenu' in Opera as this is too convoluted
			eventSupport : function( $eventName ) {
				var el = document.createElement('div');
				$eventName = 'on' + $eventName;
				var isSupported = ( $eventName in el );
				if ( !isSupported ) {
					el.setAttribute( $eventName, 'return;' );
					isSupported = typeof el[$eventName] === 'function';
				}
				el = null;
				return isSupported;
			},
			// Gets the start state of one or more finger actions on a mobile
			swipeStart : function( $event ) {
				types.element.touches = $event.originalEvent.touches;
				for ( f=0; f < types.element.touches.length; f++ ) {
					types.element.touches[f].x1 = types.element.touches[f].pageX;
					types.element.touches[f].y1 = types.element.touches[f].pageY;
				}
			},
			// Updates the state of one or more finger actions on a mobile
			swipeMove : function( $event ) {
				for ( f=0;  f < types.element.touches.length; f++ ) {
					types.element.touches[f].x2 = $event.originalEvent.touches[f].pageX;
					types.element.touches[f].y2 = $event.originalEvent.touches[f].pageY;
				}
			},
			// Calculates the end state of one or more finger actions on a mobile
			swipeEnd : function( $event, $dist ) {
				var swipe = true, $dist = $dist || 72
				for ( f=0; f < types.element.touches.length; f++ )
					if ( types.element.touches[f].x2 ) {
						types.element.touches[f] = $event.data.caller.distanceAngle( types.element.touches[f] );
						if ( !types.element.touches[f].d || types.element.touches[f].d < $dist )
							swipe = false;
					}
				if ( swipe === true ) $event.data.caller.$node().trigger( 'swiped', types.element.touches );
				else $event.data.caller.$node().trigger( 'touched', types.element.touches );
			},
			// Returns distance and angle when passed an object with four positional values
			distanceAngle : function( $f ) {
				$f.d = Math.round( Math.sqrt( Math.pow( $f.x1 - $f.x2, 2 ) + Math.pow( $f.y1 - $f.y2, 2 ) ) );
				$f.a = Math.atan2( $f.y1 - $f.y2, $f.x1 - $f.x2 );
				return $f;
			},
			// Centres the element
			center : function( $type ) {
				var p = this.$node().parent();
				var t = this.$node();
				p.resize( function() {
					if ( $type == 'horz' || $type == 'both' ) {
						t.css( 'left', ( p.outerWidth() - t.outerWidth() ) / 2 );
					} if ( $type == 'vert' || $type == 'both' ) {
						t.css( 'top', ( p.outerHeight() - t.outerHeight() ) / 2 );
					}
				} );
				p.trigger( 'resize' );
			},
			setRect : function( $x, $y, $width, $height ) {
				this.applyProperties( { props: { left: $x, top: $y, width: $width, height: $height } } );
			},
			// Sets the nodes background gradient (do not call directly. Call setStyle, instead).
			setBackground : function( $colors, $fillType ) {
				$fillType = $fillType || 'solid';
				$colors = types.color.arrayOfColors($colors);
				if ( !this.data().fill )
					this.data().fill = {};
				this.data().fill.colors = $colors;
				for ( var i = 0; i < $colors.length; i++ )
					if ( !$colors[i].rgb )
						$colors[i] = { rgb : $colors[i].slice(0), opacity : 0 };
				var bg = types.style.normaliseFill( { type : $fillType, colors : $colors } );
				this.$node().css( 'filter', bg.filter );
				for ( var c = 0; c < bg.background.length; c++ )
					this.$node().css( 'background', bg.background[c] );
				this.props.fill = this.props.fill || {};
				this.props.fill.colors = [ $colors[0], $colors[1] ];
				this.props.fill.type = $fillType;
			},
			// Sets the nodes border radius (do not call directly. Call setStyle, instead).
			setBorderRadius : function( $radius ) {
				//$radius = types.style.normaliseBorder( $radius );
				this.$node().css( 'border-radius', Math.round( $radius ) );
				this.props['border-radius'] = $radius;
			},
			setBorderColor : function( $color ) {
				if ( typeof $color == 'object' && $color.rgb != null )
					$color.rgb = types.color.RGBAToString( $color.rgb );
				this.$node().css( 'border-color', $color );
				this.props['border-color'] = $color;
			},
			// Sets a style on the node
			setStyle : function( $prop, $value ) {
				switch( $prop ) {
					case 'background-image' :
						if ( !$value ) return;
						var type = $value.type || 'solid';
						this.setBackground( $value, type );
						break;
					case 'border-radius' :
						this.setBorderRadius( $value );
						break;
					case 'border-color' :
						this.setBorderColor( $value );
						break;
					default :
						this.props[$prop] = $value;
						if ( typeof $value == 'object' && $value.rgb != null )
							$value.rgb = types.color.RGBAToString( $value.rgb );
						if ( types.style.isNumeric( $prop ) )
							$value = $value + 'px';
						this.$node().css( $prop, $value );
						break;
				}
			},
			// Correcting odd typeof functionality
			getTypeofObject : function( $value ) {
				var objectType = typeof $value;
				if ( objectType === "object" ) {
					if ( $value )
						if ( $value instanceof Array )
							objectType = "array";
					else
						objectType = "null";
				}
				return objectType;
			},
			// Performs a given action (from string)
			doAction : function( $action, $data, $e ) {
				this[$action]( $data, $e );
			},
			// Action. Do not call directly (call gotoNextState)
			play : function() {
				if ( this.playhead().direction == 1 )
					this.gotoNextState();
				else
					this.gotoPrevState();
			},
			// Action. Do not call directly (call gotoState)
			gotoFrame : function( $data ) {
				this.gotoState( $data.frameId );
			},
			// Action.
			gotoUrl : function( $data ) {
				if ( $data.target == "_blank" )
					window.open( $data.url, '_blank' );
				else
					window.location.href = $data.url;
			},
			// Transitions the node to the next state in the state list
			gotoNextState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i >= d.frames.keys.length - 1 ) ? d.frames.keys[0] : d.frames.keys[i + 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
				this.playhead().direction = 1;
			},
			// Transitions the node to the previous state in the state list
			gotoPrevState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i <= 0 ) ? d.frames.keys[d.frames.keys.length - 1] : d.frames.keys[i - 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
				this.playhead().direction = 0;
			},
			// Transitions the node to a given state
			gotoState : function( $state ) {
				var d = this.data();
				var s = '_default';
				if ( !!d && !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == $state ) {
							s = d.frames.keys[i];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
			},
			// Handles the state change (do not call directly).
			changeState : function( $stateName, $stateData ) {

				// if the previous state and current state match, then there's nothing to do
				if ( $stateName == this.stateName() )
					return;

				// if we have no frames or children, theres no point continuing
				if ( !( !!$stateData.frames && !!$stateData.frames.hash[$stateName] && !!$stateData.children ) ) 
					return;

				// set base transform values
				var duration = $.fn.fluxui.settings.defaultTransform.duration;
				var easing = $.fn.fluxui.settings.defaultTransform.easing;
				var completeAction = $.fn.fluxui.settings.defaultTransform.after;

				// store the new state names for merging
				var nextStateNames = [];
				nextStateNames.push( "_default" );
				if ( $stateName != "_default" )
					nextStateNames.push( $stateName );

				var curStateNames = [];
				if ( !!this.stateName() ) {
					curStateNames.push( "_default" );
					if ( this.stateName() != "_default" )
						curStateNames.push( this.stateName() );
				}

				// get the next state data
				var nextState = $stateData.frames.hash[$stateName];

				// if the next state has a transition, lets update the default transition values
				if ( !!nextState.transition ) {
					duration = nextState.transition.duration || duration;
					easing = nextState.transition.easing || easing;
					completeAction = nextState.transition.after || completeAction;
				}

				// once the transition is over, we're probably going to have a transition complete action
				// on the parent, so we need to setup a callback to handle this.
				var me = this;
				var callback = function() {
					if ( !!me  && !!me.pendingAction ) {
						me.stateName( $stateName );
						var pa = me.pendingAction;
						delete me.pendingAction;

						me.doAction( pa );
					}
				};

				// if the parent has a pending action (when the transition is complete), let's set that now.
				if ( completeAction != "stop" )
					this.pendingAction = completeAction;

				// now we know what our transition parameters will be, let's enforce them on the state object
				var transition = { duration : duration, easing : easing, complete : callback };

				// now for the intensive part.  we need to animate / transition the children.
				for ( c in $stateData.children.keys ) {
					var name = $stateData.children.keys[c];
					var child = $stateData.children.hash[name];

					// this will contain the prop values to transition
					var props = {};
					// and this will contain the current element props
					var curProps = {};

					if ( !!child.states ) {
						for ( var u in nextStateNames )
							if ( !!child.states[nextStateNames[u]] )
								$.extend( true, props, child.states[nextStateNames[u]] );
						for ( var u in curStateNames )
							if ( !!child.states[curStateNames[u]] )
								$.extend( true, curProps, child.states[curStateNames[u]] );
					}

					// get animate-able prop values where the previous state and next
					// state properties merge and differ
					var diff = {};

					if ( !types.style.getPropertyDiff( curProps, props, diff ) ) {
						this.stateName( $stateName );
						continue;
					}

					//types.style.normalisePropStack( diff.props );
					var n = types.element.getInstance( this.$node().find("[fluxid='" + name + "']") );
					this.stateName( $stateName );
					if ( !!n && !!n.applyProperties )
						n.applyProperties( diff, transition );
				}
			}
		},
		statics : {
			// Returns the passed $node's class instance.
			getInstance : function( $node ) {
				return $($node).data( 'currentInstance' );
			},
			make : function( $type, $state, $id ) {
				if ( !$id || $id == "" ) $id = $type + '_' + types.core.nextElementCounter();
				if ( !$state ) $state = {};
				return new types[$type]( $id, $state );
			},
			targets : [],
			// Relative to mouse move (for drag event handlers)
			targetsRelativePos : { x : [], y : [] },
			touches : {}
		}
	} );
	
} )(jQuery,this);