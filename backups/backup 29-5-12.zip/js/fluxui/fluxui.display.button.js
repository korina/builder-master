/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Button class (Lee, should this have 'fields.markup' as '<button />'?)
	 * Provides for mouse interactivity, complete with button specific states. 
	 * 
	 * Requires:
	 *		fluxui.display.element.js
	 **/
	$class.create( {
		namespace : 'button',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.entity( 'button' );
			this.$node().css( 'cursor', 'pointer' );
			this.$node().bind( 'mouseenter', { element : this, stateName : '_over', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseleave', { element : this, stateName : '_default', state : $state }, function( e ) {
				e.data.element.changeState( ( ( e.data.element.isSelected ) ? e.data.element.selectedState : e.data.stateName ), e.data.state );
			} ),
			this.$node().bind( 'mousedown', { element : this, stateName : '_down', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseup', { element : this, stateName : '_over', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} );
		},
		fields : {
			isSelected : false,
			selectedState : '_selected'
		},
		methods : {
			selected : function( set ) {
				this.isSelected = set;
				var state = ( set ) ? "_selected" : "_default";
				this.changeState( state, this.data );
			}
		}
	} );
	
} )(jQuery,this);