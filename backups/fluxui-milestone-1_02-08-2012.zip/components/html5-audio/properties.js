/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
		
	var props = {
		type: 'properties.html5-audio',
		initial: {
			props: {
				fill: {
					type: 'linear',
					direction: 'top',
					colors: [
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0
						}
					]
				},
				position: 'relative',
				width: 300,
				height: 160
			}
		},
		children: {
			keys: [ 'mp3', 'mp3-label', 'ogg', 'ogg-label', 'flash', 'flash-label' ],
			hash: {
				mp3: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 10,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-audio.mp3.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-audio.mp3'
						}
					}
				},
				'mp3-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 10,
							width: 50
						},
						attr: {
							text: 'MP3'
						}
					}
				},
				ogg: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 40,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-audio.ogg.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-audio.ogg'
						}
					}
				},
				'ogg-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 40,
							width: 50
						},
						attr: {
							text: 'OGG'
						}
					}
				},
				flash: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 70,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-audio.flash.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-audio.flash'
						}
					}
				},
				'flash-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 70,
							width: 50
						},
						attr: {
							text: 'Flash'
						}
					}
				}
			}
		}
	}
	
	/**
	 * HTML5 audio component property sheet class
	 * Provides functionality for the HTML5 audio property sheets.
	 **/
	var clazz = $.fn.fluxui.$class.create( {
		namespace : 'properties.html5-audio',
		inherits : types.properties.propsheet,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			ens : 'html5-audio'
		},
		methods : {
			updatePropertyFields : function( $cls, $prefix ) {
				var d = eventDispatcher;
				var s = $cls.states.getCurrentStateData();
				d.dispatch( this, $prefix + '.mp3.changed', s.attr.mp3 );
				d.dispatch( this, $prefix + '.ogg.changed', s.attr.ogg );
				d.dispatch( this, $prefix + '.flash.changed', s.attr['flash-player'] );
			},
			handlePropertyChange : function( $control ) {
				if ( this.selection._targets.length < 1 ) return;
				var t = types.display.element.getInstance( this.selection.targets(0).get(0) ),
					i = this.manipulator,
					n = parseInt( $control.val() ),
					s = $control.val(),
					fid = $control.attr( 'fluxid' );
				switch( fid ) {
					case 'mp3':
						t.setMp3( s );
						break;
					case 'ogg':
						t.setOgg( s );
						break;
					case 'flash':
						t.setFlash( s );
						break;
				}
			}
		},
		statics : {
			create : function() {
				var ns = 'html5-audio';
				types.serialiser.parse( ns + '.props', props, types.controls.properties.getInstance() );
			}
		}
	} );

} )(jQuery,this);