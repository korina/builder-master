/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	var clazz = $class.create( {
		namespace : 'html5-audio',
		inherits : types.display.component,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			isContainer : true,
			markup : '<audio />'
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				this.setMedia();
				var me = this;
				// Update the width and height of the Flash fallback without having to set seperatly in 'props' and 'attr'
				types.events.dispatcher.getInstance().addListener( 'stage.element.change', function() {
					me.setMedia();
				} );
			},
			setMedia : function( $mp3, $ogg, $flash ) {
				if ( !!$mp3 ) this.states.setAttributeOnCurrentState( 'mp3', $mp3 );
				if ( !!$ogg ) this.states.setAttributeOnCurrentState( 'ogg', $ogg );
				if ( !!$flash ) this.states.setAttributeOnCurrentState( 'flash-player', $flash );
				this.applyStateAttributes();
				var s = this.states.getCurrentStateData();
				$mp3 = s.attr.mp3;
				$ogg = s.attr.ogg;
				$flash = s.attr['flash-player'];
				this.$node().attr( 'controls', 'controls' );
				this.$node().html( // This method, as opposed to attributes, has wider browser support
					'<source fluxid="mp3" src="' + $mp3 + '" type="audio/mpeg" />' + // This has to come first for iOS3 support
					'<source fluxid="ogg" src="' + $ogg + '" type="audio/ogg" />' + // This is needed for native FF/Opera support
					// Flash fallback provides for non-HTML5 browsers
					'<object width="' + this.width() + '" height="' + this.height() + '" type="application/x-shockwave-flash" data="' + $flash + '">' +
						'<param name="movie" value="' + $flash + '" />' + // This is needed for certain IE browsers
						'<param name="FlashVars" value="height=' + this.height() + '&amp;showvolume&amp;width=' + this.width() + '&amp;mp3=' + $mp3 + '" />' +
					'</object>'
				);
				if ( !this.isPaused() )
					this.pause();
				this.refresh();
			},
			setMp3 : function( $mp3 ) {
				this.setMedia( $mp3 );
			},
			setOgg : function( $ogg ) {
				this.setMedia( null, $ogg );
			},
			setFlash : function( $flash ) {
				this.setMedia( null, null, $flash );
			},
			isPaused : function() {
				return this.$node()[0].paused;
			},
			pause : function() {
				return this.$node()[0].pause();
			},
			play : function() {
				return this.$node()[0].play();
			},
			stop : function() {
				return this.$node()[0].stop();
			},
			refresh : function() {
				return this.$node()[0].load();
			},
			currentTime : function( $t ) {
				if ( !isNaN( $t ) )
					this.$node()[0].currentTime = $t;
				return this.$node()[0].currentTime;
			},
			attribute : function( attr, value, updateState ) {
				if ( attr == 'mp3' || attr == 'ogg' || attr == 'flash-player' ) return "";
				return clazz.Super.attribute.call( this, attr, value, updateState );
			}
		}
	} );
	
} )(jQuery,this);
