{
	"movie" : {
		"type" : "display.container",
		"initial" : {
			"props" : {
				"width" : 400,
				"height" : 30
			}
		},
		"children" : {
			"keys" : [ "video" ],
			"hash" : {
				"video" : {
					"type" : "html5-audio",
					"initial" : {
						"props" : {
							"width" : 400,
							"height" : 30
						},
						"attr" : {
							"mp3" : "http://www.jplayer.org/audio/mp3/TSP-01-Cro_magnon_man.mp3",
							"ogg" : "http://www.jplayer.org/audio/ogg/TSP-01-Cro_magnon_man.ogg",
							"flash-player" : "http://flash-mp3-player.net/medias/player_mp3_maxi.swf"
						}
					}
				}
			}
		}
	}
}
