/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	var clazz = $class.create( {
		namespace : 'html5-video',
		inherits : types.display.component,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
			this.entity( 'html5-video' );
			var s = this.states.getCurrentStateData();
		},
		fields : {
			isContainer : true,
			markup : '<video />'
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				var s = this.states.getCurrentStateData();
				this.bindEvents(); // must call this in order to support the prop sheet
				this.setMedia( s.attr.mp4, s.attr.ogv, s.props.width, s.props.height, s.attr['flash-player'] );
				// Update the width and height of the Flash fallback without having to set seperatly in 'props' and 'attr'
				types.events.dispatcher.getInstance().addListener( 'stage.element.change', function() {
					this.setMedia( s.attr.mp4, s.attr.ogv, s.props.width, s.props.height, s.attr['flash-player'] );
				} );
			},
			// As 'poster' attr causes issues encodings need  to put poster as the first frames
			setMedia : function( $mp4, $ogv, $width, $height, $flash ) {
				this.$node().attr( 'controls', 'controls' );
				this.$node().append( // This method, as opposed to attributes, has wider browser support
					'<source src="' + $mp4 + '" type="video/mp4" />' + // This has to come first for iOS3 support
					'<source src="' + $ogv + '" type="video/ogg" />' + // This is needed for native FF/Opera/Chrome support
					// Flash fallback provides for non-HTML5 browsers
					'<object width="' + $width + '" height="' + $height + '" type="application/x-shockwave-flash" data="' + $flash + '">' +
						'<param name="movie" value="' + $flash + '" />' + // This is needed for certain IE browsers
						'<param name="flashvars" value="controlbar=over&amp;file="' + $mp4 + '" />' +
					'</object>'
				);
			},
			broadcast : function() {
				var s = this.states.getCurrentStateData();
				this.updatePropSheet( {
					ogv : s.attr.ogv,
					mp4 : s.attr.mp4,
					'flash-player' : s.attr['flash-player']
				} );
			},
			receive : function( $type, $data ) {
				var s = this.states;
				var d = s.getCurrentStateData();
				switch( $type ) {
					case 'ogv' :
					case 'mp4' :
					case 'flash-player' :
						s.setAttributeOnCurrentState( $type, $data );
						this.setMedia( d.attr.mp4, d.attr.ogv, d.props.width, d.props.height, d.attr['flash-player'] );
						break;
				}
			}
		}
	} );
	
} )(jQuery,this);
