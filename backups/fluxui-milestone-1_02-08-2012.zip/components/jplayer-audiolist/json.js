{
	"assets" : {
		"play.png" : {
			"url" : "jplayer_images/play.png",
			"height" : "28",
			"width" : "28"
		},
		"pause.png" : {
			"url" : "jplayer_images/pause.png",
			"height" : "28",
			"width" : "28"
		},
		"stop.png" : {
			"url" : "jplayer_images/stop.png",
			"height" : "28",
			"width" : "28"
		},
		"shuffle.png" : {
			"url" : "jplayer_images/shuffle.png",
			"height" : "20",
			"width" : "28"
		},
		"loop.png" : {
			"url" : "jplayer_images/loop.png",
			"height" : "26",
			"width" : "30"
		},
		"unloop.png" : {
			"url" : "jplayer_images/unloop.png",
			"height" : "26",
			"width" : "30"
		},
		"mute.png" : {
			"url" : "jplayer_images/mute.png",
			"height" : "28",
			"width" : "28"
		},
		"unmute.png" : {
			"url" : "jplayer_images/unmute.png",
			"height" : "28",
			"width" : "28"
		}
	},
	"library" : {},
	"movie" : {
		"type" : "display.container",
		"initial" : {
			"props" : {
				"overflow-y" : "hidden",
				"overflow-x" : "hidden",
				"top" : 0,
				"left" : 0,
				"height" : 600,
				"width" : 800,
				"border-radius" : 40,
				"fill" : {
					"type" : "solid",
					"colors" : [
						{
							"rgb" : "#343434",
							"opacity" : 1
						}
					]
				}
			}
		},
		"children" : {
			"keys" : ["audio-player-list"],
			"hash" : {
				"audio-player-list" : {
					"type" : "display.container",
					"initial" : {
						"props" : {
							"top" : 148,
							"height" : 304,
							"width" : 720,
							"left" : 40,
							"fill" : {
								"type" : "linear",
								"colors" : [
									{
										"rgb" : "#ffffff",
										"opacity" : 0.1
									}
								]
							},
							"border-radius" : 19
						},
						"attr" : {
							"id" : "jp_container_1",
							"class" : "jp-audio",
							"audiolist" : [
								{
									"title" :"Cro Magnon Man",
									"artist" :"The Stark Palace",
									"mp3" :"http://www.jplayer.org/audio/mp3/TSP-01-Cro_magnon_man.mp3",
									"oga" :"http://www.jplayer.org/audio/ogg/TSP-01-Cro_magnon_man.ogg",
									"poster" : "http://www.jplayer.org/audio/poster/The_Stark_Palace_640x360.png"
								},
								{
									"title" :"Your Face",
									"artist" :"The Stark Palace",
									"mp3" :"http://www.jplayer.org/audio/mp3/TSP-05-Your_face.mp3",
									"oga" :"http://www.jplayer.org/audio/ogg/TSP-05-Your_face.ogg",
									"poster" : "http://www.jplayer.org/audio/poster/The_Stark_Palace_640x360.png"
								},
								{
									"title" :"Hidden",
									"artist" :"Miaow",
									"mp3" :"http://www.jplayer.org/audio/mp3/Miaow-02-Hidden.mp3",
									"oga" :"http://www.jplayer.org/audio/ogg/Miaow-02-Hidden.ogg",
									"poster" : "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
								},
								{
									"title" :"Tempered Song",
									"artist" :"Miaow",
									"mp3" :"http://www.jplayer.org/audio/mp3/Miaow-01-Tempered-song.mp3",
									"oga" :"http://www.jplayer.org/audio/ogg/Miaow-01-Tempered-song.ogg",
									"poster" : "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
								},
								{
									"title" :"Lentement",
									"artist" :"Miaow",
									"mp3" :"http://www.jplayer.org/audio/mp3/Miaow-03-Lentement.mp3",
									"oga" :"http://www.jplayer.org/audio/ogg/Miaow-03-Lentement.ogg",
									"poster" : "http://www.jplayer.org/audio/poster/Miaow_640x360.png"
								}
							]
						}
					},
					"children" : {
						"keys" : ["playlist-audio2", "controls-audio2"],
						"hash" : {
							"playlist-audio2" : {
								"type" : "display.container",
								"initial" : {
									"attr" : {
										"class" : "jp-playlist"
									},
									"props" : {
										"height" : 300,
										"width" : 720,
										"overflow" : "auto",
										"border-radius" : 19
									}
								},
								"children" : {
									"keys" : ["tracks-audio2"],
									"hash" : {
										"tracks-audio2" : {
											"type" : "unorderedList",
											"initial" : {
												"props" : {
													"margin-left" : 0,
													"padding-top" : 45,
													"padding-left" : 0,
													"width" : 680,
													"border-radius" : 12,
													"color" : "#cecece",
													"list-style-type" : "none"
												},
												"attr" : {
													"class" : "jp-playlist-ul"
												}
											},
											"children" : {
												"keys" : ["dummy-item-audio2", "dummy-hover-audio2", "dummy-current-parent-audio2"],
												"hash" : {
													"dummy-item-audio2" : {
														"type" : "item",
														"initial" : {
															"props" : {
																"position" : "relative",
																"display" : "block",
																"height" : 16,
																"left" : 5,
																"padding-top" : 12,
																"padding-right" : 12,
																"padding-bottom" : 12,
																"padding-left" : 12,
																"fill" : {
																	"type" : "linear",
																	"colors" : [
																		{
																			"rgb" : "#000000",
																			"opacity" : 0.2
																		}
																	]
																},
																"color" : "#efefef",
																"left" : 20,
																"text-decoration" : "none"
															},
															"attr" : {
																"class" : "playlistbase",
																"text" : "This sets default list item style"
															}
														}
													},
													"dummy-hover-audio2" : {
														"type" : "item",
														"initial" : {
															"props" : {
																"position" : "relative",
																"display" : "block",
																"height" : 16,
																"left" : 5,
																"padding-top" : 12,
																"padding-right" : 12,
																"padding-bottom" : 12,
																"padding-left" : 12,
																"fill" : {
																	"type" : "linear",
																	"colors" : [
																		{
																			"rgb" : "#444444",
																			"opacity" : 0.25
																		}
																	]
																},
																"color" : "#dd00aa",
																"left" : 20,
																"text-decoration" : "none"
															},
															"attr" : {
																"class" : "playlisthover",
																"text" : "This sets style for list item being hovered over"
															}
														}
													},
													"dummy-current-parent-audio2" : {
														"type" : "item",
														"initial" : {
															"props" : {
																"position" : "relative",
																"display" : "block",
																"height" : 16,
																"left" : 5,
																"padding-top" : 12,
																"padding-right" : 12,
																"padding-bottom" : 12,
																"padding-left" : 12,
																"fill" : {
																	"type" : "linear",
																	"colors" : [
																		{
																			"rgb" : "#000000",
																			"opacity" : 0.2
																		}
																	]
																},
																"color" : "#efefef",
																"left" : 20,
																"text-decoration" : "none"
															}
														},
														"children" : {
															"keys" : ["dummy-current-audio2"],
															"hash" : {
																"dummy-current-audio2" : {
																	"type" : "display.label",
																	"initial" : {
																		"props" : {
																			"position" : "relative",
																			"left" : 15,
																			"color" : "#dd00aa"
																		},
																		"attr" : {
																			"class" : "playlistcurrent",
																			"text" : "This sets style for currently playing list item"
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							},
							"controls-audio2" : {
								"type" : "display.container",
								"initial" : {
									"props" : {
										"height" : 40,
										"width" : 720,
										"fill" : {
											"type" : "linear",
											"colors" : [
												{
													"rgb" : "#bbbbbb",
													"opacity" : 1
												},
												{
													"rgb" : "#ffffff",
													"opacity" : 1
												}
											]
										},
										"border-radius" : 19
									}
								},
								"children" : {
									"keys" : ["player-audio2", "stop-audio2", "pause-audio2", "play-audio2", "progress-audio2", "loop-audio2", "unloop-audio2", "mute-audio2", "unmute-audio2", "volume-audio2"],
									"hash" : {
										"player-audio2" : {
											"type" : "display.container",
											"initial" : {
												"attr" : {
													"id" : "jquery_jplayer_1",
													"class" : "jp-player"
												}
											}
										},
										"stop-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 6,
													"height" : 28,
													"width" : 28,
													"left" : 6,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-stop",
													"src" : "stop.png"
												}
											}
										},
										"pause-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 6,
													"height" : 28,
													"width" : 28,
													"left" : 40,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-pause",
													"src" : "pause.png"
												}
											}
										},
										"play-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 6,
													"height" : 28,
													"width" : 28,
													"left" : 40,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-play",
													"src" : "play.png"
												}
											}
										},
										"progress-audio2" : {
											"type" : "display.container",
											"initial" : {
												"props" : {
													"top" : 7,
													"left" : 76,
													"height" : 26,
													"width" : 461,
													"border-radius" : 14,
													"cursor" : "pointer",
													"fill" : {
														"type" : "solid",
														"colors" : [
															{
																"rgb" : "#efefef",
																"opacity" : 1
															}
														]
													}
												},
												"attr" : {
													"class" : "jp-progress"
												}
											},
											"children" : {
												"keys" : ["seek-bar-audio2", "current-time-audio2", "duration-audio2"],
												"hash" : {
													"seek-bar-audio2" : {
														"type" : "display.container",
														"initial" : {
															"props" : {
																"height" : 26,
																"width" : 461
															},
															"attr" : {
																"class" : "jp-seek-bar"
															}
														},
														"children" : {
															"keys" : ["play-bar-audio2"],
															"hash" : {
																"play-bar-audio2" : {
																	"type" : "display.container",
																	"initial" : {
																		"props" : {
																			"height" : 26,
																			"border-radius" : 14,
																			"fill" : {
																				"type" : "solid",
																				"colors" : [
																					{
																						"rgb" : "#343434",
																						"opacity" : 1
																					}
																				]
																			}
																		},
																		"attr" : {
																			"class" : "jp-play-bar"
																		}
																	}
																}
															}
														}
													},
													"current-time-audio2" : {
														"type" : "display.label",
														"initial" : {
															"props" : {
																"top" : 8,
																"left" : 10,
																"font-size" : 11,
																"font-weight" : "bold",
																"line-height" : 11,
																"color" : "#dd00aa"
															},
															"attr" : {
																"class" : "jp-current-time"
															}
														}
													},
													"duration-audio2" : {
														"type" : "display.label",
														"initial" : {
															"props" : {
																"top" : 8,
																"left" : 424,
																"font-size" : 11,
																"font-weight" : "bold",
																"line-height" : 11,
																"color" : "#dd00aa"
															},
															"attr" : {
																"class" : "jp-duration"
															}
														}
													}
												}
											}
										},
										"loop-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 7,
													"height" : 26,
													"width" : 30,
													"left" : 543,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-repeat",
													"src" : "loop.png"
												}
											}
										},
										"unloop-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 7,
													"height" : 26,
													"width" : 30,
													"left" : 543,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-repeat-off",
													"src" : "unloop.png"
												}
											}
										},
										"mute-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 6,
													"height" : 28,
													"width" : 28,
													"left" : 578,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-mute",
													"src" : "mute.png"
												}
											}
										},
										"unmute-audio2" : {
											"type" : "display.image",
											"initial" : {
												"props" : {
													"top" : 6,
													"height" : 28,
													"width" : 28,
													"left" : 578,
													"cursor" : "pointer"
												},
												"attr" : {
													"class" : "jp-unmute",
													"src" : "unmute.png"
												}
											}
										},
										"volume-audio2" : {
											"type" : "display.container",
											"initial" : {
												"props" : {
													"top" : 7,
													"left" : 612,
													"height" : 26,
													"width" : 100,
													"border-radius" : 14,
													"cursor" : "pointer",
													"fill" : {
														"type" : "solid",
														"colors" : [
															{
																"rgb" : "#efefef",
																"opacity" : 1
															}
														]
													}
												},
												"attr" : {
													"class" : "jp-volume-bar"
												}
											},
											"children" : {
												"keys" : ["set-volume-audio2"],
												"hash" : {
													"set-volume-audio2" : {
														"type" : "display.container",
														"initial" : {
															"props" : {
																"height" : 26,
																"border-radius" : 14,
																"fill" : {
																	"type" : "solid",
																	"colors" : [
																		{
																			"rgb" : "#343434",
																			"opacity" : 1
																		}
																	]
																}
															},
															"attr" : {
																"class" : "jp-volume-bar-value"
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
