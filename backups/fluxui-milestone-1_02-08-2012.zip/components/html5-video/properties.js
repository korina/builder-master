/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
		
	var props = {
		type: 'properties.html5-video',
		initial: {
			props: {
				fill: {
					type: 'linear',
					direction: 'top',
					colors: [
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0
						}
					]
				},
				position: 'relative',
				width: 300,
				height: 160
			}
		},
		children: {
			keys: [ 'mp4', 'mp4-label', 'ogv', 'ogv-label', 'flash', 'flash-label' ],
			hash: {
				mp4: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 10,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-video.mp4.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-video.mp4'
						}
					}
				},
				'mp4-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 10,
							width: 50
						},
						attr: {
							text: 'MP4'
						}
					}
				},
				ogv: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 40,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-video.ogv.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-video.ogv'
						}
					}
				},
				'ogv-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 40,
							width: 50
						},
						attr: {
							text: 'OGV'
						}
					}
				},
				flash: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 70,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.html5-video.flash.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.html5-video.flash'
						}
					}
				},
				'flash-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 70,
							width: 50
						},
						attr: {
							text: 'Flash'
						}
					}
				}
			}
		}
	}
	
	/**
	 * HTML5 video component property sheet class
	 * Provides functionality for the HTML5 video property sheets.
	 **/
	var clazz = $.fn.fluxui.$class.create( {
		namespace : 'properties.html5-video',
		inherits : types.properties.propsheet,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			ens : 'html5-video'
		},
		methods : {
			updatePropertyFields : function( $cls, $prefix ) {
				var d = eventDispatcher;
				var s = $cls.states.getCurrentStateData();
				d.dispatch( this, $prefix + '.mp4.changed', s.attr.mp4 );
				d.dispatch( this, $prefix + '.ogv.changed', s.attr.ogv );
				d.dispatch( this, $prefix + '.flash.changed', s.attr['flash-player'] );
			},
			handlePropertyChange : function( $control ) {
				if ( this.selection._targets.length < 1 ) return;
				var t = types.display.element.getInstance( this.selection.targets(0).get(0) ),
					i = this.manipulator,
					n = parseInt( $control.val() ),
					s = $control.val(),
					fid = $control.attr( 'fluxid' );
				switch( fid ) {
					case 'mp4':
						t.setMp4( s );
						break;
					case 'ogv':
						t.setOgv( s );
						break;
					case 'flash':
						t.setFlash( s );
						break;
				}
			}
		},
		statics : {
			create : function() {
				var ns = 'html5-video';
				types.serialiser.parse( ns + '.props', props, types.controls.properties.getInstance() );
			}
		}
	} );

} )(jQuery,this);