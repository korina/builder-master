{
	"movie" : {
		"type" : "display.container",
		"initial" : {
			"props" : {
				"height" : 300,
				"width" : 400
			}
		},
		"children" : {
			"keys" : [ "video" ],
			"hash" : {
				"video" : {
					"type" : "html5-video",
					"initial" : {
						"props" : {
							"width" : 400,
							"height" : 300
						},
						"attr" : {
							"mp4" : "http://www.jplayer.org/video/m4v/Big_Buck_Bunny_Trailer.m4v",
							"ogv" : "http://www.jplayer.org/video/ogv/Big_Buck_Bunny_Trailer.ogv",
							"flash-player" : "http://camendesign.com/code/video_for_everybody/player.swf"
						}
					}
				}
			}
		}
	}
}
