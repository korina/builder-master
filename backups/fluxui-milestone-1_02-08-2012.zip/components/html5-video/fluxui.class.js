/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	var clazz = $class.create( {
		namespace : 'html5-video',
		inherits : types.display.component,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			isContainer : true,
			markup : '<video />'
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				this.setMedia();
				var me = this;
				// Update the width and height of the Flash fallback without having to set seperatly in 'props' and 'attr'
				types.events.dispatcher.getInstance().addListener( 'stage.element.change', function() {
					me.setMedia();
				} );
			},
			// As 'poster' attr causes issues encodings need  to put poster as the first frames
			setMedia : function( $mp4, $ogv, $flash ) {
				if ( !!$mp4 ) this.states.setAttributeOnCurrentState( 'mp4', $mp4 );
				if ( !!$ogv ) this.states.setAttributeOnCurrentState( 'ogv', $ogv );
				if ( !!$flash ) this.states.setAttributeOnCurrentState( 'flash-player', $flash );
				this.applyStateAttributes();
				var s = this.states.getCurrentStateData();
				$mp4 = s.attr.mp4;
				$ogv = s.attr.ogv;
				$flash = s.attr['flash-player'];
				this.$node().attr( 'controls', 'controls' );
				this.$node().html( // This method, as opposed to attributes, has wider browser support
					'<source src="' + $mp4 + '" type="video/mp4" />' + // This has to come first for iOS3 support
					'<source src="' + $ogv + '" type="video/ogg" />' + // This is needed for native FF/Opera/Chrome support
					// Flash fallback provides for non-HTML5 browsers
					'<object width="' + this.width() + '" height="' + this.height() + '" type="application/x-shockwave-flash" data="' + $flash + '">' +
						'<param name="movie" value="' + $flash + '" />' + // This is needed for certain IE browsers
						'<param name="flashvars" value="controlbar=over&amp;file=' + $mp4 + '" />' +
					'</object>'
				);
				if ( !this.isPaused() )
					this.pause();
				this.refresh();
			},
			setMp4 : function( $mp4 ) {
				this.setMedia( $mp4 );
			},
			setOgv : function( $ogv ) {
				this.setMedia( null, $ogv );
			},
			setFlash : function( $flash ) {
				this.setMedia( null, null, $flash );
			},
			isPaused : function() {
				return this.$node()[0].paused;
			},
			pause : function() {
				return this.$node()[0].pause();
			},
			play : function() {
				return this.$node()[0].play();
			},
			stop : function() {
				return this.$node()[0].stop();
			},
			refresh : function() {
				return this.$node()[0].load();
			},
			currentTime : function( $t ) {
				if ( !isNaN( $t ) )
					this.$node()[0].currentTime = $t;
				return this.$node()[0].currentTime;
			},
			attribute : function( attr, value, updateState ) {
				if ( attr == 'mp4' || attr == 'ogv' || attr == 'flash-player' ) return "";
				return clazz.Super.attribute.call( this, attr, value, updateState );
			}
		}
	} );
	
} )(jQuery,this);
