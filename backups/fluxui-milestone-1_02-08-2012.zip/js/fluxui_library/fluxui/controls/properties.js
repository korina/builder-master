/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
	
	var clazz = $class.create( {
		namespace : 'controls.properties',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
			types.controls.properties.getInstance( this );
		},
		fields : {
			propSheets : {},
			currentSheet : null
		},
		methods : {
			addChild : function( $n ) {
				var $cls = types.display.element.getInstance( $n );
				this.propSheets[$cls.ens] = $cls;
				clazz.Super.addChild.call( this, $n );
				if ( !this.currentSheet ) this.currentSheet = $cls.ens;
				this.showSheet( this.currentSheet );
			},
			loadSheet : function( $path, $clsName ) {
				var me = this, t = types, segs;
				$.getScript( $path, function() {
					segs = $clsName.split( '.' );
					for ( var i = 0; i < segs.length; i++ )
						if ( t[segs[i]] )
							t = t[segs[i]];
						else {
							console.log( 'Could not find prop sheet', $clsName );
							return;
						}
					t.create();
				} );
			},
			showSheet : function( $element ) {
				this.currentSheet = $element;
				var fnd;
				for ( var i in this.propSheets )
					if ( this.propSheets.hasOwnProperty( i ) ) {
						this.propSheets[i].display( i == this.currentSheet );
						fnd = ( i == this.currentSheet ) || fnd;
					}
				if ( !fnd ) console.log( "Could not find property sheet for element", $element );
				return fnd;
			}
		},
		statics : {
			getInstance : function( inst ) {
				if ( !!inst )
					types.controls.properties._inst = inst;
				return types.controls.properties._inst;
			}
		}
	} );
	
} )(jQuery,this);
