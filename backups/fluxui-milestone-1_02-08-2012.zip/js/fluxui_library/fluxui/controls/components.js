/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
	
	var clazz = $class.create( {
		namespace : 'controls.components',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
			this.comCounter = 0;
		},
		methods : {
			container : function() {
				return this.getChildById('component-list');
			},
			initialise : function() {
				var me = this;
				eventDispatcher.addListeners( {
					'properties.component.item.clicked' : function( evt, id ) { me.showPreview( id ); },
					'properties.component.item.dblclicked' : function( evt, id ) { me.addToStage( id ); }
				} );
				$.post( "data/?action=components", {}, function( data ) {
					data = eval( data );
					if ( types.core.isArray( data ) && data.length > 0 )
						for ( var i = 0; i < data.length; i++ )
							me.addComponent( data[i], data[i].split( '-' ).join( ' ' ) );
				} );
			},
			addToStage : function( $id ) {
				$.post( "data/?action=getComponent&id=" + $id, {}, function( data ) {
					eventDispatcher.dispatch( this, 'components.add', data );
				} );
			},
			addComponent : function( $id, $label ) {
				var d = this.data.hash['component-button'];
				if ( !!d ) {
					var p = types.serialiser.parse( 'component_' + this.comCounter++, d, this.container() );
					p.setId( $id );
					p.setLabel( $label );
					p.setIcon( 'data/?action=getComponent&id=' + $id + '&type=icon' );
					types.controls.properties.getInstance().loadSheet( 'data/?action=getComponent&id=' + $id + '&type=props', 'properties.' + $id );
				}
				eventDispatcher._dispatch( 'properties.components.item.added', $label, $id );
			},
			showPreview : function( $id ) {
				this.getChildById( 'preview' ).src( 'data/?action=getComponent&id=' + $id + '&type=preview' );
			},
			getComponents : function() {
				var d = {};
				var c = this.container().getChildren();
				for ( var i = 0; i < c.length; i++ )
					d[c[i].label] = { id: c[i].comId };
				return d;
			},
			clear : function() {
				var c = this.container().getChildren();
				for ( var i = 0; i < c.length; i++ )
					c[i].remove();
			}
		}
	} );
	
	var clazb = $class.create( {
		namespace : 'controls.componentitem',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazb.Super.constructor.call( this, $id, $descriptor );
		},
		methods : {
			initialise : function() {
				var me = this;
				this.$node().bind( 'click', function() { me.click(); } );
				this.$node().bind( 'dblclick', function() { me.dblclick(); } );
			},
			setId : function( $id ) {
				this.comId = $id;
			},
			setLabel : function( $label ) {
				this.label = $label;
				this.getChildById('component-label').text( $label );
			},
			setIcon : function( $icon ) {
				this.icon = $icon;
				this.getChildById('component-icon').src( $icon );
			},
			click : function() {
				eventDispatcher._dispatch( 'properties.component.item.clicked', this.comId );
			},
			dblclick : function() {
				eventDispatcher._dispatch( 'properties.component.item.dblclicked', this.comId );
			}
		}
	} );
	
} )(jQuery,this);