/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
	var lib;
	
	var clazz = $class.create( {
		namespace : 'controls.library',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
			this.assetCounter = 0;
			lib = this;
		},
		methods : {
			container : function() {
				return this.getChildById('asset-list');
			},
			initialise : function() {
				var me = this;
				eventDispatcher.addListeners( {
					'dialog.confirm.import-asset' : function( evt, label, url ) { me.handleImportDialogSubmit( label, url ); },
					'properties.library.add' : function() { me.handleAddAssetClick(); },
					'properties.library.item.clicked' : function( evt, url ) { me.showPreview( url ); }
				} );
			},
			addAsset : function( $url, $label ) {
				var d = this.data.hash['asset-button'];
				if ( !!d ) {
					var p = types.serialiser.parse( 'asset_' + this.assetCounter++, d, this.container() );
					p.setUrl( $url );
					p.setLabel( $label );
					assets[$label] = { url: $url };
				}
				eventDispatcher._dispatch( 'properties.library.item.added', $label, $url );
			},
			showPreview : function( url ) {
				this.getChildById( 'preview' ).src( url );
			},
			getAssets : function() {
				var d = {};
				var c = this.container().getChildren();
				for ( var i = 0; i < c.length; i++ )
					d[c[i].label] = { url: c[i].url };
				return d;
			},
			handleAddAssetClick : function() {
				var d = types.controls.dialog.getInstance();
				if ( !d.isOpen() ) {
					d.setContent( d.importAsset );
					d.show();
				}
			},
			handleImportDialogSubmit : function( $label, $url ) {
				lib.addAsset( $url, $label );
				types.controls.dialog.getInstance().hide();
			},
			clear : function() {
				var c = this.container().getChildren();
				for ( var i = 0; i < c.length; i++ )
					c[i].remove();
			}
		}
	} );
	
	var clazb = $class.create( {
		namespace : 'controls.libitem',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazb.Super.constructor.call( this, $id, $descriptor );
		},
		methods : {
			initialise : function() {
				var me = this;
				this.$node().bind( 'click', function() { me.click(); } );
				this.getChildById( 'asset-btn' ).$node().bind( 'click', function() { me.remove(); } );
			},
			setUrl : function( $url ) {
				this.url = $url;
			},
			setLabel : function( $label ) {
				this.label = $label;
				this.getChildById('asset-label').text( $label );
			},
			click : function() {
				eventDispatcher._dispatch( 'properties.library.item.clicked', this.url );
			},
			remove : function() {
				var lbl = this.getChildById('asset-label').text();
				this.$node().remove();
				eventDispatcher._dispatch( 'properties.library.item.removed', lbl );
			}
		}
	} );
	
} )(jQuery,this);