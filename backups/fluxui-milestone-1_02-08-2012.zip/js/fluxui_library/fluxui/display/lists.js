/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Unordered list class
	 * Provides for unordered lists
	 **/
	$class.create( {
		namespace : 'display.unorderedList',
		inherits : types.display.element,
		constructor : function( $id, $descriptor, $node ) {
			this._fluxid = $id;
			this.states = new types.state( $descriptor.initial, $descriptor.states );
			this.frames = types.core.clone( $descriptor.frames ) || {keys : [], hash : {}};
			this.data = types.core.clone( $descriptor.data ) || {};
			this.actions = new types.interaction( this, $descriptor.behavior, $descriptor.bind );
			this.makeNode( $node );
			this.__container = this;
			this.__bg = this;
			this.__bgOuter = this;
			this.__border = this;
			this._children = [];
		},
		fields : {
			markup : '<ul />'
		}
	} );
	
	/**
	 * Ordered list class
	 * Provides for ordered lists
	 **/
	var clazz = $class.create( {
		namespace : 'display.orderedList',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			markup : '<ol />'
		}
	} );
	
	/**
	 * List item class
	 * Provides the item tag for both ordered and unordered lists
	 **/
	var clazb = $class.create( {
		namespace : 'display.item',
		inherits : types.display.label,
		constructor : function( $id, $descriptor ) {
			clazb.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			markup : '<li />'
		}
	} );
	
} )(jQuery,this);
