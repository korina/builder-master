/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Image class
	 * Provides for the HTML img tag
	 **/
	var clazz = $class.create( {
		namespace : 'display.image',
		inherits : types.display.element,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			markup : '<img />'
		},
		props : {
			border : 'none'
		},
		methods : {
			src : function( $t ) {
				if ( !!$t )
					this.$node().attr( 'src', $t );
				return this.$node().attr( 'src' );
			},
			initialise : function() {
				this.clearSrc();
			},
			attribute : function( attr, value, updateState ) {
				if ( !!value ) {
					if ( !!updateState )
						this.states.setAttributeOnCurrentState( attr, value );
					if ( attr == 'src' ) {
						if ( !!assets[value] ) {
							this.$node().attr( attr, assets[value].url );
							if ( assets[value].height ) this.$node().attr( 'height', assets[value].height );
							if ( assets[value].width ) this.$node().attr( 'width', assets[value].width );
						} else this.clearSrc();
					}
					else
						this.$node().attr( attr, value );
				}
				return this.$node().attr( attr );
			},
			style : function( type, prop, updateState ) {
				if ( type == 'fill' ) return; // supress fills...
				return clazz.Super.style.call( this, type, prop, updateState );
			},
			resetSize : function( cb ) {
				var me = this;
				$("<img/>")
					.attr( "src", me.src() )
					.load( function() {
						var w = this.width, h = this.height;
						me.width( w );
						me.height( h );
						if ( !!cb ) cb( w, h );
					} );
			},
			clearSrc : function() {
				this.src( 'http://placehold.it/' + this.width() + 'x' + this.height() );
			}
		}
	} );
	
} )(jQuery,this);