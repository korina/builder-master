/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Openselect class
	 * Provides for multiple lined select HTML tag
	 **/
	var clazz = $class.create( {
		namespace : 'display.form.openselect',
		inherits : types.display.form.dropdown,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				clazz.Super.initialise.call( this, $id, $descriptor );
				var a = i.attr;
				this.$node().attr( 'size', a.labels.length );
			}
		}
	} );
	
} )(jQuery,this);