/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	/**
	 * Color class
	 * Provides color specific functions, including color conversion.
	 **/
	$class.create( {
		namespace : 'color',
		constructor : function( $r, $g, $b, $opacity, $pos ) {
			this.r = $r || 0;
			this.g = $g || 0;
			this.b = $b || 0;
			this.opacity = ( $opacity != null ) ? $opacity : 1;
			this.pos = $pos || 0;
		},
		methods : {
			toRGB : function() {
				return [this.r, this.g, this.b];
			},
			toRGBA : function() {
				return [this.r, this.g, this.b, this.opacity];
			},
			toHex : function( $useAlpha, $alphaFirst ) {
				var f = types.color.base16;
				var rgb = [ 
							f( this.r ),
							f( this.g ),
							f( this.b )
						],
					a = f( Math.round( this.opacity * 255 ) )
				if ( !!$useAlpha ) {
					if ( !!$alphaFirst )
						rgb.unshift( a );
					else
						rgb.push( a );
				}
				return '#' + rgb.join('');
			}
		},
		statics : {
			// Converts a decimal number to a hexidecimal number
			base16 : function( $num ) {
				return 16 > $num ? "0" + $num.toString(16) : $num.toString(16);
			},
			// Converts a hexidecimal number to a decimal number
			base10 : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !Math.isNaN( Number( $hex ) ) ? $hex : parseInt( $hex[1], 16 ) << 16 + parseInt( $hex[2], 16 ) << 8 + parseInt( $hex[3], 16 );
			},
			// Converts a hexidecimal number to an RGBA array.
			hexToRGBA : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !$hex ? $hex : [ parseInt( $hex[1], 16 ), parseInt( $hex[2], 16 ), parseInt( $hex[3], 16 ), 255 ];
			},
			// Converts a color object to an RGBA array
			objToRGBA : function( $obj ) {
				if ( $obj == "transparent" ) return [255, 255, 255, 0];
				if ( $obj.constructor == Array ) return $obj;
				var hex = types.color.hexToRGBA( $obj );
				return hex ? hex : ( hex = types.color.RGBAStringToRGBA( $obj ) ) ? hex : [255, 255, 255, 150];
			},
			fromRGB : function( $c ) {
				if ( !$c || $c.constructor != Array || $c.length < 3 ) return new types.color();
				return new types.color( $c[0], $c[1], $c[2] );
			},
			fromRGBA : function( $c ) {
				var rgb = types.color.fromRGB( $c );
				if ( !!$c && !!$c[3] ) rgb.opacity = $c[3];
				return rgb;
			},
			fromARGB : function( $c ) {
				var rgb = types.color.fromRGB( $c );
				if ( !!$c[3] ) rgb.opacity = $c[3];
				return rgb;
			},
			fromHex : function( $c ) {
				$c = types.color.hexToRGBA( $c );
				return new types.color( $c[0], $c[1], $c[2] );
			},
			// Converts an RGBA array to a string representaion (not hex).
			RGBAToRGBAString : function( $num ) {
				if ( $num.constructor == Array ) {
					var a = new Array();
					for ( i = 0; i < $num.length && i < 4; i++ )
						a.push( ( i == 3 ) ? $num[i] / 255 : $num[i] );
					return "rgba(" + a.join() + ")";
				}
			},
			// Converts string representation of RGBA to an RGBA array.
			RGBAStringToRGBA : function( $str ) {
				$str = /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/.exec( $str );
				return !$str ? $str : [ parseInt( $str[1], 10 ), parseInt( $str[2], 10 ), parseInt( $str[3], 10 ), parseInt( void 0 == $str[4] ? 255 : $str[4], 10 )];
			},
			// Converts an RGBA array to a hexidecimal string.
			RGBAToHex : function( $num, $useAlpha ) {
				if ( $num.constructor == Array ) {
					var c = [];
					for ( var i = 0; i < $num.length; i++ )
						c[i] = $num[i];
					if ( c.length > 3 ) {
						var alpha = c.pop();
						if ( $useAlpha )
							c.unshift( alpha );
					}
					var hashed = new Array();
					for ( i in c )
						hashed.push( types.color.base16( c[i] ) );
					return '#' + hashed.join(''); 
				}
			}
		}
	} );
	
} )(jQuery,this);