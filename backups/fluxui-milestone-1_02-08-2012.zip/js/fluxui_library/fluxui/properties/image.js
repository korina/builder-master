/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();
		
	var props = {
		type: 'properties.image',
		initial: {
			props: {
				fill: {
					type: 'linear',
					direction: 'top',
					colors: [
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0
						},
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0.33
						},
						{
							rgb: '#000000',
							opacity: 1,
							pos: 0.33
						},
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0.335
						},
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0.81
						},
						{
							rgb: '#000000',
							opacity: 1,
							pos: 0.81
						},
						{
							rgb: '#d6d6d6',
							opacity: 1,
							pos: 0.815
						}

					]
				},
				position: 'relative',
				width: 300,
				height: 190
			}
		},
		children: {
			keys: [ 'left', 'left-label', 'top', 'top-label', 'width', 'width-label', 'height', 'height-label', 'reset-asset', 'reset-asset-label', 'border-width', 'border-width-label', 'border-color', 'border-color-label', 'border-radius', 'border-radius-label', 'asset-source-label', 'asset-source', 'placeholder-asset-label', 'placeholder-asset', 'id', 'id-label', 'class', 'class-label' ],
			hash: {
				left: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 10,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.left.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.left'
						}
					}
				},
				'left-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 70,
							top: 10,
							width: 20
						},
						attr: {
							text: 'x'
						}
					}
				},
				top: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 40,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.top.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.top'
						}
					}
				},
				'top-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 70,
							top: 40,
							width: 20
						},
						attr: {
							text: 'y'	
						}
					}
				},
				width: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 100,
							top: 10,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.width.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.width'
						}
					}
				},
				'width-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 160,
							top: 10,
							width: 20
						},
						attr: {
							text: 'w'
						}
					}
				},
				height: {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 100,
							top: 40,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.height.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.height'
						}
					}
				},
				'height-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 160,
							top: 40,
							width: 20
						},
						attr: {
							text: 'h'
						}
					}
				},
				'placeholder-asset': {
					type: 'display.image',
					initial: {
						props: {
							left: 190,
							top: 10,
							width: 16,
							cursor: 'pointer'
						},
						attr: {
							src: 'btn-placeholder-asset'
						}
					},
					behavior: {
						click: {
							event: 'properties.image.placeholder'
						}
					}
				},
				'placeholder-asset-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 210,
							top: 10,
							width: 70
						},
						attr: {
							text: 'placeholder'
						}
					}
				},
				'reset-asset': {
					type: 'display.image',
					initial: {
						props: {
							left: 190,
							top: 40,
							width: 16,
							cursor: 'pointer'
						},
						attr: {
							src: 'btn-reset-asset'
						}
					},
					behavior: {
						click: {
							event: 'properties.image.reset-asset'
						}
					}
				},
				'reset-asset-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 210,
							top: 40,
							width: 60
						},
						attr: {
							text: 'reset size'
						}
					}
				},
				'border-color': {
					type: 'controls.colorpicker',
					initial: {
						props: {
							left: 185,
							top: 68
						}
					},
					bind: {
						color: {
							event: 'events.display.image.border-color.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.border-color'
						},
						click: {
							event: 'color.request'
						}
					}
				},
				'border-color-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 210,
							top: 70
						},
						attr: {
							text: 'border color'
						}
					}
				},
				'border-width': {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 70,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.border-width.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.border-width'
						}
					}
				},
				'border-width-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 70,
							top: 70
						},
						attr: {
							text: 'border weight'
						}
					}
				},
				'border-radius-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 70,
							top: 100
						},
						attr: {
							text: 'border radius'
						}
					}
				},
				'border-radius': {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 100,
							width: 50
						}
					},
					bind: {
						text: {
							event: 'events.display.image.border-radius.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.border-radius'
						}
					}
				},
				'asset-source-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 130,
							width: 60
						},
						attr: {
							text: 'source'
						}
					}
				},
				'asset-source': {
					type: 'display.form.dropdown',
					initial: {
						props: {
							left: 10,
							top: 130,
							width: 200
						}
					},
					bind: {
						text: {
							event: 'events.display.image.asset-source.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.asset-source'
						}
					}
				},
				'id': {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 10,
							top: 160,
							width: 80
						}
					},
					bind: {
						text: {
							event: 'events.display.image.id.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.id'
						}
					}
				},
				'id-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 100,
							top: 160,
							width: 20
						},
						attr: {
							text: 'id'
						}
					}
				},
				'class': {
					type: 'display.form.textfield',
					initial: {
						props: {
							left: 130,
							top: 160,
							width: 80
						}
					},
					bind: {
						text: {
							event: 'events.display.image.class.changed'
						}
					},
					behavior: {
						change: {
							event: 'properties.image.class'
						}
					}
				},
				'class-label': {
					type: 'display.label',
					initial: {
						props: {
							left: 220,
							top: 160,
							width: 40
						},
						attr: {
							text: 'class'
						}
					}
				}
			}
		}
	}
	
	/**
	 * Image property sheet class
	 * Provides functionality for the image property sheets.
	 **/
	var clazz = $.fn.fluxui.$class.create( {
		namespace : 'properties.image',
		inherits : types.properties.propsheet,
		constructor : function( $id, $descriptor ) {
			clazz.Super.constructor.call( this, $id, $descriptor );
		},
		fields : {
			ens : 'display.image'
		},
		methods : {
			initialise : function( $id, $decorator ) {
				var me = this;
				eventDispatcher.addListener( 'properties.image.*', function( $ns, $evt ) {
					me.handlePropertyChange( $($evt.target) );
				} );
				clazz.Super.initialise.call( this, $id, $decorator );
			}
		},
		statics : {
			create : function() {
				var ns = 'display.image';
				types.serialiser.parse( ns + '.props', props, types.controls.properties.getInstance() );
			}
		}
	} );
	
} )(jQuery,this);