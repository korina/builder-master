$(window).load( function() {
	$().fluxui.initialise( { debug : true } );

var editor =  {
	assets : {
		
	},
	library: {
		
	},
	movie : {
		states: {
			_default: {
				props: {
					width: 100,
					height: 270
				},
				attr: {
					anchor: [ 1, 1, 1, 1 ]
				},
				frames: {
					keys: [],
					hash: {}
				},
				children: {
					keys: [ 'header', 'workspace' ],
					hash: {
						header: {
							type: 'element',
							states: {
								_default: {
									props: {
										fill: {
											type: 'linear',
											direction: 'top',
											colors: [
												{
													rgb: '#cccccc',
													opacity: 1,
													pos: 0
												},
												{
													rgb: '#ffffff',
													opacity: 1,
													pos: 0.5
												},
												{
													rgb: '#cccccc',
													opacity: 1,
													pos: 1
												}
											]
										},
										width: 100,
										height: 70
									},
									attr: {
										anchor: [ 1, 1, 1, 1 ]
									},
									frame: {
										keys: [],
										hash: {}
									}
								}
							}
						},
						workspace: {
							type: 'element',
							states: {
								_default: {
									props: {
										fill: {
											type: 'solid',
											colors: [
												{
													rgb: '#666666',
													opacity: 1
												}
											]
										},
										width: 100,
										height: 200
									},
									attr: {
										anchor: [ 1, 1, 1, 1 ]
									},
									frame: {
										keys: [],
										hash: {}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

	$().fluxui.initialise( { debug : true } );
    $('#movie-container').fluxui( editor );
} );