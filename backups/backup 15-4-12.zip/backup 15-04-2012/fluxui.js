/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
 
/**
 * Using resize plugin for anchoring
 *
 * jQuery resize event - v1.1 - 3/14/2010
 * http://benalman.com/projects/jquery-resize-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 **/
 
(function($,window,undefined){
	'$:nomunge';
	var elems = $([]),
		jq_resize = $.resize = $.extend( $.resize, {} ),
		timeout_id,
		str_setTimeout = 'setTimeout',
		str_resize = 'resize',
		str_data = str_resize + '-special-event',
		str_delay = 'delay',
		str_throttle = 'throttleWindow';
	jq_resize[ str_delay ] = 250;
	jq_resize[ str_throttle ] = true;
	$.event.special[ str_resize ] = {
		setup: function() {
			if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
			var elem = $(this);
			elems = elems.add( elem );
			$.data( this, str_data, { w: elem.width(), h: elem.height() } );
			if ( elems.length === 1 ) {
				loopy();
			}
		},
		teardown: function() {
			if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
			var elem = $(this);
			elems = elems.not( elem );
			elem.removeData( str_data );
			if ( !elems.length ) {
				clearTimeout( timeout_id );
			}
		},
		add: function( handleObj ) {
			if ( !jq_resize[ str_throttle ] && this[ str_setTimeout ] ) { return false; }
			var old_handler;
			function new_handler( e, w, h ) {
				var elem = $(this),
					data = $.data( this, str_data );
				data.w = w !== undefined ? w : elem.width();
				data.h = h !== undefined ? h : elem.height();
				old_handler.apply( this, arguments );
			};
			if ( $.isFunction( handleObj ) ) {
				old_handler = handleObj;
				return new_handler;
			} else {
				old_handler = handleObj.handler;
				handleObj.handler = new_handler;
			}
		}
	};
	function loopy() {
		timeout_id = window[ str_setTimeout ](function(){
			elems.each(function(){
				var elem = $(this),
					width = elem.width(),
					height = elem.height(),
					data = $.data( this, str_data );
				if ( width !== data.w || height !== data.h ) {
					elem.trigger( str_resize, [ data.w = width, data.h = height ] );
				}
			});
			loopy();
		}, jq_resize[ str_delay ] );
	};
})(jQuery,this);

/**
 * Begin FluxUI
 **/

( function( $ ) {

	var eventDispatcher;

	/**
	 * Plugin constructor
	 * Here, we parse the movie and perform simple checks to ensure we have
	 * what we need.  We then proceed to kick start the movie construction.
	 **/
	var flux = $.fn.fluxui = function( $movie ) {
		$container = $(this);
		$container.empty();
		eventDispatcher = flux.eventDispatcher = flux.eventDispatcher || new types.events.dispatcher();
		// we're doing this for each movie, though we only really want (and have tested) for one.
		var rtn = this.each( function() {
			if ( !$movie ) flux.log( "No movie to parse. Exiting." );
			if ( $movie ) {
				// stick all assets in the _assets variable
				var _assets = new Array();
				for ( a in $movie.assets ) {
					_assets.push( $movie.assets[a].url );
				}
				if ( _assets.length > 0 ) {
					types.system.preload( _assets );
				}
				$.extend( true, assets, $movie.assets );
			}
			var m;
			// kickstart movie construction
			if ( !!$movie.library && !!$movie.movie ) {
				m = types.system.createMovie( $movie.movie, types.system.nextMovieCounter() );
			} else {
				flux.log( "Movie structure corrupt." );
			}
			// set outer movie container css (includes dimentions)
			if ( 'absolute' != $(this).css( 'position' ) && 'relative' != $(this).css( 'position' ) )
				$(this).css( 'position', 'relative' );
			$container.css( 'width', $(m).width() );
			$container.css( 'height', $(m).height() );
			$container.append( m );
			m = types.element.getInstance( m );
			if ( !!m && !!m.initialise )
				m.initialise( $movie.movie.states._default );
		} );
		
		return { movie: rtn, eventDispatcher: eventDispatcher, types: types };
	};

	/**
	 * the developer can call this to set his own default settings, such as debug mode etc.
	 **/
	flux.initialise = function( $options ) {
		$.extend( true, this.settings, $options );
	};

	/**
	 * global assets lookup
	 **/
	var assets = flux.assets = flux.assets || {};
	
	/**
	 * global data container
	 **/
	var fdata = flux.fdata = flux.fdata || {};

	/**
	 * types lookup - stores all classes for all movies
	 **/
	var types = flux.types = flux.types || {};
	
	/**
	 * class builder object
	 **/
	var $$class = flux.$class = flux.$class || {};
	
	/**
	 * The class engine.
	 * Handles building classes from passed structures
	 **/
	$$class.create = function( param ) {
		if ( !param )
			return function() {};

		if ( !param.namespace )
			throw new Error( "Please specify the Namespace." );
		
		if ( !types[param.namespace] ) {

			var clazz = function() {
				//analyse fields of the class
				if ( param.fields ) {
					param.fields.className = param.namespace;
					var fields = param.fields;
					for ( var field in fields ) {
						if ( typeof fields[field] == "function" )
							throw new TypeError( "Field [" + field + "] cannot be a function!" );
						if ( field == "props" ) { // hack to inherit properties
							if ( !this[field] ) this[field] = {};
							for ( var prop in fields[field] )
								this[field][prop] = fields[field][prop];
						}
						else if ( !this[field] )
							this[field] = fields[field];
					}
				}
				
				// get and execute the constructor to do the initialize process.
				if ( param.constructor ) {
					if ( typeof param.constructor != "function" )
						throw new TypeError("Illegal function [" + method + "]!");
					param.constructor.apply( this, arguments );
				}
				
			};
		
			// set parent class and field "Super" for class         
			var parentClass = param.inherits || Object;
			if ( typeof parentClass != "function" )
				throw new TypeError( "The parent class is not a function." );
			if ( parentClass != Object ) {
				function F() {};
				F.prototype = parentClass.prototype;
				var prototype = new F();
				prototype.constructor = clazz;
				clazz.prototype = prototype;
			}
			clazz.prototype.Super = parentClass;
		
			// read methods and add to class(use prototype)
			if ( param.methods ) {
				var methods = param.methods;
				for ( var method in methods ) {
					if ( typeof methods[method] != "function" )
						throw new TypeError( "Illegal function [" + method + "]!" );
					clazz.prototype[method] = methods[method];
				}
			}
			
			// read static variables and methods and add to class
			if ( param.statics ) {
				var statics = param.statics;
				for ( var name in statics )
					clazz[name] = statics[name];
			}
			// create the specified namespace and append the class to it.
			var name = param.namespace;
			if ( name.length == 0 || name.indexOf( " " ) != -1 || name.charAt( 0 ) == '.' 
					|| name.charAt( name.length - 1 ) == '.' || name.indexOf( ".." ) != -1 )
				throw new Error( "illegal Namespace: " + name );
			var parts = name.split( '.' );
			var container = types;
			for( var i = 0; i < parts.length - 1; i++ ) {
				var part = parts[i];
				// If there is no property of container with this name, create an empty object.
				if (!container[part]) {
					container[part] = {};
				} else if (typeof container[part] != "object") {
					// If there is already a property, make sure it is an object
					var n = parts.slice(0, i).join('.');
					throw new Error(n + " already exists and is not an object");
				}
				container = container[part];
			}
			container[parts[parts.length - 1]] = clazz;
		} else
			var clazz = types[param.namespace];
		
		return clazz;
	};
	
	/**
	 * Timer class
	 * This is the animation timer engine.  Functions are removed when they return false.
	 * When all functions are removed, the timer is deleted.  Only one timer required
	 * to process all functions, application wide.
	 **/
	$$class.create( {
		namespace : 'timer',
		statics : {
			timerID : 0,
			timers : [],
			start : function() {
				if ( types.timer.timerID )
					return;
				( function(){
					for ( var i = 0; i < types.timer.timers.length; i++ )
						if ( types.timer.timers[i]() === false ) {
							types.timer.timers.splice(i, 1);
							i--;
						}
					types.timer.timerID = setTimeout( arguments.callee, 0 );
				} )();
			},
			stop: function(){
				clearTimeout( types.timer.timerID );
				types.timer.timerID = 0;
			},
			add: function( fn ){
				types.timer.timers.push( fn );
				types.timer.start();
			}
		}
	} );
	
	/**
	 * Style class
	 * Provides functions specific to parsing and understanding styles / css values
	 **/
	$$class.create( {
		namespace : 'style',
		statics : {
			css : function( $node, $style, $value ) {
				switch( $style ) {
					case 'fill' :
						var fill = types.style.normaliseFill( $value );
						$($node).css( 'filter', fill.filter );
						for ( var i = 0; i < fill.background.length; i++ )
							$($node).css( 'background', fill.background[i] );
						return;
						break;	
				}
				$($node).css( $style, $value );
			},
			decorate : function( $key, $value ) {
				return ( types.style.isNumeric( $key ) && $value > 0 ) ? $value + 'px' : $value;
			},
			raw : function( $value ) {
				return Number( String( $value ).split( 'px' ).join( '' ) );
			},
			// Normalises single color gradient parsing (solid fills)
			normaliseFill : function( $data ) {
				var fillType = $data.type || 'solid';
				if ( $data.colors.length <= 1 )
					fillType = 'solid';
				return types.style.normaliseBackground( fillType, $data.direction || 'top', $data.colors );
			},
			// Provides css for border radius for different browser types
			normaliseBorder : function( $size ) {
				return { "border-radius" : $size,
				"-moz-border-radius" : $size,
				"-webkit-border-radius" : $size };
			},
			// Provides css for gradient backgrounds for different browser types
			normaliseBackground : function( $fillType, $direction, $colors ) {
				if ( $colors.length == 1 )
					$colors[1] = $colors[0];
				var fromIE_RGBA = types.color.RGBAToHex( types.color.objToRGBA( $colors[0].rgb ), true );
				var toColor = $colors[$colors.length-1].rgb;
				var toIE_RGBA = types.color.RGBAToHex( types.color.objToRGBA( toColor ), true );
				var clrList = '';
				var grdList = '';
				var grdDir = 'left top, left bottom';
				switch( $direction ) {
					case 'top':
						break;
					case 'left':
						grdDir = 'left top, right top';
						break;
					case '-45deg':
						grdDir = 'left top, right bottom';
						break;
					case '45deg':
						grdDir = 'left bottom, right top';
						break;
					case 'center':
						grdDir = 'center center, 0px, center center';
						break;
				}
				for ( var i = 0; i < $colors.length; i++ ) {
					if ( isNaN( $colors[i].pos ) ) {
						var lastPos = 0;
						if ( $colors.length == 1 ) lastPos = $colors[i].pos = 0;
						else if ( i == $colors.length - 1 ) lastPos = $colors[i].pos = 1;
						else lastPos = $colors[i].pos = ( 1 - lastPos ) / ( $colors.length - ( i - 1 ) ) + lastPos;
					} else lastPos = $colors[i].pos;
					clrList += types.color.RGBAToString( types.color.objToRGBA( $colors[i].rgb ) ) + " " + ($colors[i].pos * 100) + "%";
					grdList += "color-stop(" + ($colors[i].pos * 100) + "%" + " " + types.color.RGBAToHex( types.color.objToRGBA( $colors[i].rgb ) ) + ")";
					if ( i < $colors.length - 1 ) {
						clrList += ", ";
						grdList += ", ";
					}
				}
				var ret = { filter : "progid:DXImageTransform.Microsoft.gradient(startColorStr='" + fromIE_RGBA + "', EndColorStr='" + toIE_RGBA + "')",
					background : ["-webkit-gradient(" + ( $direction == 'center' ? 'radial' : 'linear' ) + ", " + grdDir + ", " + grdList + ")",
					"-webkit-linear-gradient(" + $direction + ", " + clrList + ")",
					"-moz-linear-gradient(" + $direction + ", " + clrList + ")",
					"-ms-linear-gradient(" + $direction + ", " + clrList + ")",
					"-o-linear-gradient(" + $direction + ", " + clrList + ")",
					"linear-gradient(" + $direction + ", " + clrList + ")"] };
				return ret;
			},
			// Gets those properties in $nextProps that are different or not
			// present in $curProps and adds them to $merged.  If differences are found,
			// true is returned, else false.
			getPropertyDiff : function( $curProps, $nextProps, $merged ) {
				var diff = false;
				if ( !$curProps )
					$curProps = {};
				for ( var prop in $nextProps ) {
					if ( $nextProps.hasOwnProperty( prop ) ) {
						if ( !$curProps[prop] && typeof $nextProps[prop] != 'object' ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
							continue;
						}
						if ( typeof $nextProps[prop] === 'object'  ) {
							var obj = {};
							if ( types.style.getPropertyDiff( $curProps[prop], $nextProps[prop], obj ) ) {
								if ( !$merged[prop] ) $merged[prop] = {}
								if ( prop == "fill" )
									$.extend( true, $merged[prop], $nextProps[prop] );
								else
									$.extend( true, $merged[prop], obj );
								diff = true;
							}
						} else if ( $curProps[prop] != $nextProps[prop] ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
						}
					}
				}
				return diff;
			},
			// Lists all css types that can be animated
			canAnimate : function( $prop ) {
				return types.system.indexOf( ['opacity', 'color', 'fill', 'background-color', 'border-color', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'], $prop );
			},
			// Lists all css types that are a color type
			isColor : function( $prop ) {
				return types.system.indexOf( ['color', 'fill', 'background-color', 'border-color'], $prop );
			},
			// Lists all css types that are numeric
			isNumeric : function( $prop ) {
				return types.system.indexOf( ['opacity', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'], $prop );
			}
		}
	} );
	
	/**
	 * Events class
	 * Events binding, collecting and notifications functions
	 **/
	$$class.create( {
		namespace : 'events.dispatcher',
		fields : {
			delimiter : '.',
			wildcard : '*',
			_stack : {}
		},
		methods : {
			addListener : function( $evt, $handler ) {
				var pntr = eventDispatcher._getNamespaceSegment( $evt );
				if ( !this.hasListener( $evt, $handler ) )
					pntr._handlers.push( $handler );
			},
			removeListener : function( $evt, $handler ) {
				var pntr = eventDispatcher._getNamespaceSegment( $evt );
				if ( !$pntr._handlers ) $pntr._handlers = [];
				for ( var t = 0; t < $pntr._handlers.length; t++ )
					if ( $pntr._handlers[t] == $handler ) {
						$pntr._handlers.splice( t );
						return;
					}
			},
			hasListener : function( $evt, $handler ) { 
				if ( !$handler || typeof $handler != 'function' ) throw 'Event handler must be supplied as a function';
				var pntr = eventDispatcher._getNamespaceSegment( $evt );
				if ( !pntr._handlers ) pntr._handlers = [];
				var f = false;
				for ( var t = 0; t < pntr._handlers.length; t++ )
					if ( pntr._handlers[t] == $handler )
						f = true;
				return f;
			},
			dispatch : function( $evt /* additional params will be passed to event handlers */ ) {
				var pntr = eventDispatcher._getNamespaceSegment( $evt, true ),
					args = Array.prototype.slice.call( arguments ).splice(0);
				args.shift();
				for ( var i = 0; i < pntr.length; i++ )
					for ( var j = 0; j < pntr[i]._handlers.length; j++ )
						pntr[i]._handlers[j].apply( arguments.caller, args );
			},
			bind : function( $obj, $trigger, $event ) {
				var t = eventDispatcher;
				$obj.bind( $trigger, function() {
					var args = Array.prototype.slice.call( arguments );
					args.unshift( $event );
					t.dispatch.apply( $obj, args );
				} );
			},
			_getNamespaceSegment : function( $evt, $includeWildcards, $arr ) {
				var e = ( typeof $evt == 'string' ) ? $evt.split( this.delimiter ) : ( $evt.constructor == Array ) ? $evt : null;
				if ( !e ) throw 'Event listener assigned to unknown type';
				var pntr = this._stack;
				for ( var i = 0; i < e.length; i++ ) {
					if ( typeof e[i] != 'string' ) throw 'Event identifier segment not a string value';
					if ( e[i] == "_handlers" || ( e[i] == this.wildcard && i < e.length - 1 ) ) throw 'Invalid name used in event namespace.';
					if ( !pntr[e[i]] ) pntr[e[i]] = {};
					pntr = pntr[e[i]];
				}
				if ( !pntr._handlers ) pntr._handlers = [];
				if ( $includeWildcards ) {
					if ( !$arr || $arr.constructor != Array ) $arr = [];
					$arr.push( pntr );
					if ( e[e.length-1] == this.wildcard )
						e.pop();
					if ( e.length > 0 ) {
						e.pop();
						e.push( this.wildcard );
						this._getNamespaceSegment( e, $includeWildcards, $arr );
					}
					return $arr;
				}
				return pntr;
			}
		}
	} );
	
	/**
	 * System class
	 * Provides system level functions
	 **/
	$$class.create( {
		namespace : 'system',
		statics : {
			// load all images used in the movie. likely not needed, but future proofs code
			preload : function( $assets ) {
				for ( a in $assets )
					$('<img/>')[0].src = $assets[a];
			},
			// guarantees a unique movie id
			nextMovieCounter : function() {
				fdata.counter = fdata.counter || 0;
				return fdata.counter++;
			},
			// helps kickstart movie parsing into HTML nodes
			createMovie : function( $clip, $movieId, $state ) {
				$state = $state || '_default';
				var node = new types.element( 'root_' + $movieId, $clip.states[$state] );
				$(node).attr( 'entity', 'movie' );
				return node.node;
			},
			// encodes HTML to a valid string
			htmlEncode : function(value){
				return $('<div/>').text(value).html();
			},
			// Decodes a string to valid HTML
			htmlDecode : function(value){
				return $('<div/>').html(value).text();
			},
			// Clones an object
			clone : function( $obj ) {
				var newObj = ( $obj instanceof Array ) ? [] : {};
				for ( i in $obj ) {
					if ( $obj[i] && typeof $obj[i] == "object" ) {
						newObj[i] = types.system.clone( $obj[i] );
					} else newObj[i] = $obj[i]
				}
				return newObj;
			},
			// Non-global polluting array.indexOf function
			indexOf : function( $array, $value ) {
				for ( var i = 0; i < $array.length; i++ ) {
					if ( $array[i] == $value ) return true;
				}
				return false;
			},
			// Returns true if $val is an Object. This includes any complex object, including Arrays.
			isObject : function( $val ) {
				return $val === Object( $val );
			},
			// Returns true if $val is an array.
			isArray : function( $val ) {
				return $val.constructor == Array;
			},
			// Returns true if $val is a string
			isString : function( $val ) {
				return toString.call( $val ) == '[object String]';
			},
			// Returns true if item has no length or own properties.
			isEmpty : function( $val ) {
				if ( types.system.isArray( $val ) || types.system.isString( $val ) ) return $val.length === 0;
				for ( var key in $val ) if ( $val.hasOwnProperty( key ) ) return false;
				return true;
			},
			// Returns an array of form names used by all elements ( limited by element if required )
			getAllFormNames : function( $element ) {
				if ( !$element )
					var $element = 'body';
				var formNames = [];
				$( $element ).find( '[formName]' ).each( function() {
					var thisForm = $( this ).attr( 'formName' );
					for ( formName in formNames )
						if ( formNames[formName] === thisForm )
							var pushing = false;
					if ( pushing !== false )
						formNames.push( thisForm );
				} );
				return formNames;
			},
			// Get a form's elements by form name ( or retrieve the first form's input ), and filter by class, tag and type
			getByFormName : function( $formName, $elClass, $tag, $type ) {
				if ( !$formName )
					var $formName = types.system.getAllFormNames()[0];
				if ( !$elClass && !$tag && !$type )
					return $( '[formName="' + $formName + '"]' );
				else {
					var returnEls = [];
					$( '[formName="' + $formName + '"]' ).each( function() {
						if ( !!$elClass && $( this ).hasClass( $elClass ) === true ) {
							for ( el in returnEls )
								if ( returnEls[el] !== this )
									var pushing = false;
							if ( pushing !== false )
								returnEls.push( this );
						};
						// Lee, check for matches by tag may not be needed, what do you think?
						if ( !!$tag && this.tagName === $tag ) {
							for ( el in returnEls )
								if ( returnEls[el] !== this )
									var pushing = false;
							if ( pushing !== false )
								returnEls.push( this );
						};
						// specifically for 'input' elements
						if ( !!$type && $( this ).attr( 'type' ) === $type ) {
							for ( el in returnEls )
								if ( returnEls[el] !== this )
									var pushing = false;
							if ( pushing !== false )
								returnEls.push( this );
						}
					} );
					return returnEls;
				}
			}
		}
	} );
	
	/**
	 * Tween class
	 * Handles all tweening / animation tasks.
	 **/
	$$class.create( {
		namespace : 'tween',
		statics : {
			// From $start color to $end color using tween percentage $pc, returns
			// a new color that is the $pc (percentage) of both colors, where 0% is $start
			// and 100% is $end.
			getRGBTransition : function( $start, $end, $pc ) {
				var r1 = $start[0],
					g1 = $start[1],
					b1 = $start[2],
					a1 = $start[3];
			
				var r2 = $end[0],
					g2 = $end[1],
					b2 = $end[2],
					a2 = $end[3];
			
				return [Math.floor( r1 + ( $pc * ( r2 - r1 ) ) + .5 ),
						Math.floor( g1 + ( $pc * ( g2 - g1 ) ) + .5 ),
						Math.floor( b1 + ( $pc * ( b2 - b1 ) ) + .5 ),
						Math.floor( a1 + ( $pc * ( a2 - a1 ) ) + .5 )];
			},
			// Prepares to animate $props on $node for $duration using the ease function $easing.
			// once complete, $callback in invoked.
			animate : function( $node, $props, $duration, $easing, $callback ) {
				if ( !$easing ) $easing = "linearTween";
				var aprops = {};
				var hasProps = false;
				for ( var key in $props ) {
					if ( !!$duration && $props.hasOwnProperty( key ) && types.style.canAnimate( key ) ) {
						aprops[key] = $props[key];
						hasProps = true;
					} else {
						if ( !!$props[key] && $props[key].constructor == Array )
							for ( j in $props[key] )
								types.style.css( $node, key, types.style.decorate( key, $props[key][j] ) );
						else
							types.style.css( $node, key, types.style.decorate( key, $props[key] ) );
					}
				}
				if ( hasProps ) {
					types.tween.doAnimation( $node, aprops, $duration, $easing, $callback );
				} else if ( !!$callback ) $callback();
			},
			// Performs the actual animation. See "animate" above.
			doAnimation : function( $node, $props, $duration, $easing, $callback ) {
				var startTime = new Date().getTime();
				var ease = types.tween[$easing];
				var inst = types.element.getInstance( $node );
				inst.props = inst.props || {};
				var fills = [], colors = [], css = [];
				for ( var prop in $props ) {
					if ( types.style.isColor( prop ) ) {
						if ( prop == 'fill' ) {
							if ( inst.props.fill == null )
								inst.props.fill = { colors : [ { rgb : '#ffffff', opacity: 0 }, { rgb : '#ffffff', opacity: 0 } ], type : 'solid' };
							if ( typeof inst.props.fill.colors[1] === 'undefined' )
								inst.props.fill.colors[1] = inst.props.fill.colors[0];
							if ( typeof $props[prop].colors[1] === 'undefined' )
								$props[prop].colors[1] = $props[prop].colors[0];
							var pc1 = types.color.colorObjToRGBA( inst.props.fill.colors[0].rgb, inst.props.fill.colors[0].opacity ),
								pc2 = types.color.colorObjToRGBA( inst.props.fill.colors[1].rgb, inst.props.fill.colors[1].opacity ),
								nc1 = types.color.colorObjToRGBA( $props[prop].colors[0].rgb, $props[prop].colors[0].opacity ),
								nc2 = types.color.colorObjToRGBA( $props[prop].colors[1].rgb, $props[prop].colors[1].opacity );
							if ( !( pc1 == nc1 && pc2 == nc2 ) ) {
								fills.push( {
									type : $props[prop].type || 'solid', 
									from1 : pc1,
									from2 : pc2, 
									to1 : nc1,
									to2 : nc2
								} );
							}
							continue;
						} else {
							var val = inst.props[prop] || inst.$node().css( prop );
							if ( !val || val == '' || val == 'initial' )
								var val = 'transparent';
							if ( val != $props[prop] ) {
								var pcolor = types.color.colorObjToRGBA( val );
								var ncolor = types.color.colorObjToRGBA( $props[prop].rgb, $props[prop].opacity );
								colors.push( { prop : prop, from : pcolor, to : ncolor } );
							}
							continue;
						}
					}
					if ( types.style.isNumeric( prop ) ) {
						var val = ( inst.props[prop] || inst.$node().css( prop ) ),
							newProp = $props[prop];
						val = types.style.raw( val );
						if ( val != newProp )
							css.push( { prop : prop, from : val, to : newProp } );
					}
				}
				// If there's a duration, then create a timer function and animate
				if ( $duration > 0 ) {
					types.timer.add( function() {
						var time = Math.min( new Date().getTime() - startTime, $duration );
						var perc = ease( time, 0, 1, $duration );
						if ( fills.length > 0 ) {
							for ( var i = 0; i < fills.length; i++ ) {
								inst.setStyle( 'background-image', { 
									color1 : types.tween.getRGBTransition( fills[i].from1, fills[i].to1, perc ), 
									color2 : types.tween.getRGBTransition( fills[i].from2, fills[i].to2, perc ), 
									type : fills[i].type
								} );
							}
						}
						if ( colors.length > 0 ) {
							for ( var i = 0; i < colors.length; i++ ) {
								inst.setStyle(
									colors[i].prop,
									types.tween.getRGBTransition( colors[i].from, colors[i].to, perc )
								);
							}
						}
						if ( css.length > 0 ) {
							for ( var i = 0; i < css.length; i++ ) {
								var nv = Math.floor( css[i].from + ( perc * ( css[i].to - css[i].from ) ) + .5 );
								inst.setStyle( css[i].prop, nv );
							}
						}
						if ( time >= $duration ) {
							$callback();
							return false;
						}
					} );
				// If no duration, just change the properties here and now.
				} else {
					for ( var i = 0; i < fills.length; i++ )
						inst.setStyle( 'background-image', { 
							color1 : fills[i].to1, 
							color2 : fills[i].to2, 
							type : fills[i].type
						} );
					for ( var i = 0; i < colors.length; i++ )
						inst.setStyle( colors[i].prop, colors[i].to );
					for ( var i = 0; i < css.length; i++ )
						inst.setStyle( css[i].prop, css[i].to );
				}
			},
			// --- LIST OF TWEEN FUNCTIONS --- //
			// t: current time, b: beginning value, c: change in value, d: duration
			// t and d can be in frames or seconds/milliseconds
			linearTween : function( t, b, c, d ) {
				return c * t / d + b;
			},
			easeInQuad : function( t, b, c, d ) {
				return c * ( t /= d ) * t + b;
			},
			easeOutQuad : function( t, b, c, d ) {
				return -c * ( t /= d ) * ( t - 2 ) + b;
			},
			easeInOutQuad : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t + b;
				return -c / 2 * ( ( --t ) * ( t - 2 ) - 1 ) + b;
			},
			easeInCubic : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t + b;
			},
			easeOutCubic : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t + 1 ) + b;
			},
			easeInOutCubic : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t + 2 ) + b;
			},
			easeInQuart : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t + b;
			},
			easeOutQuart : function( t, b, c, d ) {
				return -c * ( ( t = t / d - 1 ) * t * t * t - 1 ) + b;
			},
			easeInOutQuart : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t + b;
				return -c / 2 * ( ( t -= 2 ) * t * t * t - 2 ) + b;
			},
			easeInQuint : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t * t + b;
			},
			easeOutQuint : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t * t * t + 1 ) + b;
			},
			easeInOutQuint : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t * t * t + 2 ) + b;
			},
			easeInSine : function( t, b, c, d ) {
				return -c * Math.cos( t / d * ( Math.PI / 2 ) ) + c + b;
			},
			easeOutSine : function( t, b, c, d ) {
				return c * Math.sin( t / d * ( Math.PI / 2 ) ) + b;
			},
			easeInOutSine : function( t, b, c, d ) {
				return -c / 2 * ( Math.cos( Math.PI * t / d ) - 1 ) + b;
			},
			easeInExpo : function( t, b, c, d ) {
				return ( t == 0 ) ? b : c * Math.pow( 2, 10 * ( t / d - 1 ) ) + b;
			},
			easeOutExpo : function( t, b, c, d ) {
				return ( t == d ) ? b + c : c * ( - Math.pow( 2, -10 * t / d ) + 1 ) + b;
			},
			easeInOutExpo : function( t, b, c, d ) {
				if ( t == 0 ) return b;
				if ( t == d ) return b + c;
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * Math.pow( 2, 10 * ( t - 1 ) ) + b;
				return c / 2 * ( - Math.pow( 2, -10 * --t ) + 2 ) + b;
			},
			easeInCirc : function( t, b, c, d ) {
				return -c * ( Math.sqrt( 1 - ( t /= d ) * t ) - 1 ) + b;
			},
			easeOutCirc : function( t, b, c, d ) {
				return c * Math.sqrt( 1 - ( t = t / d - 1 ) * t ) + b;
			},
			easeInOutCirc : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return -c / 2 * ( Math.sqrt( 1 - t * t ) - 1 ) + b;
				return c / 2 * ( Math.sqrt( 1 - ( t -= 2 ) * t ) + 1) + b;
			},
			easeInElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return -( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
			},
			easeOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return a * Math.pow( 2, -10 * t ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) + c + b;
			},
			easeInOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d / 2 ) == 2 ) return b + c;  if ( !p ) p = d * ( .3 * 1.5 );
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				if ( t < 1 ) return -.5 * ( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
				return a * Math.pow( 2 , -10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) * .5 + c + b;
			},
			easeInBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( t /= d ) * t * ( ( s + 1 ) * t - s ) + b;
			},
			easeOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( ( t = t / d - 1 ) * t * ( ( s + 1 ) * t + s ) + 1 ) + b;
			},
			easeInOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158; 
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * ( t * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t - s ) ) + b;
				return c / 2 * ( ( t -= 2 ) * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t + s ) + 2 ) + b;
			},
			easeInBounce : function( t, b, c, d ) {
				return c - types.tween.easeOutBounce( d - t, 0, c, d ) + b;
			},
			easeOutBounce : function( t, b, c, d ) {
				if ( ( t /= d ) < ( 1 / 2.75 ) ) {
					return c * ( 7.5625 * t * t ) + b;
				} else if ( t < ( 2 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 1.5 / 2.75 ) ) * t + .75 ) + b;
				} else if ( t < ( 2.5 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 2.25 / 2.75 ) ) * t + .9375 ) + b;
				} else {
					return c * ( 7.5625 * ( t -= ( 2.625 / 2.75 ) ) * t + .984375 ) + b;
				}
			},
			easeInOutBounce : function( t, b, c, d ) {
				if ( t < d / 2 ) return types.tween.easeInBounce( t * 2, 0, c, d ) * .5 + b;
				return types.tween.easeOutBounce( t * 2 - d, 0, c, d ) * .5 + c * .5 + b;
			}
		}
	} );
	
	/**
	 * Color class
	 * Provides color specific functions, including color conversion.
	 **/
	$$class.create( {
		namespace : 'color',
		statics : {
			// Converts a decimal number to a hexidecimal number
			base16 : function( $num ) {
				return 16 > $num ? "0" + $num.toString(16) : $num.toString(16);
			},
			// Converts a hexidecimal number to a decimal number
			base10 : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !Math.isNaN( Number( $hex ) ) ? $hex : parseInt( $hex[1], 16 ) << 16 + parseInt( $hex[2], 16 ) << 8 + parseInt( $hex[3], 16 );
			},
			// Converts a hexidecimal number to an RGBA array.
			hexToRGBA : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !$hex ? $hex : [ parseInt( $hex[1], 16 ), parseInt( $hex[2], 16 ), parseInt( $hex[3], 16 ), 255 ];
			},
			// Converts a color object to an RGBA array
			objToRGBA : function( $obj ) {
				if ( $obj == "transparent" ) return [255, 255, 255, 0];
				if ( $obj.constructor == Array ) return $obj;
				var hex = types.color.hexToRGBA( $obj );
				return hex ? hex : ( hex = types.color.rgbaStringToRGBA( $obj ) ) ? hex : [255, 255, 255, 150];
			},
			// Converts an RGBA array to a string representaion (not hex).
			RGBAToString : function( $num ) {
				if ( $num.constructor == Array ) {
					var a = new Array();
					for ( i = 0; i < $num.length && i < 4; i++ )
						a.push( ( i == 3 ) ? $num[i] / 255 : $num[i] );
					return "rgba(" + a.join() + ")";
				}
			},
			// Converts string representation of RGBA to an RGBA array.
			rgbaStringToRGBA : function( $str ) {
				$str = /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/.exec( $str );
				return !$str ? $str : [ parseInt( $str[1], 10 ), parseInt( $str[2], 10 ), parseInt( $str[3], 10 ), parseInt( void 0 == $str[4] ? 255 : $str[4], 10 )];
			},
			// Converts an RGBA array to a hexidecimal string.
			RGBAToHex : function( $num, $useAlpha ) {
				if ( $num.constructor == Array ) {
					var c = [];
					for ( var i = 0; i < $num.length; i++ )
						c[i] = $num[i];
					if ( c.length > 3 ) {
						var alpha = c.pop();
						if ( $useAlpha )
							c.unshift( alpha );
					}
					var hashed = new Array();
					for ( i in c )
						hashed.push( types.color.base16( c[i] ) );
					return '#' + hashed.join(''); 
				}
			},
			// Converts a color name to a hexidemcial value
			colorNameToHex : function( $color ) {
				var colors = {"aliceblue":"#f0f8ff","antiquewhite":"#faebd7","aqua":"#00ffff","aquamarine":"#7fffd4","azure":"#f0ffff","beige":"#f5f5dc","bisque":"#ffe4c4","black":"#000000","blanchedalmond":"#ffebcd","blue":"#0000ff","blueviolet":"#8a2be2","brown":"#a52a2a","burlywood":"#deb887","cadetblue":"#5f9ea0","chartreuse":"#7fff00","chocolate":"#d2691e","coral":"#ff7f50","cornflowerblue":"#6495ed","cornsilk":"#fff8dc","crimson":"#dc143c","cyan":"#00ffff","darkblue":"#00008b","darkcyan":"#008b8b","darkgoldenrod":"#b8860b","darkgray":"#a9a9a9","darkgreen":"#006400","darkkhaki":"#bdb76b","darkmagenta":"#8b008b","darkolivegreen":"#556b2f","darkorange":"#ff8c00","darkorchid":"#9932cc","darkred":"#8b0000","darksalmon":"#e9967a","darkseagreen":"#8fbc8f","darkslateblue":"#483d8b","darkslategray":"#2f4f4f","darkturquoise":"#00ced1","darkviolet":"#9400d3","deeppink":"#ff1493","deepskyblue":"#00bfff","dimgray":"#696969","dodgerblue":"#1e90ff","firebrick":"#b22222","floralwhite":"#fffaf0","forestgreen":"#228b22","fuchsia":"#ff00ff","gainsboro":"#dcdcdc","ghostwhite":"#f8f8ff","gold":"#ffd700","goldenrod":"#daa520","gray":"#808080","green":"#008000","greenyellow":"#adff2f","honeydew":"#f0fff0","hotpink":"#ff69b4","indianred ":"#cd5c5c","indigo ":"#4b0082","ivory":"#fffff0","khaki":"#f0e68c","lavender":"#e6e6fa","lavenderblush":"#fff0f5","lawngreen":"#7cfc00","lemonchiffon":"#fffacd","lightblue":"#add8e6","lightcoral":"#f08080","lightcyan":"#e0ffff","lightgoldenrodyellow":"#fafad2","lightgrey":"#d3d3d3","lightgreen":"#90ee90","lightpink":"#ffb6c1","lightsalmon":"#ffa07a","lightseagreen":"#20b2aa","lightskyblue":"#87cefa","lightslategray":"#778899","lightsteelblue":"#b0c4de","lightyellow":"#ffffe0","lime":"#00ff00","limegreen":"#32cd32","linen":"#faf0e6","magenta":"#ff00ff","maroon":"#800000","mediumaquamarine":"#66cdaa","mediumblue":"#0000cd","mediumorchid":"#ba55d3","mediumpurple":"#9370d8","mediumseagreen":"#3cb371","mediumslateblue":"#7b68ee","mediumspringgreen":"#00fa9a","mediumturquoise":"#48d1cc","mediumvioletred":"#c71585","midnightblue":"#191970","mintcream":"#f5fffa","mistyrose":"#ffe4e1","moccasin":"#ffe4b5","navajowhite":"#ffdead","navy":"#000080","oldlace":"#fdf5e6","olive":"#808000","olivedrab":"#6b8e23","orange":"#ffa500","orangered":"#ff4500","orchid":"#da70d6","palegoldenrod":"#eee8aa","palegreen":"#98fb98","paleturquoise":"#afeeee","palevioletred":"#d87093","papayawhip":"#ffefd5","peachpuff":"#ffdab9","peru":"#cd853f","pink":"#ffc0cb","plum":"#dda0dd","powderblue":"#b0e0e6","purple":"#800080","red":"#ff0000","rosybrown":"#bc8f8f","royalblue":"#4169e1","saddlebrown":"#8b4513","salmon":"#fa8072","sandybrown":"#f4a460","seagreen":"#2e8b57","seashell":"#fff5ee","sienna":"#a0522d","silver":"#c0c0c0","skyblue":"#87ceeb","slateblue":"#6a5acd","slategray":"#708090","snow":"#fffafa","springgreen":"#00ff7f","steelblue":"#4682b4","tan":"#d2b48c","teal":"#008080","thistle":"#d8bfd8","tomato":"#ff6347","turquoise":"#40e0d0","violet":"#ee82ee","wheat":"#f5deb3","white":"#ffffff","whitesmoke":"#f5f5f5","yellow":"#ffff00","yellowgreen":"#9acd32"};
				if (typeof colors[ $color.toLowerCase() ] != 'undefined' )
					return colors[ $color.toLowerCase() ];
			
				return $color;
			},
			// Converts a color object to an RGBA array
			colorObjToRGBA : function( $color, $opacity ) {
				if ( !$color || $color == 'transparent' )
					return [255,255,255,0];
				else if ( $color.constructor == Array )
					return $color;
				else if ( "string" == typeof $color ) {
					if ( $color.substr( 0, 3 ) == "rgb" ) {
						var re = /rgb?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/;
						var segs = re.exec( $color );
						return !segs ? segs : [parseInt(segs[1], 10), parseInt(segs[2], 10), parseInt(segs[3], 10), parseInt(void 0 == segs[4] ? 255 : segs[4], 10)];
					} else {
						var c = types.color.hexToRGBA( types.color.colorNameToHex( $color ) );
						if ( $opacity != null )
							c[3] = Math.round( $opacity * 255 );
						return c;
					}
				} else if ( typeof $color === 'array' ) {
					var c = $color;
					if ( $opacity != null )
						c[3] = Math.round( $opacity * 255 );
					return c;
				}
			}
		}
	} );

	/*******************************\
	|------- DISPLAY ELEMENTS ------|
	\*******************************/
	
	/**
	 * Element class
	 * This is the base class for all display objects
	 **/
	$$class.create( { 
		namespace : 'element',
		constructor : function( $id, $state ) {
			var np = ( !!$state ) ? $state.props : null;
			var p = {};
			$.extend( true, p, this.props );
			$.extend( true, p, np );
			this.node = $(this.markup).get( 0 );
			this.entity( this.className );
			this.fluxid( $id );
			//types.style.normalisePropStack( p );
			this.applyProperties( { props : p } );
			this.data( $state );
			//this.stateName();
			this.$node().data( 'currentInstance', this );
			this.playhead( { direction: 1 } );
			if ( !!$state && $state.children ) {
				for ( indx in $state.children.keys ) {
					var child = $state.children.hash[$state.children.keys[indx]];
					if ( !!child ) {
						var l = new types[child.type]( $state.children.keys[indx], child.states._default );
						this.$node().append( l.node );
						if ( !!l.initialise )
							l.initialise( child.states._default );
					}
				}
			}
			this.gotoState( '_default' );
			var b = $state.behaviour;
			if ( !!b )
				for ( var i in b ) {
					if ( b.hasOwnProperty( i ) ) {
						if ( !!b[i].action ) 
							this.$node().bind( i, { caller : this, event : b[i] }, function( e ) {
								e.data.caller.parentInstance().doAction( e.data.event.action, e.data.event );
							} );
						if ( !!b[i].event )
							eventDispatcher.bind( this.$node(), i, b[i].event );	
					}
				}
		},
		fields : {
			markup : '<div />',
			props : {
				'position' : 'absolute',
				'padding' : 0,
				'margin' : 0,
				'box-sizing' : 'border-box',
				'vertical-align' : 'baseline',
				'word-wrap' : 'break-word',
				'max-width' : 'none',
				'max-height' : 'none',
				'zoom' : 1,
				'overflow' : 'hidden',
				'border' : 'solid',
				'border-radius' : 0,
				'border-width' : 0,
				'border-color' : { rgb: [0,0,0,0] },
				'border-style' : 'solid'
			}
		},
		methods : {
			// The individual object id
			fluxid : function( value ) {
				if ( !!value )
					this.$node().attr( 'fluxid', value );
				return this.$node().attr( 'fluxid' );
			},
			// The string representation of its class
			entity : function( value ) {
				if ( !!value )
					this.$node().attr( 'entity', value );
				return this.$node().attr( 'entity' );
			},
			// Any element's entity
			elementsEntity : function( $elem ) {
				return $elem.context.attributes[ 0 ].value;
			},
			// The class nodes parent --- Lee, I've changed 'node()' to '$node()'
			parentNode : function() {
				return this.$node().parent();
			},
			// Add a child element (would be better in the 'input' class when multilevel inheritance works)
			addChild : function ( $id, $elem, $marker, $value, $type, $group, $chosen ) {
				$chosen = !$chosen ? '' : ' ' + $chosen; // Typically 'selected' or 'checked'
				$value = !$value ? '' : ' value="' + $value + '"';
				$type = !$type ? '' : ' type="' + $type + '"';
				$group = !$group ? '' : ' name="' + $group + '"';
				$id.append( '<' + $elem + $type + $value + $group + $chosen + ' >' + $marker + '</' + $elem + '><br />' );
			},
			// Remove any number of children from an element (passed as a JQuery element)
			// (would be better in the 'input' class when multilevel inheritance works)
			removeChild: function ( $id, $html, $value, $position ) {
				if ( !$html && !$value && !$position )
					$id.empty();
				else
					for ( option in $id )
						if ( $id[option].html() === $html || $id[option].val === $value || option === $position )
							$id[option].remove();
			},
			// The class of the class nodes parent
			parentInstance : function() {
				return types.element.getInstance( this.$node().parent().get( 0 ) );
			},
			// data (JSON segment relative to this class instance) for this node.
			data : function( $data ) {
				if ( !!$data )
					this.$node().data( 'nodeData', $data );
				return this.$node().data( 'nodeData' );
			},
			// The class' underlying HTML node.
			$node : function() {
				return $(this.node);
			},
			// Perform any actions required after this object has been appended to the DOM
			initialise : function( $state ) {
				if ( !!$state && !!$state.attr )
					this.applyAttributes( $state.attr );
			},
			// Set the playhead direction
			playhead : function( $data ) {
				if ( !!$data )
					this.$node().data( 'playhead', $data );
				return this.$node().data( 'playhead' );
			},
			// The current state name
			stateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'currentState', $stateName );
				return this.$node().data( 'currentState' );
			},
			// The state name this node is currently transitioning to
			// or has transitioned to (if stateName === nextStateName)
			nextStateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'nextState', $stateName );
				return this.$node().data( 'nextState' );
			},
			// Applies a given list of properties to the node via animation.
			applyProperties : function( $props, $state ) {
				if ( !!$props && $props.props )
					types.tween.animate( this.node, $props.props, ( !!$state ? $state.duration : null ), ( !!$state ? $state.easing : null ), ( !!$state ? $state.complete : null ) );
			},
			// Applies attributes to the current node (currently, only anchoring is supported)
			applyAttributes : function( $attr ) {
				if ( this.$node().parent().length < 1 ) return;
				if ( $attr != null && $attr.anchor != null && $attr.anchor.constructor == Array ) {
					var $a = $attr.anchor.slice(0);
					switch ( $a.length ) {
						case 1:
							var v = $a[0];
							$a = [v,v,v,v];
							break;
						case 2:
							var v = $a[0], w = $a[1];
							$a = [v,w,v,w];
							break;
						case 3:
							$a[3] = $a[2];
							break;
						default:
							break;
					}
					var p = this.$node().parent();
					var t = this.$node();
					var top = ( isNaN( parseInt( t.css( 'top' ), 10 ) ) ) ? 0 : parseInt( t.css( 'top' ), 10 );
					var left = ( isNaN( parseInt( t.css( 'left' ), 10 ) ) ) ? 0 : parseInt( t.css( 'left' ), 10 );
					var loc = [top, p.width() - t.width() - left, p.height() - t.height() - top, left];
					p.resize( function() {
						if ( $a[1] != 0 ) {
							if ( $a[3] != 0 )
								t.width( p.width() - left - loc[1] );
							else
								t.css( { left: p.width() - t.width() - loc[1] } );
						}
						if ( $a[2] != 0 ) {
							if ( $a[0] != 0 )
								t.height( p.height() - top - loc[2] );
							else
								t.css( { top: p.height() - t.height() - loc[2] } );
						}
					} );
				}
			},
			
			// Sets the nodes background gradient (do not call directly. Call setStyle, instead).
			setBackground : function( $colors, $fillType ) {
				$fillType = $fillType || 'solid';
				var bg = types.style.normaliseFill( { type : $fillType, colors : [{ rgb : $colors[0].rgb.slice(0), opacity : 0 }, { rgb : $colors[1].rgb.slice(0), opacity : 0 }] } );
				this.$node().css( 'filter', bg.filter );
				for ( var c = 0; c < bg.background.length; c++ )
					this.$node().css( 'background', bg.background[c] );
				this.props.fill.colors = [ $colors[0], $colors[1] ];
				this.props.fill.type = $fillType;
			},
			// Sets the nodes border radius (do not call directly. Call setStyle, instead).
			setBorderRadius : function( $radius ) {
				$radius = types.style.normaliseBorder( $radius );
				this.$node().css( 'border-radius', Math.round( $radius ) );
				this.props['border-radius'] = $radius;
			},
			// Sets a style on the node
			setStyle : function( $prop, $value ) {
				switch( $prop ) {
					case 'background-image' :
						this.setBackground( [{ rgb : $value.color1 }, { rgb : $value.color2 }], $value.type );
						break;
					case 'border-radius' :
						this.setBorderRadius( $value );
						break;
					default :
						this.props[$prop] = $value;
						if ( typeof $value == 'object' && $value.rgb != null )
							$value.rgb = types.color.RGBAToString( $value.rgb );
						if ( types.style.isNumeric( $prop ) )
							$value = $value + 'px';
						this.$node().css( $prop, $value );
						break;
				}
			},
			
			// Performs a given action (from string)
			doAction : function( $action, $data ) {
				this[$action]( $data );
			},
			// Action. Do not call directly (call gotoNextState)
			play : function() {
				if ( this.playhead().direction == 1 )
					this.gotoNextState();
				else
					this.gotoPrevState();
			},
			// Action. Do not call directly (call gotoState)
			gotoFrame : function( $data ) {
				this.gotoState( $data.frameId );
			},
			// Action.
			gotoUrl : function( $data ) {
				if ( $data.target == "_blank" )
					window.open( $data.url, '_blank' );
				else
					window.location.href = $data.url;
			},
			// Transitions the node to the next state in the state list
			gotoNextState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i >= d.frames.keys.length - 1 ) ? d.frames.keys[0] : d.frames.keys[i + 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
				this.playhead().direction = 1;
			},
			// Transitions the node to the previous state in the state list
			gotoPrevState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i <= 0 ) ? d.frames.keys[d.frames.keys.length - 1] : d.frames.keys[i - 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
				this.playhead().direction = 0;
			},
			// Transitions the node to a given state
			gotoState : function( $state ) {
				var d = this.data();
				var s = '_default';
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == $state ) {
							s = d.frames.keys[i];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
			},
			// Handles the state change (do not call directly).
			changeState : function( $stateName, $stateData ) {
				
				// if the previous state and current state match, then there's nothing to do
				if ( $stateName == this.stateName() )
					return;
				
				// if we have no frames or children, theres no point continuing
				if ( !( !!$stateData.frames && !!$stateData.frames.hash[$stateName] && !!$stateData.children ) ) 
					return;
				
				// set base transform values
				var duration = settings.defaultTransform.duration;
				var easing = settings.defaultTransform.easing;
				var completeAction = settings.defaultTransform.after;
				
				// store the new state names for merging
				var nextStateNames = [];
				nextStateNames.push( "_default" );
				if ( $stateName != "_default" )
					nextStateNames.push( $stateName );
					
				var curStateNames = [];
				if ( !!this.stateName() ) {
					curStateNames.push( "_default" );
					if ( this.stateName() != "_default" )
						curStateNames.push( this.stateName() );
				}
				
				// get the next state data
				var nextState = $stateData.frames.hash[$stateName];
				
				// if the next state has a transition, lets update the default transition values
				if ( !!nextState.transition ) {
					duration = nextState.transition.duration || duration;
					easing = nextState.transition.easing || easing;
					completeAction = nextState.transition.after || completeAction;
				}
				
				// once the transition is over, we're probably going to have a transition complete action
				// on the parent, so we need to setup a callback to handle this.
				var me = this;
				var callback = function() {
					if ( !!me  && !!me.pendingAction ) {
						me.stateName( $stateName );
						var pa = me.pendingAction;
						delete me.pendingAction;
						me.doAction( pa );
					}
				};
				
				// if the parent has a pending action (when the transition is complete), let's set that now.
				if ( completeAction != "stop" )
					this.pendingAction = completeAction;
					
				// now we know what our transition parameters will be, let's enforce them on the state object
				var transition = { duration : duration, easing : easing, complete : callback };
				
				// now for the intensive part.  we need to animate / transition the children.
				for ( c in $stateData.children.keys ) {
					var name = $stateData.children.keys[c];
					var child = $stateData.children.hash[name];
					
					// this will contain the prop values to transition
					var props = {};
					// and this will contain the current element props
					var curProps = {};
					
					if ( !!child.states ) {
						for ( var u in nextStateNames )
							if ( !!child.states[nextStateNames[u]] )
								$.extend( true, props, child.states[nextStateNames[u]] );
						for ( var u in curStateNames )
							if ( !!child.states[curStateNames[u]] )
								$.extend( true, curProps, child.states[curStateNames[u]] );
					}
					
					// get animate-able prop values where the previous state and next
					// state properties merge and differ
					var diff = {};
					
					if ( !types.style.getPropertyDiff( curProps, props, diff ) ) {
						this.stateName( $stateName );
						continue;
					}
					
					//types.style.normalisePropStack( diff.props );
					var n = types.element.getInstance( this.$node().find("[fluxid='" + name + "']") );
					this.stateName( $stateName );
					if ( !!n && !!n.applyProperties )
						n.applyProperties( diff, transition );
				}
			}
		},
		statics : {
			// Returns the passed $node's class instance.
			getInstance : function( $node ) {
				return $($node).data( 'currentInstance' );
			}
		}
	} );
	
	/**
	 * Image class
	 * Provides for the HTML img tag
	 **/
	$$class.create( {
		namespace : 'image',
		fields : {
			markup : '<img />'
		},
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.src )
				this.$node().attr( 'src', assets[$state.src].url );
		},
		methods : {
			applyProperties : function( $props, $state ) {
				if ( !!$props.props )
					types.tween.animate( this.node, $props.props, !!$state ? $state.duration : null, !!$state ? $state.easing : null, !!$state ? $state.complete : null );
				if ( !!$props && !!$props.src && !!assets[$props.src] )
					this.$node().attr( 'src', assets[$props.src].url );
			}
		}
	} );
	
	/**
	 * Button class (Lee, should this have 'fields.markup' as '<button />'?)
	 * Provides for mouse interactivity, complete with button specific states. 
	 **/
	$$class.create( {
		namespace : 'button',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.$node().css( 'cursor', 'pointer' );
			this.$node().bind( 'mouseenter', { element : this, stateName : '_over', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseleave', { element : this, stateName : '_default', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mousedown', { element : this, stateName : '_down', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseup', { element : this, stateName : '_over', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} );
		}
	} );
	
	/**
	 * Label class (Given that 'label' is a HTML element, should we change this class' name?)
	 **/
	$$class.create( {
		namespace : 'label',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.text )
				this.$node().html( $state.text );
		},
		fields : {
			props : {
				'overflow' : 'hidden',
				'font-family' : 'arial',
				'font-size' : 12
			}
		}
	} );
	
	/**
	 * TextArea class
	 * Provides for the textarea HTML tag
	 **/
	$$class.create( {
		namespace : 'textarea',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !!$state.text )
				this.$node().html( types.system.htmlEncode( $state.text ) );
		},
		fields : {
			markup : '<textarea />'
		},
		inherits : types.element
	} );
	
	/**
	 * Input class (currently redundant)
	 * Provides for the input HTML tag. Should ideally be inherited by the Radiogroup, Checkboxgroup &c. classes.
	 **/
	$$class.create( {
		namespace : 'input',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
		},
		fields : {
			markup : '<input />'
		},
		inherits : types.element
	} );
	
	/**
	 * Text class
	 * Provides for the input text and password HTML tags. If the 'text' field is not 'password' then its text input
	 **/
	$$class.create( {
		namespace : 'text',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( $state.text === "password" ) {
				this.$node().attr( 'type', 'password' );
			} else {
				this.$node().attr( 'type', 'text' );
				if ( !!$state.text )
					this.$node().val( types.system.htmlEncode( $state.text ) );
			}
		},
		fields : {
			markup : '<input />'
		},
		inherits : types.element
	} );
	
	/**
	 * Checkboxgroup class
	 * Provides for the input checkbox HTML tag
	 **/
	$$class.create( {
		namespace : 'checkboxGroup',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'input', elText, $state.subElVals[subElem], 'checkbox', text );
			}
		},
		fields : {
			markup : '<div class="checkboxGroup" />'
		},
		inherits : types.element
	} );
	
	/**
	 * Radiogroup class
	 * Provides for the input radio HTML tag
	 **/
	$$class.create( {
		namespace : 'radioGroup',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'input', elText, $state.subElVals[subElem], 'radio', text );
			}
		},
		fields : {
			markup : '<div class="radioGroup" />'
		},
		inherits : types.element
	} );
	
	/**
	 * Dropdown class
	 * Provides for the select HTML tag
	 **/
	$$class.create( {
		namespace : 'dropDown',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'option', elText, $state.subElVals[subElem], text );
			}
		},
		fields : {
			markup : '<select />'
		},
		inherits : types.element
	} );
	
	/**
	 * Openselect class
	 * Provides for multiple lined select HTML tag
	 **/
	$$class.create( {
		namespace : 'openSelect',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			this.$node().attr( 'size', $state.subElems.length );
			if ( !$state.text ) { var text = null } else { var text = $state.text };
			for (  subElem in $state.subElems ) {
				var elText = $state.subElems[subElem];
				this.addChild ( this.$node(), 'option', elText, $state.subElVals[subElem], text );
			}
		},
		fields : {
			markup : '<select />'
		},
		inherits : types.element
	} );

	// stores global fluxui settings
	var settings = flux.settings = {
		debug : false,
		defaultTransform : {
			duration : 300,
			easing : "linearTween",
			after : "stop"
		}
	};

	// logs important debug messages to the browser
	flux.log = function( $msg ) {
		if ( this.settings.debug ) {
			if ( !!window.console && !!window.console.log ) {
				var log = Function.prototype.bind.call( console.log, console );
				log.apply( console, arguments );
			} else {
				alert( $msg );
			}
		}
	};

} )( jQuery );
