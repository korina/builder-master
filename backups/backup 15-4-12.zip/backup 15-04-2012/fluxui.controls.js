$(document).ready( function() {
	var $$class = $.fn.fluxui.$class;
	var types = $.fn.fluxui.types;
	
	$$class.create( {
		namespace : 'accordion',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.data.hash.button ) {
				var c = this.$node().children();
				for ( var i = 0; i < c.length; i++ ) {
					var child = $state.data.hash.button;
					var l = new types.button( 'button', child.states._default );
					l.applyProperties( { props: { position: 'relative' } } );
					var p = $(c[i]).wrap( '<div></div>' ).parent();
					p.prepend( l.node );
					l.applyProperties( { props: { width: this.width } }, $state );
					l.$node().find( "div[fluxid='label']" ).html( types.element.getInstance( c[i] ).text );
					$(c[i]).hide();
					if ( !!l.initialise )
						l.initialise( child.states._default );
					var acc = this;
					l.$node().bind( 'click', function( evt ) {
						acc.handleClick( evt.currentTarget );
					} );
				}
			}
		},
		methods: {
			handleClick: function( $btn ) {
				var panel = $($btn).next()[0];
				this.$node().find( "div[entity='accordionPanel']" ).each( function() {
					console.log( this, panel );
					if ( this == panel )
						$(this).show( 'fast' );
					else
						$(this).hide( 'fast' );
				} );
			}
		}
	} );
	
	$$class.create( {
		namespace : 'accordionPanel',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.applyProperties( { props: { position: 'relative' } }, $state );
			this.text = $state.text;
		},
		fields : {
			props : {
				position: 'relative'
			},
			text : ''
		}
	} );
} );