$(window).load( function() {

	$().fluxui.initialise( { debug : true } );

	var editor =  {
		assets : {
			
		},
		library: {
			
		},
		movie : {
			states: {
				_default: {
					props: {
						width: 500,
						height: 472,
						fill: {
							type: 'solid',
							colors: [
								{
									rgb: '#000000',
									opacity: 1
								}
							]
						}
					},
					attr: {
						anchor: [ 1, 1, 1, 1 ]
					},
					frames: {
						keys: [],
						hash: {}
					},
					children: {
						keys: [ 'header', 'sidebar', 'workspace' ],
						hash: {
							header: {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'linear',
												direction: 'top',
												colors: [
													{
														rgb: '#cccccc',
														opacity: 1,
														pos: 0
													},
													{
														rgb: '#ffffff',
														opacity: 1,
														pos: 0.5
													},
													{
														rgb: '#cccccc',
														opacity: 1,
														pos: 1
													}
												]
											},
											width: 500,
											height: 70
										},
										attr: {
											anchor: [ 1, 1, 0, 1 ]
										}
									}
								}
							},
							sidebar: {
								type: 'element',
								states: {
									_default: {
										props: {
											top: 72,
											left: 200,
											width: 300,
											height: 400
										},
										attr: {
											anchor: [ 1, 1, 1, 0 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children: {
											keys: [ 'panels' ],
											hash: {
												panels: {
													type: 'accordion',
													states: {
														_default: {
															props: {
																fill: {
																	type: 'solid',
																	colors: [
																		{
																			rgb: '#cccccc',
																			opacity: 1
																		}
																	]
																},
																width: 300,
																height: 400,
																'overflow-y': 'auto'
															},
															attr: {
																anchor: [ 1, 1, 1, 1 ]
															},
															data: {
																keys: [ 'button' ],
																hash: {
																	button: {
																		type: 'button',
																		states: {
																			_default: {
																				props: {
																					fill: {
																						type: 'linear',
																						direction: 'top',
																						colors: [
																							{
																								rgb: '#cccccc',
																								opacity: 1,
																								pos: 0
																							},
																							{
																								rgb: '#ffffff',
																								opacity: 1,
																								pos: 0.5
																							},
																							{
																								rgb: '#cccccc',
																								opacity: 1,
																								pos: 1
																							}
																						]
																					},
																					'border-width': '0 0 1px 0',
																					'border-color': '#333333',
																					'border-style': 'solid',
																					width: 300,
																					height: 100
																				},
																				frames: {
																					keys: [],
																					hash: {}
																				},
																				children: {
																					keys: [ 'label' ],
																					hash: {
																						label: {
																							type: 'label',
																							states: {
																								_default: {
																									text: 'Button',
																									props: {
																										color: '#666666',
																										top: 40,
																										left: 30,
																										'font-size': 16
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															},
															frames: {
																keys: [],
																hash: {}
															},
															children: {
																keys: [ 'panel1', 'panel2', 'panel3' ],
																hash: {
																	panel1: {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Properties',
																				props: {
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#cc0000',
																								opacity: 1
																							}
																						]
																					},
																					width: 300,
																					height: 200
																				}
																			}
																		}
																	},
																	panel2: {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Library',
																				props: {
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#0000cc',
																								opacity: 1
																							}
																						]
																					},
																					width: 300,
																					height: 200
																				}
																			}
																		}
																	},
																	panel3: {
																		type: 'accordionPanel',
																		states: {
																			_default: {
																				text: 'Components',
																				props: {
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#00cc00',
																								opacity: 1
																							}
																						]
																					},
																					width: 300,
																					height: 200
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							},
							workspace: {
								type: 'element',
								states: {
									_default: {
										props: {
											fill: {
												type: 'solid',
												colors: [
													{
														rgb: '#666666',
														opacity: 1
													}
												]
											},
											top: 72,
											width: 198,
											height: 400,
											'overflow': 'auto'
										},
										attr: {
											anchor: [ 1, 1, 1, 1 ]
										},
										frames: {
											keys: [],
											hash: {}
										},
										children:{
											keys: [ 'stage-container' ],
											hash: {
												'stage-container': {
													type: 'element',
													states: {
														_default: {
															props: {
																fill: {
																	type: 'solid',
																	colors: [
																		{
																			rgb: '#666666',
																			opacity: 1
																		}
																	]
																},
																'min-height': 1000,
																'min-width': 1000
															},
															frames: {
																keys: [],
																hash: {}
															},
															children: {
																keys: [ 'stage' ],
																hash: {
																	stage: {
																		type: 'element',
																		states: {
																			_default: {
																				props: {
																					fill: {
																						type: 'solid',
																						colors: [
																							{
																								rgb: '#FFFFFF',
																								opacity: 1
																							}
																						]
																					},
																					width: 400,
																					height: 300
																				},
																				
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

    var data = $('#movie-container').fluxui( editor );
	$('body').css( { overflow: 'hidden', margin: 0, padding: 0 } );
	$(window).resize( function() {
		$('#movie-container').width( $(this).width() );
		$('#movie-container').height( $(this).height() );
	} ).trigger( 'resize' );
	data.eventDispatcher.addListener( 'this.is.an.event', function() {
		console.log( 'this.is.an.event' );
	} )
	data.eventDispatcher.addListener( 'this.is.an.*', function() {
		console.log( 'this.is.an.*' );
	} )
	data.eventDispatcher.addListener( 'this.is.*', function() {
		console.log( 'this.is.*' );
	} )
	data.eventDispatcher.addListener( 'this.is.one.*', function() {
		console.log( 'this.is.one.*' ); // will fail, as it's not in the namespace
	} )
} );