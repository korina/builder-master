(function (q) {
    var r = function () {
            return Array.prototype.slice.call(arguments).join("")
        },
        D = function (q) {
            if (null === q) return null;
            if ("object" === typeof q) {
                var d = {},
                    i;
                "undefined" !== typeof q.length && (d = []);
                for (i in q) q.hasOwnProperty(i) && ("object" === typeof q[i] ? d[i] = D(q[i]) : "string" === typeof q[i] ? d[i] = q[i] : "number" === typeof q[i] ? d[i] = q[i] : "boolean" === typeof q[i] && (d[i] = !0 === q[i] ? !0 : !1));
                return d
            }
            return q
        },
        y = function () {
            var r = {
                aliceblue: "#f0f8ff",
                antiquewhite: "#faebd7",
                aqua: "#00ffff",
                aquamarine: "#7fffd4",
                azure: "#f0ffff",
                beige: "#f5f5dc",
                bisque: "#ffe4c4",
                black: "#000000",
                blanchedalmond: "#ffebcd",
                blue: "#0000ff",
                blueviolet: "#8a2be2",
                brown: "#a52a2a",
                burlywood: "#deb887",
                cadetblue: "#5f9ea0",
                chartreuse: "#7fff00",
                chocolate: "#d2691e",
                coral: "#ff7f50",
                cornflowerblue: "#6495ed",
                cornsilk: "#fff8dc",
                crimson: "#dc143c",
                cyan: "#00ffff",
                darkblue: "#00008b",
                darkcyan: "#008b8b",
                darkgoldenrod: "#b8860b",
                darkgray: "#a9a9a9",
                darkgrey: "#a9a9a9",
                darkgreen: "#006400",
                darkkhaki: "#bdb76b",
                darkmagenta: "#8b008b",
                darkolivegreen: "#556b2f",
                darkorange: "#ff8c00",
                darkorchid: "#9932cc",
                darkred: "#8b0000",
                darksalmon: "#e9967a",
                darkseagreen: "#8fbc8f",
                darkslateblue: "#483d8b",
                darkslategray: "#2f4f4f",
                darkslategrey: "#2f4f4f",
                darkturquoise: "#00ced1",
                darkviolet: "#9400d3",
                deeppink: "#ff1493",
                deepskyblue: "#00bfff",
                dimgray: "#696969",
                dimgrey: "#696969",
                dodgerblue: "#1e90ff",
                firebrick: "#b22222",
                floralwhite: "#fffaf0",
                forestgreen: "#228b22",
                fuchsia: "#ff00ff",
                gainsboro: "#dcdcdc",
                ghostwhite: "#f8f8ff",
                gold: "#ffd700",
                goldenrod: "#daa520",
                gray: "#808080",
                grey: "#808080",
                green: "#008000",
                greenyellow: "#adff2f",
                honeydew: "#f0fff0",
                hotpink: "#ff69b4",
                "indianred ": "#cd5c5c",
                "indigo ": "#4b0082",
                ivory: "#fffff0",
                khaki: "#f0e68c",
                lavender: "#e6e6fa",
                lavenderblush: "#fff0f5",
                lawngreen: "#7cfc00",
                lemonchiffon: "#fffacd",
                lightblue: "#add8e6",
                lightcoral: "#f08080",
                lightcyan: "#e0ffff",
                lightgoldenrodyellow: "#fafad2",
                lightgray: "#d3d3d3",
                lightgrey: "#d3d3d3",
                lightgreen: "#90ee90",
                lightpink: "#ffb6c1",
                lightsalmon: "#ffa07a",
                lightseagreen: "#20b2aa",
                lightskyblue: "#87cefa",
                lightslategray: "#778899",
                lightslategrey: "#778899",
                lightsteelblue: "#b0c4de",
                lightyellow: "#ffffe0",
                lime: "#00ff00",
                limegreen: "#32cd32",
                linen: "#faf0e6",
                magenta: "#ff00ff",
                maroon: "#800000",
                mediumaquamarine: "#66cdaa",
                mediumblue: "#0000cd",
                mediumorchid: "#ba55d3",
                mediumpurple: "#9370d8",
                mediumseagreen: "#3cb371",
                mediumslateblue: "#7b68ee",
                mediumspringgreen: "#00fa9a",
                mediumturquoise: "#48d1cc",
                mediumvioletred: "#c71585",
                midnightblue: "#191970",
                mintcream: "#f5fffa",
                mistyrose: "#ffe4e1",
                moccasin: "#ffe4b5",
                navajowhite: "#ffdead",
                navy: "#000080",
                oldlace: "#fdf5e6",
                olive: "#808000",
                olivedrab: "#6b8e23",
                orange: "#ffa500",
                orangered: "#ff4500",
                orchid: "#da70d6",
                palegoldenrod: "#eee8aa",
                palegreen: "#98fb98",
                paleturquoise: "#afeeee",
                palevioletred: "#d87093",
                papayawhip: "#ffefd5",
                peachpuff: "#ffdab9",
                peru: "#cd853f",
                pink: "#ffc0cb",
                plum: "#dda0dd",
                powderblue: "#b0e0e6",
                purple: "#800080",
                red: "#ff0000",
                rosybrown: "#bc8f8f",
                royalblue: "#4169e1",
                saddlebrown: "#8b4513",
                salmon: "#fa8072",
                sandybrown: "#f4a460",
                seagreen: "#2e8b57",
                seashell: "#fff5ee",
                sienna: "#a0522d",
                silver: "#c0c0c0",
                skyblue: "#87ceeb",
                slateblue: "#6a5acd",
                slategray: "#708090",
                slategrey: "#708090",
                snow: "#fffafa",
                springgreen: "#00ff7f",
                steelblue: "#4682b4",
                tan: "#d2b48c",
                teal: "#008080",
                thistle: "#d8bfd8",
                tomato: "#ff6347",
                turquoise: "#40e0d0",
                violet: "#ee82ee",
                wheat: "#f5deb3",
                white: "#ffffff",
                whitesmoke: "#f5f5f5",
                yellow: "#ffff00",
                yellowgreen: "#9acd32"
            },
                d = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/,
                i = /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
                j = {
                    hexToRGBA: function (i) {
                        i = d.exec(i);
                        return !i ? i : [parseInt(i[1], 16), parseInt(i[2], 16), parseInt(i[3], 16), 255]
                    },
                    unknownToRGBA: function (d) {
                        if ("string" == typeof d && r[d.toLowerCase()]) return j.hexToRGBA(r[d.toLowerCase()]);
                        if ("transparent" == d) return [255, 255, 255, 0];
                        var h = j.hexToRGBA(d);
                        return h ? h : (h = j.rgbaStringToRGBA(d)) ? h : [255, 255, 255, 255]
                    },
                    sixteenToHex: function (d) {
                        return 16 > d ? "0" + d.toString(16) : d.toString(16)
                    },
                    rgbaToRGBAString: function (d) {
                        return ["rgba(", [d[0], d[1], d[2], d[3] / 255].join(), ")"].join("")
                    },
                    rgbaToHex: function (d) {
                        return ["#", j.sixteenToHex(d[0]), j.sixteenToHex(d[1]), j.sixteenToHex(d[2])].join("")
                    },
                    rgbaToIEHex: function (d) {
                        return ["#", j.sixteenToHex(d[3]), j.sixteenToHex(d[0]), j.sixteenToHex(d[1]), j.sixteenToHex(d[2])].join("")
                    },
                    rgbaStringToRGBA: function (d) {
                        d = i.exec(d);
                        return !d ? d : [parseInt(d[1], 10), parseInt(d[2], 10), parseInt(d[3], 10), parseInt(void 0 == d[4] ? 255 : d[4], 10)]
                    },
                    stepRGBA: function (d, h, i) {
                        return q.map(h, function (j, n) {
                            return h[n] + Math.round(d * (i[n] - h[n]))
                        })
                    }
                };
            return j
        }(),
        M = function () {
            var q = {
                linearTween: function (d, i, j, m) {
                    return j * d / m + i
                },
                easeInQuad: function (d, i, j, m) {
                    return j * (d /= m) * d + i
                },
                easeOutQuad: function (d, i, j, m) {
                    return -j * (d /= m) * (d - 2) + i
                },
                easeInOutQuad: function (d, i, j, m) {
                    return 1 > (d /= m / 2) ? j / 2 * d * d + i : -j / 2 * (--d * (d - 2) - 1) + i
                },
                easeInCubic: function (d, i, j, m) {
                    return j * (d /= m) * d * d + i
                },
                easeOutCubic: function (d, i, j, m) {
                    return j * ((d = d / m - 1) * d * d + 1) + i
                },
                easeInOutCubic: function (d, i, j, m) {
                    return 1 > (d /= m / 2) ? j / 2 * d * d * d + i : j / 2 * ((d -= 2) * d * d + 2) + i
                },
                easeInQuart: function (d, i, j, m) {
                    return j * (d /= m) * d * d * d + i
                },
                easeOutQuart: function (d, i, j, m) {
                    return -j * ((d = d / m - 1) * d * d * d - 1) + i
                },
                easeInOutQuart: function (d, i, j, m) {
                    return 1 > (d /= m / 2) ? j / 2 * d * d * d * d + i : -j / 2 * ((d -= 2) * d * d * d - 2) + i
                },
                easeInQuint: function (d, i, j, m) {
                    return j * (d /= m) * d * d * d * d + i
                },
                easeOutQuint: function (d, i, j, m) {
                    return j * ((d = d / m - 1) * d * d * d * d + 1) + i
                },
                easeInOutQuint: function (d, i, j, m) {
                    return 1 > (d /= m / 2) ? j / 2 * d * d * d * d * d + i : j / 2 * ((d -= 2) * d * d * d * d + 2) + i
                },
                easeInSine: function (d, i, j, m) {
                    return -j * Math.cos(d / m * (Math.PI / 2)) + j + i
                },
                easeOutSine: function (d, i, j, m) {
                    return j * Math.sin(d / m * (Math.PI / 2)) + i
                },
                easeInOutSine: function (d, i, j, m) {
                    return -j / 2 * (Math.cos(Math.PI * d / m) - 1) + i
                },
                easeInExpo: function (d, i, j, m) {
                    return 0 == d ? i : j * Math.pow(2, 10 * (d / m - 1)) + i
                },
                easeOutExpo: function (d, i, j, m) {
                    return d == m ? i + j : j * (-Math.pow(2, -10 * d / m) + 1) + i
                },
                easeInOutExpo: function (d, i, j, m) {
                    return 0 == d ? i : d == m ? i + j : 1 > (d /= m / 2) ? j / 2 * Math.pow(2, 10 * (d - 1)) + i : j / 2 * (-Math.pow(2, -10 * --d) + 2) + i
                },
                easeInCirc: function (d, i, j, m) {
                    return -j * (Math.sqrt(1 - (d /= m) * d) - 1) + i
                },
                easeOutCirc: function (d, i, j, m) {
                    return j * Math.sqrt(1 - (d = d / m - 1) * d) + i
                },
                easeInOutCirc: function (d, i, j, m) {
                    return 1 > (d /= m / 2) ? -j / 2 * (Math.sqrt(1 - d * d) - 1) + i : j / 2 * (Math.sqrt(1 - (d -= 2) * d) + 1) + i
                },
                easeInElastic: function (d, i, j, m, h, p) {
                    if (0 == d) return i;
                    if (1 == (d /= m)) return i + j;
                    p || (p = 0.3 * m);
                    h < Math.abs(j) ? (h = j, j = p / 4) : j = p / (2 * Math.PI) * Math.asin(j / h);
                    return -(h * Math.pow(2, 10 * (d -= 1)) * Math.sin((d * m - j) * 2 * Math.PI / p)) + i
                },
                easeOutElastic: function (d, i, j, m, h, p) {
                    if (0 == d) return i;
                    if (1 == (d /= m)) return i + j;
                    p || (p = 0.3 * m);
                    if (h < Math.abs(j)) var h = j,
                        t = p / 4;
                    else t = p / (2 * Math.PI) * Math.asin(j / h);
                    return h * Math.pow(2, -10 * d) * Math.sin((d * m - t) * 2 * Math.PI / p) + j + i
                },
                easeInOutElastic: function (d, i, j, m, h, p) {
                    if (0 == d) return i;
                    if (2 == (d /= m / 2)) return i + j;
                    p || (p = m * 0.3 * 1.5);
                    if (h < Math.abs(j)) var h = j,
                        t = p / 4;
                    else t = p / (2 * Math.PI) * Math.asin(j / h);
                    return 1 > d ? -0.5 * h * Math.pow(2, 10 * (d -= 1)) * Math.sin((d * m - t) * 2 * Math.PI / p) + i : 0.5 * h * Math.pow(2, -10 * (d -= 1)) * Math.sin((d * m - t) * 2 * Math.PI / p) + j + i
                },
                easeInBack: function (d, i, j, m, h) {
                    void 0 == h && (h = 1.70158);
                    return j * (d /= m) * d * ((h + 1) * d - h) + i
                },
                easeOutBack: function (d, i, j, m, h) {
                    void 0 == h && (h = 1.70158);
                    return j * ((d = d / m - 1) * d * ((h + 1) * d + h) + 1) + i
                },
                easeInOutBack: function (d, i, j, m, h) {
                    void 0 == h && (h = 1.70158);
                    return 1 > (d /= m / 2) ? j / 2 * d * d * (((h *= 1.525) + 1) * d - h) + i : j / 2 * ((d -= 2) * d * (((h *= 1.525) + 1) * d + h) + 2) + i
                }
            };
            q.easeInBounce = function (d, i, j, m) {
                return j - q.easeOutBounce(m - d, 0, j, m) + i
            };
            q.easeOutBounce = function (d, i, j, m) {
                return (d /= m) < 1 / 2.75 ? j * 7.5625 * d * d + i : d < 2 / 2.75 ? j * (7.5625 * (d -= 1.5 / 2.75) * d + 0.75) + i : d < 2.5 / 2.75 ? j * (7.5625 * (d -= 2.25 / 2.75) * d + 0.9375) + i : j * (7.5625 * (d -= 2.625 / 2.75) * d + 0.984375) + i
            };
            q.easeInOutBounce = function (d, i, j, m) {
                return d < m / 2 ? 0.5 * q.easeInBounce(2 * d, 0, j, m) + i : 0.5 * q.easeOutBounce(2 * d - m, 0, j, m) + 0.5 * j + i
            };
            return q
        }(),
        ka = function (r) {
            var d = null,
                i = {},
                j = 0,
                m = !1,
                h = {
                    easing: "linearTween",
                    duration: 300,
                    fps: 30,
                    complete: q.noop,
                    step: q.noop,
                    after: ""
                },
                p = q.extend({}, h);
            q.extend(this, {
                reset: function (j) {
                    p = q.extend({}, h, j);
                    i = {};
                    m = !1;
                    clearInterval(d)
                },
                start: function () {
                    if (m) {
                        clearInterval(d);
                        j = (new Date).getTime();
                        var h = 0 >= p.duration,
                            n = p.duration;
                        d = window.setInterval(function () {
                            h ? n = delta = 1 : delta = Math.min((new Date).getTime() - j, n);
                            var l = M[p.easing](delta, 0, 1, n);
                            q.each(i, function (d, h) {
                                r.getProperty(d).interpolate(l, h[1], h[2])
                            });
                            delta >= n && (clearInterval(d), p.complete())
                        }, Math.floor(1E3 / p.fps))
                    }
                },
                addTransition: function (d, h, l) {
                    i[d] = [d, h, l];
                    m = !0
                }
            })
        },
        ba = function (r) {
            var d = 0,
                i = 0,
                j = 1,
                m = [0, 0, 0, 255],
                h = [255, 255, 255, 255],
                p = [255, 255, 255, 255],
                t, n = q("<div style='position:absolute; left:-1px; top:-1px; border-width:0px;'></div>").appendTo(r.get$Element()).get(0),
                l, u, A = null,
                w = q.extend(this, {
                    init: function () {
                        document.namespaces["rui-vml"] || document.namespaces.add("rui-vml", "urn:schemas-microsoft-com:vml", "#default#VML");
                        document.namespaces["rui-office"] || document.namespaces.add("rui-office", "urn:schemas-microsoft-com:office");
                        t = document.createElement("rui-vml:shape");
                        t.style.position = "absolute";
                        n.appendChild(t);
                        t.style.behavior = "url(#default#VML)";
                        r.get$Element().css({
                            borderWidth: 0
                        });
                        u = document.createElement("rui-vml:stroke");
                        t.appendChild(u);
                        u.style.behavior = "url(#default#VML)";
                        (new F).listenTo(r, "afterRefreshAllProperties", function () {
                            w.invalidate()
                        })
                    },
                    render: function () {
                        var h = r.get$Element().width(),
                            l = r.get$Element().height();
                        if (!isNaN(h) && !isNaN(l)) {
                            var h = Math.round(h),
                                l = Math.round(l),
                                p = Math.round(d),
                                c = Math.round(i / 2);
                            0 < p ? (p = ["m ", p + c, ",", c, " l ", h - p - c, ",", c, " qx ", h - c, ",", p + c, " l ", h - c, ",", l - p - c, " qy ", h - p - c, ",", l - c, " l ", p + c, ",", l - c, " qx ", c, ",", l - p - c, " l ", c, ",", p + c, " qy ", p + c, ",", c, " x e"].join(""), t.connectortype = "curved") : (p = ["m ", c, ",", c, " l ", h - c, ",", c, " ", h - c, ",", l - c, " ", c, ",", l - c, " x e"].join(""), t.connectortype = "straight");
                            t.path = p;
                            t.style.width = h + "px";
                            t.style.height = l + "px";
                            t.coordsize = [h, l].join(" ");
                            0 == i ? (t.strokeweight = "0px", t.strokecolor = "none") : (t.strokeweight = i + "px", t.strokecolor = ["rgb(", m[0], ",", m[1], ",", m[2], ")"].join(""));
                            t.style.antialias = !1;
                            clearTimeout(A)
                        }
                    },
                    invalidate: function () {
                        clearTimeout(A);
                        A = setTimeout(w.render, 1)
                    },
                    setStrokeWeight: function (d) {
                        i = d;
                        w.invalidate()
                    },
                    setCornerRadius: function (h) {
                        d = h;
                        w.invalidate()
                    },
                    setWidth: function () {
                        w.invalidate()
                    },
                    setHeight: function () {
                        w.invalidate()
                    },
                    setStrokeColor: function (d) {
                        m = d;
                        w.invalidate()
                    },
                    setFill: function (d, i) {
                        h = i;
                        p = d;
                        var n = document.createElement("rui-vml:fill");
                        n.type = "gradient";
                        n.color = ["rgb(", h[0], ",", h[1], ",", h[2], ")"].join("");
                        n.color2 = ["rgb(", p[0], ",", p[1], ",", p[2], ")"].join("");
                        var c = p[3] / 255;
                        n.opacity = h[3] / 255;
                        n.setAttribute("rui-office:opacity2", c);
                        l = n;
                        t.appendChild(l);
                        l.style.behavior = "url(#default#VML)"
                    },
                    setShapeOpacity: function (d) {
                        j = d;
                        t.style.filter = 1 > j ? "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + parseFloat(100 * j) + ")" : "";
                        w.setFill(h, p)
                    }
                });
            w.init()
        },
        F = function () {
            var r = [];
            q.extend(this, {
                listenTo: function (d, i, j) {
                    d = d.getDispatcher();
                    j = d.addListener(i, j);
                    r.push({
                        dispatcher: d,
                        eventName: i,
                        key: j
                    })
                },
                release: function () {
                    q.each(r, function (d, i) {
                        i.dispatcher.removeListener(i.eventName, i.key)
                    });
                    r = []
                }
            })
        },
        L = function () {
            var r = 0,
                d = {};
            q.extend(this, {
                addListener: function (i, j) {
                    void 0 == d[i] && (d[i] = {});
                    r += 1;
                    d[i][r] = j;
                    return r
                },
                removeListener: function (i, j) {
                    delete d[i][j]
                },
                dispatch: function (i, j) {
                    void 0 != d[i] && q.each(d[i], function (d, h) {
                        h(i, j)
                    })
                },
                release: function () {
                    d = {}
                }
            })
        },
        ca = function (r) {
            var d = {
                name: "no name",
                images: {},
                elements: {}
            },
                i, j = new L,
                m = q.extend(this, {
                    instantiateElement: function (d) {
                        console.assert(m.getElementStruct(d));
                        var d = m.getElementStruct(d),
                            i = r.createElement(d.typeName);
                        i.unmarshal(d);
                        return i
                    },
                    instantiateImage: function (d) {
                        var i = m.getImageStruct(d);
                        console.assert(i);
                        var j = r.createElement("image");
                        j.set("src", d);
                        j.set("width", i.width);
                        j.set("height", i.height);
                        return j
                    },
                    eachImage: function (h) {
                        q.each(d.images, h)
                    },
                    eachElementStruct: function (h) {
                        q.each(d.elements, h)
                    },
                    setUIFileStruct: function (h) {
                        d = h;
                        j.dispatch("libraryChange", {
                            operation: "reset",
                            uifilestruct: d
                        })
                    },
                    getUIFileStruct: function () {
                        return d
                    },
                    addNewElementStruct: function (d, i, j) {
                        console.assert(void 0 === m.getElementStruct(d));
                        var n = r.createElement(i);
                        q.each(j, function (d, h) {
                            n.set(d, h)
                        });
                        i = n.marshal();
                        m.setElementStruct(d, i);
                        return i
                    },
                    setElementStruct: function (h, i) {
                        var m = void 0 === d.elements[h] ? "add" : "update";
                        d.elements[h] = D(i);
                        j.dispatch("libraryChange", {
                            operation: m,
                            name: h,
                            struct: d.elements[h]
                        })
                    },
                    getElementStruct: function (h) {
                        return D(d.elements[h])
                    },
                    renameElementStruct: function (h, i) {
                        d.elements[i] = d.elements[h];
                        delete d.elements[h];
                        j.dispatch("libraryChange", {
                            operation: "rename",
                            name: i,
                            struct: d.elements[i],
                            oldName: h
                        })
                    },
                    deleteElementStruct: function (h) {
                        var i = d.elements[h];
                        delete d.elements[h];
                        j.dispatch("libraryChange", {
                            operation: "delete",
                            name: h,
                            struct: i
                        })
                    },
                    setImageStruct: function (h) {
                        var i = void 0 == d.images[h.filename] ? "add" : "update";
                        d.images[h.filename] = h;
                        j.dispatch("libraryChange", {
                            operation: i,
                            name: h.filename,
                            struct: d.images[h.filename]
                        })
                    },
                    getImageStruct: function (h) {
                        return d.images[h]
                    },
                    setImageUrlPrefix: function (d) {
                        i = d
                    },
                    getImageUrl: function (d) {
                        var p = m.getImageStruct(d);
                        return void 0 == p ? "images/placeholder.png" : i ? i + p.filename : 0 == d.toLowerCase().indexOf("http") ? d : p.url
                    },
                    deleteImageStruct: function (h) {
                        console.assert(d.images[h]);
                        var i = d.images[h];
                        delete d.images[h];
                        j.dispatch("libraryChange", {
                            operation: "delete",
                            name: h,
                            struct: i
                        })
                    },
                    getDispatcher: function () {
                        return j
                    }
                })
        },
        G;
    G = {
        propertyDefinitions: {
            opacity: {
                canAnimate: !0,
                storeAs: "float",
                extension: "CssProperty"
            },
            "font-size": {
                canAnimate: !0,
                applyAs: "px",
                storeAs: "int",
                extension: "CssProperty"
            },
            color: {
                canAnimate: !0,
                applyAs: "color",
                preventClear: !0,
                extension: "CssColorProperty"
            },
            text: {
                extension: "LineBreakTextProperty"
            },
            height: {
                canAnimate: !0,
                storeAs: "int",
                preventClear: !0,
                extension: "CssProperty"
            },
            tabIndex: {
                extension: "AttrProperty"
            },
            "input-value": {
                extension: "InputValueProperty"
            },
            frames: {
                extension: "FramesProperty"
            },
            "font-style": {
                extension: "CssProperty"
            },
            fill: {
                canAnimate: !0,
                applyAs: "color",
                preventClear: !0,
                extension: "BoxFillProperty"
            },
            "overflow-y": {
                extension: "CssProperty"
            },
            "overflow-x": {
                extension: "CssProperty"
            },
            layout: {
                extension: "LayoutProperty"
            },
            title: {
                extension: "AttrProperty"
            },
            top: {
                canAnimate: !0,
                storeAs: "int",
                preventClear: !0,
                extension: "CssProperty"
            },
            "border-width": {
                canAnimate: !0,
                storeAs: "int",
                extension: "CssProperty"
            },
            width: {
                canAnimate: !0,
                storeAs: "int",
                preventClear: !0,
                extension: "CssProperty"
            },
            html: {
                extension: "HtmlProperty"
            },
            "font-weight": {
                extension: "CssProperty"
            },
            type: {
                extension: "AttrWriteOnceProperty"
            },
            composition: {
                extension: "CompositionProperty"
            },
            "background-color": {
                canAnimate: !0,
                applyAs: "color",
                extension: "CssColorProperty"
            },
            "border-radius": {
                canAnimate: !0,
                storeAs: "int",
                extension: "BorderRadiusProperty"
            },
            padding: {
                extension: "CssProperty"
            },
            "border-style": {
                extension: "CssProperty"
            },
            "asset-name": {
                extension: "AssetNameProperty"
            },
            "font-family": {
                extension: "CssProperty"
            },
            "text-align": {
                extension: "CssProperty"
            },
            src: {
                extension: "ImageSourceProperty"
            },
            "border-color": {
                canAnimate: !0,
                applyAs: "color",
                extension: "CssColorProperty"
            },
            name: {
                extension: "AttrProperty"
            },
            "text-decoration": {
                extension: "CssProperty"
            },
            "mouse-behavior": {
                extension: "MouseBehaviorProperty"
            },
            "line-height": {
                canAnimate: !0,
                applyAs: "px",
                storeAs: "int",
                extension: "LineHeightProperty"
            },
            left: {
                canAnimate: !0,
                storeAs: "int",
                preventClear: !0,
                extension: "CssProperty"
            }
        },
        elementTypes: [{
            isVoidElement: "TRUE",
            nodeName: "img",
            propertyOverrides: {},
            label: "Image",
            typeName: "image",
            propertyOrder: "name,left,top,width,height,opacity,src,title".split(",")
        }, {
            typeName: "text",
            propertyOverrides: {
                color: {
                    defaultValue: "black"
                },
                "overflow-y": {
                    defaultValue: "hidden"
                },
                "overflow-x": {
                    defaultValue: "hidden"
                },
                "font-size": {
                    defaultValue: 12
                },
                "font-family": {
                    defaultValue: "arial"
                }
            },
            propertyOrder: "name,left,top,width,height,overflow-x,overflow-y,opacity,font-family,font-size,line-height,color,font-style,font-weight,text-decoration,text-align,text,title".split(","),
            nodeName: "div",
            label: "Text"
        }, {
            typeName: "box",
            propertyOverrides: {
                opacity: {
                    extension: "BoxOpacityProperty"
                },
                "border-color": {
                    defaultValue: "black",
                    extension: "BoxBorderColorProperty"
                },
                "border-style": {
                    defaultValue: "solid"
                },
                "border-radius": {
                    defaultValue: 0,
                    extension: "BoxBorderRadiusProperty"
                },
                "border-width": {
                    defaultValue: 0,
                    extension: "BoxBorderWidthProperty"
                }
            },
            propertyOrder: "name,left,top,width,height,opacity,fill,border-style,border-width,border-color,border-radius,title".split(","),
            nodeName: "div",
            label: "Box"
        }, {
            typeName: "button",
            propertyOverrides: {},
            propertyOrder: "name,left,top,width,height,overflow-x,overflow-y,opacity,background-color,composition,asset-name,frames,layout,title,mouse-behavior".split(","),
            nodeName: "div",
            label: "Button"
        }, {
            typeName: "widget",
            propertyOverrides: {},
            propertyOrder: "name,left,top,width,height,overflow-x,overflow-y,opacity,background-color,composition,asset-name,frames,layout,title".split(","),
            nodeName: "div",
            label: "Container"
        }, {
            typeName: "select",
            propertyOverrides: {},
            propertyOrder: "name,left,top,width,height,padding,font-family,font-size,line-height,color,font-style,font-weight,text-decoration,text-align,background-color,border-style,border-width,border-color,tabIndex,title".split(","),
            nodeName: "select",
            label: "Select"
        }, {
            isVoidElement: "TRUE",
            nodeName: "input",
            propertyOverrides: {
                type: {
                    defaultValue: "text"
                }
            },
            label: "Input Text",
            typeName: "input_text",
            propertyOrder: "name,type,left,top,width,height,padding,font-family,font-size,line-height,color,font-style,font-weight,text-decoration,text-align,input-value,background-color,border-style,border-width,border-color,tabIndex,title".split(",")
        }, {
            isVoidElement: "TRUE",
            nodeName: "input",
            propertyOverrides: {
                type: {
                    defaultValue: "password"
                }
            },
            label: "Input Password",
            typeName: "input_password",
            propertyOrder: "name,type,left,top,width,height,padding,font-family,font-size,line-height,color,font-style,font-weight,text-decoration,text-align,input-value,background-color,border-style,border-width,border-color,tabIndex,title".split(",")
        }, {
            isVoidElement: "TRUE",
            nodeName: "input",
            propertyOverrides: {
                width: {
                    extension: "ReadOnlyWidthProperty"
                },
                type: {
                    defaultValue: "radio"
                },
                height: {
                    extension: "ReadOnlyHeightProperty"
                }
            },
            label: "Radio",
            typeName: "input_radio",
            propertyOrder: "name,type,left,top,width,height,input-value,tabIndex,title".split(",")
        }, {
            isVoidElement: "TRUE",
            nodeName: "input",
            propertyOverrides: {
                width: {
                    extension: "ReadOnlyWidthProperty"
                },
                type: {
                    defaultValue: "checkbox"
                },
                height: {
                    extension: "ReadOnlyHeightProperty"
                }
            },
            label: "Checkbox",
            typeName: "input_checkbox",
            propertyOrder: "name,type,left,top,width,height,input-value,tabIndex,title".split(",")
        }, {
            typeName: "textarea",
            propertyOverrides: {},
            propertyOrder: "name,left,top,width,height,padding,font-family,font-size,line-height,color,font-style,font-weight,text-decoration,text-align,text,background-color,border-style,border-width,border-color,tabIndex,title".split(","),
            nodeName: "textarea",
            label: "Textarea"
        }, {
            typeName: "htmlembed",
            propertyOverrides: {
                "overflow-y": {
                    defaultValue: "hidden"
                },
                "overflow-x": {
                    defaultValue: "hidden"
                }
            },
            propertyOrder: "name,left,top,width,height,overflow-x,overflow-y,html".split(","),
            nodeName: "div",
            label: "HtmlEmbed"
        }]
    };
    var S = function () {
            G || q.ajax({
                url: "/editor/js/definitions.json",
                dataType: "json",
                type: "GET",
                async: !1,
                data: {},
                success: function (d) {
                    G = d
                }
            });
            var v = function () {
                    var d = {};
                    q.each(G.elementTypes, function (i, j) {
                        j.propertyDefinitions = {};
                        q.each(j.propertyOrder, function (d, h) {
                            var i = D(G.propertyDefinitions[h]);
                            void 0 !== j.propertyOverrides[h] && q.extend(i, j.propertyOverrides[h]);
                            if (void 0 !== i.defaultValue) if ("int" == i.storeAs) i.defaultValue = parseInt(i.defaultValue, 10);
                            else if ("float" == i.storeAs) i.defaultValue = parseFloat(i.defaultValue, 10);
                            j.propertyDefinitions[h] = i
                        });
                        d[j.typeName] = j
                    });
                    return d
                }(),
                d = new ca(this),
                i = q.browser.msie && 9 > parseInt(q.browser.version),
                j = {
                    NoopProperty: function () {
                        q.extend(this, {
                            setValue: q.noop,
                            clearValue: q.noop
                        })
                    },
                    CssProperty: function (d, i) {
                        var j, n = q.extend(this, {
                            setValue: function (l) {
                                var n = l;
                                "px" == d.getPropertyDefinition(i).applyAs && (n = parseInt(l, 10) + "px");
                                d.get$Element().css(i, n);
                                j = l
                            },
                            clearValue: function () {
                                d.get$Element().css(i, "");
                                j = void 0
                            },
                            getTransitionValues: function (l) {
                                void 0 === j && (j = parseInt(d.get$Element().css(i), 10));
                                return [j, l]
                            },
                            interpolate: function (d, h, i) {
                                n.setValue(h + d * (i - h))
                            }
                        })
                    },
                    AttrProperty: function (d, i) {
                        q.extend(this, {
                            setValue: function (j) {
                                d.get$Element().attr(i, j)
                            },
                            clearValue: function () {
                                d.get$Element().removeAttr(i)
                            }
                        })
                    },
                    AttrWriteOnceProperty: function (d, i) {
                        var j = q.extend(this, {
                            setValue: function (n) {
                                d.get$Element().attr(i, n);
                                j.setValue = q.noop
                            },
                            clearValue: function () {
                                d.get$Element().removeAttr(i)
                            }
                        })
                    },
                    LineBreakTextProperty: function (d) {
                        q.extend(this, {
                            setValue: function (i) {
                                i = q("<div></div>").text(i).html().replace(/\n/gi, "<br/>\n");
                                d.get$Element().html(i)
                            },
                            clearValue: function () {
                                d.get$Element().text("")
                            }
                        })
                    },
                    LineHeightProperty: function (d, i) {
                        var j, n = q.extend(this, {
                            setValue: function (l) {
                                d.get$Element().css(i, l + "px");
                                j = l
                            },
                            clearValue: function () {
                                d.get$Element().css(i, "");
                                j = void 0
                            },
                            getTransitionValues: function (l) {
                                if (void 0 === j) {
                                    var n = parseInt(d.get$Element().css(i), 10);
                                    j = isNaN(n) ? d.get("font-size") : parseInt(n, 10)
                                }
                                return [j, l]
                            },
                            interpolate: function (d, h, i) {
                                n.setValue(h + d * (i - h))
                            }
                        })
                    },
                    CssColorProperty: function (d, j) {
                        var m = [0, 0, 0, 255];
                        q.extend(this, {
                            setValue: function (i) {
                                m = y.unknownToRGBA(i);
                                d.get$Element().css(j, i)
                            },
                            clearValue: function () {
                                d.get$Element().css(j, "");
                                m = [0, 0, 0, 255]
                            },
                            getTransitionValues: function (d) {
                                return [m, y.unknownToRGBA(d)]
                            },
                            interpolate: function (n, l, q) {
                                m = y.stepRGBA(n, l, q);
                                n = i ? 0 == m[3] ? "transparent" : y.rgbaToHex(m) : y.rgbaToRGBAString(m);
                                d.get$Element().css(j, n)
                            }
                        })
                    },
                    BorderRadiusProperty: function (d) {
                        var i, j = q.extend(this, {
                            setValue: function (j) {
                                var l = j + "px";
                                d.get$Element().css({
                                    "border-radius": l,
                                    "-moz-border-radius": l,
                                    "-webkit-border-radius": l
                                });
                                i = j
                            },
                            clearValue: function () {
                                d.get$Element().css({
                                    "border-radius": "",
                                    "-moz-border-radius": "",
                                    "-webkit-border-radius": ""
                                });
                                i = void 0
                            },
                            getTransitionValues: function (d) {
                                void 0 === i && (i = 0);
                                return [i, d]
                            },
                            interpolate: function (d, h, i) {
                                j.setValue(h + d * (i - h))
                            }
                        })
                    },
                    ImageSourceProperty: function (d) {
                        var i = null,
                            j = new F,
                            n = q.extend(this, {
                                init: function () {
                                    j.listenTo(d, "beforeDestroy", function () {
                                        j.release()
                                    });
                                    j.listenTo(d.getTypeRegistry().getLibraryModel(), "libraryChange", function (d, h) {
                                        if (("update" == h.operation || "delete" == h.operation) && "image" == h.struct.structType && h.name == i)"update" == h.operation ? n.setValue(h.name) : "delete" == h.operation && n.clearValue()
                                    })
                                },
                                setValue: function (l) {
                                    i = l;
                                    l = d.getTypeRegistry().getLibraryModel().getImageUrl(l);
                                    d.get$Element().attr("src", l)
                                },
                                clearValue: function () {
                                    i = null;
                                    d.get$Element().attr("src", "images/placeholder.png")
                                }
                            });
                        n.init()
                    },
                    FramesProperty: function (d, i) {
                        var j, n, l, m, r = 0,
                            w = [],
                            k = "_default",
                            B = {},
                            v = d.getProperty("composition");
                        console.assert(v);
                        var c = "_default";
                        j = !1;
                        n = function () {
                            j = !0;
                            x.gotoFrame("_over")
                        };
                        l = function () {
                            j = !1;
                            x.gotoFrame(c)
                        };
                        m = function () {
                            x.gotoFrame("_down");
                            q(document).one("mouseup", function () {
                                x.gotoFrame("_over")
                            })
                        };
                        var x = q.extend(this, {
                            createFrameStruct: function () {
                                return frameStruct = {
                                    structType: "frame",
                                    name: "Untitled Frame",
                                    transitionOptions: {}
                                }
                            },
                            init: function () {
                                x.addFrame("_default", x.createFrameStruct());
                                "button" == d.getElementType().typeName && (void 0 === B._over && x.addFrame("_over", x.createFrameStruct()), void 0 === B._down && x.addFrame("_down", x.createFrameStruct()), void 0 === B._selected && x.addFrame("_selected", x.createFrameStruct()), d.get$Element().css({
                                    cursor: "pointer"
                                }), x.enableButtonBehavior());
                                x.captureState();
                                var c = new F;
                                c.listenTo(d, "afterUnmarshal", function () {
                                    var d = x.getFrameByKey(k);
                                    if ("play" == q.extend({}, d.transitionOptions).after) {
                                        var d = x.getOrderedKeys(),
                                            h = q.inArray(k, d);
                                        console.assert(-1 != h); - 1 != h && h + 1 < d.length && x.gotoFrame(d[h + 1])
                                    }
                                    c.release()
                                })
                            },
                            enableButtonBehavior: function () {
                                x.disableButtonBehavior();
                                d.get$Element().bind("mouseenter", n).bind("mouseleave", l).bind("mousedown", m)
                            },
                            disableButtonBehavior: function () {
                                d.get$Element().unbind("mouseenter", n).unbind("mouseleave", l).unbind("mousedown", m)
                            },
                            setDefaultFrameKey: function (d) {
                                c = d;
                                j || x.gotoFrame(c)
                            },
                            setValue: function (c) {
                                console.assert(c.framesByKey._default);
                                r = 0;
                                w = c.orderedKeys;
                                B = c.framesByKey;
                                q.each(w, function (c, d) {
                                    var h = d.match(/frame_(\d+)/);
                                    h && (h = parseInt(h[1], 10), isNaN(h) || (r = Math.max(r, h)))
                                });
                                x.gotoFrame("_default")
                            },
                            clearValue: function () {
                                w = [];
                                B = {};
                                x.addFrame("_default", x.createFrameStruct());
                                x.gotoFrame("_default")
                            },
                            newKey: function () {
                                return "frame_" + ++r
                            },
                            addFrame: function (c, d) {
                                console.assert(void 0 === B[c]);
                                w.push(c);
                                B[c] = d
                            },
                            gotoFrame: function (c, d) {
                                if ("" == c || void 0 == c || null == c) c = "_default";
								console.assert(void 0 !== B[c]);
                                if (c != k) {
                                    var h = x.getFrameByKey(c),
                                        i = q.extend({}, h.transitionOptions, d),
                                        l = 0;
                                    i.complete = function () {
                                        l++;
                                        if (l == v.getOrderedKeys().length && "play" == i.after) {
                                            var d = q.inArray(c, w);
                                            console.assert(-1 != d);
                                            x.gotoFrame(w[d == w.length - 1 ? 0 : d + 1])
                                        }
                                    };
                                    v.eachChild(function (d, h) {
                                        h.ensureStateExists(c);
                                        h.gotoState(c, i)
                                    });
                                    k = c
                                }
                            },
                            gotoFrameName: function (c) {
                                for (var d = 0; d < w.length; d++) if (B[w[d]].name == c) {
                                    x.gotoFrame(w[d]);
                                    break
                                }
                            },
                            getCurrentFrameKey: function () {
                                return k
                            },
                            getOrderedKeys: function () {
                                return w
                            },
                            getFrameByKey: function (c) {
                                console.assert(void 0 !== B[c]);
                                return D(B[c])
                            },
                            updateFrame: function (c, d) {
                                console.assert(B[c]);
                                B[c] = d
                            },
                            deleteFrame: function (c) {
                                if (!(void 0 === B[c] || "_default" == c)) {
                                    v.eachChild(function (d, h) {
                                        h.hasState(c) && h.deleteState(c)
                                    });
                                    var d = q.inArray(c, w);
                                    console.assert(0 < d);
                                    w.splice(d, 1);
                                    delete B[c];
                                    k == c && x.gotoFrame("_default")
                                }
                            },
                            captureState: function () {
                                d.cacheStateValue(i, {
                                    structType: "frames",
                                    orderedKeys: w,
                                    framesByKey: B
                                })
                            }
                        });
                        x.init()
                    },
                    CompositionProperty: function (d, i) {
                        var j = 0,
                            n = d.get$Element(),
                            l = [],
                            m = {},
                            r = q.extend(this, {
                                setValue: function (i) {
                                    r.removeChildren();
                                    q.each(i.orderedKeys, function (k, l) {
                                        var n = i[l],
                                            c = d.getTypeRegistry().createElement(n.typeName);
                                        r.addChild(l, c);
                                        m[l] = c;
                                        var p = l.match(/child_(\d+)/);
                                        p && (p = parseInt(p[1], 10), isNaN(p) || (j = Math.max(j, p)));
                                        c.unmarshal(n)
                                    })
                                },
                                clearValue: function () {
                                    q.each(m, function (d, h) {
                                        h.destroy()
                                    });
                                    l = [];
                                    m = {}
                                },
                                captureState: function () {
                                    var j = {
                                        structType: "composition",
                                        orderedKeys: l
                                    };
                                    q.each(m, function (d, h) {
                                        j[d] = h.marshal()
                                    });
                                    d.cacheStateValue(i, j)
                                },
                                getOrderedKeys: function () {
                                    return l
                                },
                                setOrderedKeys: function (d) {
                                    l = D(d);
                                    d = q.map(m, function (d, h) {
                                        return h
                                    });
                                    console.assert(l.length == d.length);
                                    q.each(l, function (d, h) {
                                        var i = r.getChildByKey(h);
                                        n.append(i.get$Element())
                                    })
                                },
                                newKey: function () {
                                    return "child_" + ++j
                                },
                                addChild: function (i, k) {
                                    console.assert(void 0 === m[i]);
                                    l.push(i);
                                    m[i] = k;
                                    k.get$Element().attr("child_key", i);
                                    n.append(k.get$Element());
                                    k.setParent(d);
                                    return i
                                },
                                getChildByKey: function (d) {
                                    return m[d]
                                },
                                getChildByName: function (d) {
                                    for (var h = 0; h < l.length; h++) {
                                        var i = r.getChildByKey(l[h]);
                                        if (i.get("name") == d) return i
                                    }
                                },
                                getChildByPath: function (d) {
                                    var h = r,
                                        i;
                                    q.each(d.split("/"), function (d, c) {
                                        i = h.getChildByName(c);
                                        console.assert(i);
                                        h = i.getProperty("composition")
                                    });
                                    return i
                                },
                                eachChild: function (d) {
                                    q.each(r.getOrderedKeys(), function (h, i) {
                                        d(i, r.getChildByKey(i))
                                    })
                                },
                                removeChildByKey: function (d) {
                                    var h = m[d];
                                    l.splice(q.inArray(d, l), 1);
                                    delete m[d];
                                    h.destroy()
                                },
                                removeChildren: function () {
                                    q.each(m, function (d, h) {
                                        h.destroy()
                                    });
                                    m = {};
                                    l = [];
                                    d.get$Element().empty()
                                }
                            })
                    },
                    LayoutProperty: function (d) {
                        var i = null,
                            j = {},
                            n = d.getProperty("composition");
                        j.fixedDistances = function (i) {
                            var l = d.get("width"),
                                j = d.get("height");
                            q.each(i, function (d, h) {
                                var i = n.getChildByName(h.name);
                                console.assert(i);
                                if (i) {
                                    var c = h.constraints;
                                    void 0 !== c.left ? i.set("left", c.left) : void 0 !== c.right && i.set("left", l - i.get("width") - c.right);
                                    void 0 !== c.width ? i.set("width", c.width) : void 0 !== c.left && void 0 !== c.right && i.set("width", l - c.right - c.left);
                                    void 0 !== c.top ? i.set("top", c.top) : void 0 !== c.bottom && i.set("top", j - i.get("height") - c.bottom);
                                    void 0 !== c.height ? i.set("height", c.height) : void 0 !== c.top && void 0 !== c.bottom && i.set("height", j - c.bottom - c.top);
                                    h.sublayout && i.getProperty("layout") && i.getProperty("layout").doLayout(h.sublayout)
                                }
                            })
                        };
                        var l = q.extend(this, {
                            setValue: function (d) {
                                i = d;
                                l.doLayout()
                            },
                            clearValue: function () {
                                i = null;
                                l.doLayout()
                            },
                            doLayout: function (d) {
                                if ((d = d || i) && j[d.layoutType]) j[d.layoutType](d.spec)
                            }
                        })
                    },
                    ReadOnlyHeightProperty: function (d) {
                        q.extend(this, {
                            setValue: q.noop,
                            clearValue: q.noop,
                            getValue: function () {
                                return d.get$Element().outerHeight()
                            }
                        })
                    },
                    ReadOnlyWidthProperty: function (d) {
                        q.extend(this, {
                            setValue: q.noop,
                            clearValue: q.noop,
                            getValue: function () {
                                return d.get$Element().outerWidth()
                            }
                        })
                    },
                    AssetNameProperty: function (d, i) {
                        d.getProperty("composition");
                        var j = d.getTypeRegistry(),
                            n = new F;
                        n.listenTo(d, "beforeDestroy", function () {
                            n.release()
                        });
                        n.listenTo(d.getTypeRegistry().getLibraryModel(), "libraryChange", function (j, n) {
                            "delete" == n.operation && n.name == d.get(i) && l.clearValue()
                        });
                        var l = q.extend(this, {
                            setValue: function (i) {
                                var n = j.getLibraryModel().getElementStruct(i);
                                if (n) {
                                    q.each(["composition", "frames", "background-color"], function (i, l) {
                                        d.set(l, n.statesByKey._default[l], "_default")
                                    });
                                    var i = n.statesByKey._default.width,
                                        p = n.statesByKey._default.height;
                                    d.getPropertyDefinition("width").defaultValue = i;
                                    d.getPropertyDefinition("width").preventClear = !1;
                                    d.getPropertyDefinition("height").defaultValue = p;
                                    d.getPropertyDefinition("height").preventClear = !1;
                                    d.refreshProperty("width");
                                    d.refreshProperty("height")
                                } else l.clearValue()
                            },
                            clearValue: function () {
                                d.getProperty("composition").removeChildren();
                                d.get$Element().css({
                                    background: 'url("images/placeholder.png")'
                                })
                            }
                        })
                    },
                    InputValueProperty: function (d) {
                        console.assert("INPUT" == d.get$Element().get(0).nodeName);
                        q.extend(this, {
                            setValue: function (i) {
                                d.get$Element().val(i)
                            },
                            clearValue: function () {
                                d.get$Element().val("")
                            }
                        })
                    },
                    HtmlProperty: function (d) {
                        var i = /<script.*?src='.*\/embed\/(.*?)'><\/script>/gi;
                        q.extend(this, {
                            setValue: function (j) {
                                var n = i.exec(j);
                                i.lastIndex = 0;
                                n && 2 == n.length && 0 < n[1].length ? (j = j.substr(n[0].length), n = n[1], d.get$Element().html(j), q.ajax({
                                    url: "/ws/nested/" + n,
                                    dataType: "json",
                                    success: function (i) {
                                        var j = (new S).getLibraryModel();
                                        j.setUIFileStruct(i);
                                        j.instantiateElement("__main__").get$Element().css({
                                            height: d.get("height"),
                                            width: d.get("width")
                                        }).appendTo(d.get$Element())
                                    }
                                })) : d.get$Element().html(j)
                            },
                            clearValue: function () {
                                d.get$Element().html("")
                            }
                        })
                    },
                    MouseBehaviorProperty: function (d) {
                        var i = {},
                            j = q.extend(this, {
                                init: function () {
                                    d.get$Element().bind("mouseenter", function (d) {
                                        j.doAction("over");
                                        d.preventDefault()
                                    });
                                    d.get$Element().bind("mouseleave", function (d) {
                                        j.doAction("out");
                                        d.preventDefault()
                                    });
                                    d.get$Element().bind("click", function (d) {
                                        j.doAction("release");
                                        d.preventDefault()
                                    })
                                },
                                doAction: function (d) {
                                    if (d = i[d]) {
                                        var h = j[d.actionType];
                                        console.assert(h);
                                        h && h(d)
                                    }
                                },
                                none: function () {},
                                goto_frame: function (i) {
                                    d.getParent().getProperty("frames").gotoFrameName(i.frameName)
                                },
                                goto_next: function () {
                                    var i = d.getParent().getProperty("frames"),
                                        j = i.getOrderedKeys(),
                                        p = q.inArray(i.getCurrentFrameKey(), j);
                                    i.gotoFrame(j[p == j.length - 1 ? 0 : p + 1])
                                },
                                goto_previous: function () {
                                    var i = d.getParent().getProperty("frames"),
                                        j = i.getOrderedKeys(),
                                        p = q.inArray(i.getCurrentFrameKey(), j);
                                    i.gotoFrame(j[0 < p ? p - 1 : j.length - 1])
                                },
                                goto_website: function (d) {
                                    window.open(d.url, d.target)
                                },
                                goto_email: function (d) {
                                    window.open("mailto://" + d.emailAddress, "_blank")
                                },
                                setValue: function (n) {
                                    if ((i = n) && i.release && "goto_website" == i.release.actionType) {
                                        var n = i.release.url,
                                            l;
                                        l = (l = (l = window.location.href == n) || window.location.pathname == n) || j.getLastPart(n) == j.getLastPart(window.location.pathname);
                                        d.getProperty("frames").setDefaultFrameKey(l ? "_selected" : "_default")
                                    }
                                },
                                getLastPart: function (d) {
                                    d = d.split("/");
                                    return d[d.length - 1]
                                },
                                clearValue: function () {
                                    i = {}
                                }
                            });
                        j.init()
                    },
                    BoxFillProperty: function (d) {
                        d.get$Element().css({
                            zoom: 1
                        });
                        var j = [255, 255, 255, 0],
                            m = [255, 255, 255, 0],
                            n, l, u, A, w = q.extend(this, {
                                init: function () {
                                    d.get$Element().css({
                                        "border-width": 0,
                                        overflow: "hidden"
                                    });
                                    if (q.browser.msie && 9 == parseInt(q.browser.version)) {
                                        var i = {
                                            position: "absolute",
                                            padding: 0,
                                            margin: 0,
                                            width: "100%",
                                            height: "100%",
                                            border: "0px solid black",
                                            "box-sizing": "border-box",
                                            "-moz-box-sizing": "border-box",
                                            "-webkit-box-sizing": "border-box",
                                            "-ms-box-sizing": "border-box",
                                            "font-size": "100%",
                                            font: "inherit",
                                            "vertical-align": "baseline",
                                            "word-wrap": "break-word"
                                        };
                                        l = q("<div></div>").appendTo(d.get$Element()).css(i).css({
                                            overflow: "hidden"
                                        });
                                        u = q("<div></div>").appendTo(l).css(i);
                                        A = q("<div></div>").appendTo(d.get$Element()).css(i);
                                        q("<div></div>").css(i).css({
                                            backgroundColor: "white",
                                            opacity: 0
                                        }).appendTo(d.get$Element())
                                    } else l = u = A = d.get$Element()
                                },
                                setValue: function (d) {
                                    j = y.unknownToRGBA(d.color1);
                                    m = y.unknownToRGBA(d.color2 || d.color1);
                                    w.setGradient(j, m)
                                },
                                getTransitionValues: function (d) {
                                    var h = {
                                        top: j,
                                        bottom: m
                                    },
                                        d = {
                                            top: y.unknownToRGBA(d.color1),
                                            bottom: y.unknownToRGBA(d.color2 || d.color1)
                                        };
                                    return [h, d]
                                },
                                interpolate: function (d, h, i) {
                                    j = y.stepRGBA(d, h.top, i.top);
                                    m = y.stepRGBA(d, h.bottom, i.bottom);
                                    w.setGradient(j, m)
                                },
                                clearValue: function () {
                                    j = [255, 255, 255, 0];
                                    m = [255, 255, 255, 0];
                                    i ? w.getRoundedRect().setFill(j, m) : w.getFillTarget().css({
                                        backgroundImage: "",
                                        filter: "",
                                        backgroundColor: ""
                                    })
                                },
                                setGradient: function (d, h) {
                                    if (i) w.getRoundedRect().setFill(d, h);
                                    else {
                                        var j = y.rgbaToRGBAString(d),
                                            c = y.rgbaToRGBAString(h),
                                            l = y.rgbaToIEHex(d),
                                            n = y.rgbaToIEHex(h);
                                        w.getFillTarget().css("background-image", r("-webkit-gradient(linear, left top, left bottom, from(", j, "), to(", c, "))"));
                                        w.getFillTarget().css("background-image", r("-webkit-linear-gradient(top, ", j, ", ", c, ")"));
                                        w.getFillTarget().css("background-image", r("-moz-linear-gradient(top, ", j, ", ", c, ")"));
                                        w.getFillTarget().css("background-image", r("-ms-linear-gradient(top, ", j, ", ", c, ")"));
                                        w.getFillTarget().css("background-image", r("-o-linear-gradient(top, ", j, ", ", c, ")"));
                                        w.getFillTarget().css("background-image", r("linear-gradient(top, ", j, ", ", c, ")"));
                                        w.getFillTarget().css("filter", r("progid:DXImageTransform.Microsoft.gradient(startColorStr='", l, "', EndColorStr='", n, "')"))
                                    }
                                },
                                getRoundedRect: function () {
                                    if (!n) {
                                        n = new ba(d);
                                        var i = new F;
                                        i.listenTo(d, "width", function () {
                                            n.invalidate()
                                        });
                                        i.listenTo(d, "height", function () {
                                            n.invalidate()
                                        })
                                    }
                                    return n
                                },
                                getClipTarget: function () {
                                    return l
                                },
                                getFillTarget: function () {
                                    return u
                                },
                                getStrokeTarget: function () {
                                    return A
                                }
                            });
                        w.init()
                    },
                    BoxBorderRadiusProperty: function (d) {
                        var j, m = d.getProperty("fill"),
                            n = q.extend(this, {
                                setValue: function (d) {
                                    if (i) m.getRoundedRect().setCornerRadius(d);
                                    else {
                                        var h = d + "px",
                                            h = {
                                                "border-radius": h,
                                                "-moz-border-radius": h,
                                                "-webkit-border-radius": h
                                            };
                                        m.getClipTarget().css(h);
                                        m.getStrokeTarget().css(h)
                                    }
                                    j = d
                                },
                                clearValue: function () {
                                    if (i) m.getRoundedRect().setCornerRadius(0);
                                    else {
                                        var d = {
                                            "border-radius": "",
                                            "-moz-border-radius": "",
                                            "-webkit-border-radius": ""
                                        };
                                        m.getClipTarget().css(d);
                                        m.getStrokeTarget().css(d)
                                    }
                                    j = void 0
                                },
                                getTransitionValues: function (d) {
                                    void 0 === j && (j = 0);
                                    return [j, d]
                                },
                                interpolate: function (d, h, i) {
                                    n.setValue(h + d * (i - h))
                                }
                            })
                    },
                    BoxBorderWidthProperty: function (d) {
                        var j, m = d.getProperty("fill"),
                            n = q.extend(this, {
                                setValue: function (d) {
                                    i ? m.getRoundedRect().setStrokeWeight(d) : m.getStrokeTarget().css("border-width", d);
                                    j = d
                                },
                                clearValue: function () {
                                    i ? m.getRoundedRect().setStrokeWeight(0) : m.getStrokeTarget().css("border-width", "");
                                    j = void 0
                                },
                                getTransitionValues: function (d) {
                                    void 0 === j && (j = 0);
                                    return [j, d]
                                },
                                interpolate: function (d, h, i) {
                                    n.setValue(h + d * (i - h))
                                }
                            })
                    },
                    BoxBorderColorProperty: function (d) {
                        var j = [0, 0, 0, 255],
                            m = d.getProperty("fill"),
                            n = q.extend(this, {
                                setValue: function (d) {
                                    n.setBorderRGBA(y.unknownToRGBA(d))
                                },
                                clearValue: function () {
                                    i ? m.getRoundedRect().setStrokeColor([0, 0, 0, 255]) : m.getStrokeTarget().css("border-color", "");
                                    j = [0, 0, 0, 255]
                                },
                                getTransitionValues: function (d) {
                                    return [j, y.unknownToRGBA(d)]
                                },
                                interpolate: function (d, h, i) {
                                    d = y.stepRGBA(d, h, i);
                                    n.setBorderRGBA(d)
                                },
                                setBorderRGBA: function (d) {
                                    j = d;
                                    i ? m.getRoundedRect().setStrokeColor(d) : m.getStrokeTarget().css("border-color", y.rgbaToHex(d))
                                }
                            })
                    },
                    BoxOpacityProperty: function (d) {
                        var j, m = q.extend(this, {
                            setValue: function (m) {
                                i ? d.getProperty("fill").getRoundedRect().setShapeOpacity(m) : d.get$Element().css({
                                    opacity: m
                                });
                                j = m
                            },
                            clearValue: function () {
                                i ? d.getProperty("fill").getRoundedRect().setShapeOpacity(1) : d.get$Element().css({
                                    opacity: ""
                                });
                                j = void 0
                            },
                            getTransitionValues: function (d) {
                                void 0 === j && (j = 1);
                                return [j, d]
                            },
                            interpolate: function (d, h, i) {
                                m.setValue(h + d * (i - h))
                            }
                        })
                    }
                },
                m = q.extend(this, {
                    createElement: function (d) {
                        return void 0 === v[d] ? null : new Y(v[d], m)
                    },
                    getPropertyConstructor: function (d) {
                        console.assert(j[d]);
                        return j[d]
                    },
                    getLibraryModel: function () {
                        return d
                    }
                })
        },
        Y = function (v, d) {
            var i, j = {},
                m = "_default",
                h = {
                    _default: {}
                },
                p = new ka(this),
                t = {},
                n = new L,
                l, u = q.extend(this, {
                    init: function () {
                        i = q(v.isVoidElement ? r("<", v.nodeName, "/>") : r("<", v.nodeName, "></", v.nodeName, ">"));
                        i.attr("etype", v.typeName);
                        i.css({
                            position: "absolute",
                            padding: 0,
                            margin: 0,
                            "box-sizing": "border-box",
                            "-moz-box-sizing": "border-box",
                            "-webkit-box-sizing": "border-box",
                            "-ms-box-sizing": "border-box",
                            "font-size": "100%",
                            font: "inherit",
                            "vertical-align": "baseline",
                            "word-wrap": "break-word",
                            "max-width": "none",
                            "max-height": "none"
                        });
                        q.each(v.propertyDefinitions, function (d) {
                            j[d] = u.createProperty(u, d)
                        });
                        u.ensureStateExists("_default");
                        u.refreshAllProperties()
                    },
                    getElementType: function () {
                        return v
                    },
                    getPropertyDefinition: function (d) {
                        return u.getElementType().propertyDefinitions[d]
                    },
                    getProperty: function (d) {
                        return j[d]
                    },
                    getTypeRegistry: function () {
                        return d
                    },
                    createProperty: function (h, i) {
                        var j = u.getPropertyDefinition(i);
                        return new(d.getPropertyConstructor(j.extension))(u, i)
                    },
                    gotoState: function (d, h) {
                        if (void 0 === d || null === d || "" == d) d = "_default";
                        console.assert(u.hasState(d));
                        d != m && (m = d, p.reset(h), q.each(j, function (d) {
                            u.refreshProperty(d, !0)
                        }), p.start())
                    },
                    ensureStateExists: function (d) {
                        h[d] = h[d] || {}
                    },
                    duplicateState: function (d, i) {
                        h[i] = D(h[d])
                    },
                    hasState: function (d) {
                        return void 0 !== h[d]
                    },
                    deleteState: function (d) {
                        console.assert("_default" != d);
                        console.assert(u.hasState(d));
                        "_default" != d && (m == d && u.gotoState("_default"), delete h[d])
                    },
                    set: function (d, i, j) {
                        j = j || m;
                        console.assert(h[j || "_default"]);
                        if (!(void 0 == i && !0 == u.getPropertyDefinition(d).preventClear && "_default" == j)) {
                            var l = h[j][d];
                            h[j][d] = i;
                            u.refreshProperty(d);
                            n.dispatch(d, i, l)
                        }
                    },
                    get: function (d) {
                        var i = u.getProperty(d);
                        if (void 0 !== i.getValue) return i.getValue();
                        i = u.getPropertyDefinition(d);
                        console.assert(i);
                        var j = h[m][d];
                        void 0 === j && (j = h._default[d]);
                        if (void 0 === j) j = i.defaultValue;
                        return j
                    },
                    getDispatcher: function () {
                        return n
                    },
                    cacheStateValue: function (d, i) {
                        h[m][d] = i;
                        t[d] = i
                    },
                    refreshProperty: function (d, h) {
                        console.assert(u.getProperty(d));
                        var i = u.getProperty(d),
                            j = u.get(d);
                        j == t[d] ? u.getPropertyDefinition(d).canAnimate && h && i.getTransitionValues && void 0 !== j && (i = i.getTransitionValues(j), p.addTransition(d, i[0], i[1])) : (t[d] = j, void 0 === j ? i.clearValue() : u.getPropertyDefinition(d).canAnimate && h && i.getTransitionValues ? (i = i.getTransitionValues(j), p.addTransition(d, i[0], i[1])) : i.setValue(j))
                    },
                    refreshAllProperties: function () {
                        q.each(j, function (d) {
                            u.refreshProperty(d)
                        });
                        n.dispatch("afterRefreshAllProperties", null)
                    },
                    marshal: function () {
                        return D({
                            structType: "element",
                            typeName: v.typeName,
                            statesByKey: h
                        })
                    },
                    unmarshal: function (d) {
                        h = D(d.statesByKey);
                        console.assert(u.hasState("_default"));
                        u.hasState(m) || (m = "_default");
                        u.refreshAllProperties();
                        n.dispatch("afterUnmarshal")
                    },
                    setParent: function (d) {
                        l = d
                    },
                    getParent: function () {
                        return l
                    },
                    get$Element: function () {
                        return i
                    },
                    destroy: function () {
                        l = void 0;
                        n.dispatch("beforeDestroy", null);
                        n.release();
                        u.get$Element().remove()
                    }
                });
            u.init()
        },
        da = function () {
            if (void 0 == window.console) window.console = {};
            q.each(["log", "error", "assert", "group", "groupEnd"], function (r, d) {
                window.console[d] = window.console[d] || q.noop
            });
            console.assert = function (q) {
                if (!q) try {
                    IllegalFunction()
                } catch (d) {}
            }
        };
    window.RocketUI = {
        a: r,
        b: D,
        c: function (q) {
            var d = {},
                i;
            for (i in q) q.hasOwnProperty(i) && (d[i] = q[i]);
            return d
        },
        d: S,
        e: Y,
        f: F,
        g: L,
        h: M,
        i: da,
        embed: function (r) {
            var d = q.extend({
                uifilestruct: null,
                targetId: "#main",
                applyAsPage: !1
            }, r);
            d.uifilestruct && q(window).load(function () {
                var i = (new S).getLibraryModel();
                i.setUIFileStruct(d.uifilestruct);
                var i = i.instantiateElement("__main__"),
                    j = q(d.targetId);
                "absolute" != j.css("position") && "relative" != j.css("position") && j.css("position", "relative");
                j.css({
                    height: i.get("height"),
                    width: i.get("width")
                });
                i.get$Element().appendTo(j);
                d.applyAsPage && (j.css({
                    "margin-left": "auto",
                    "margin-right": "auto"
                }), q("body").css({
                    backgroundColor: i.get("background-color")
                }))
            })
        }
    };
    da()
})(jQuery);
$.noConflict()