// Ed Rogers, Influxis, 2012

var report = 1; // Set to 'true' for verbose, 'false' for none, or '1' for half way

// Globals
var result = {};
var targetElement = "";

if ( !console )
	var console = { log : function( msg ) { alert( msg ); } };

// Function compatible with standard RocketUI source files
window.RocketUI = {
	embed : function (ruim) { // 'ruim' short for 'Rocket UI Model'
		var targetElement = ruim.targetId;
		if (report == 1) console.log ("Running conversion from RocketUI to FluxUI ...");

		// Break down the model and filter, then move or merge certain properties into others
		var result = breakDown (ruim.uifilestruct,new Object ());
		var result = move (result,result);
		var result = merge (result,result);
		
		// Report results and write to global variable
		if (report == 1) {
			console.log ("RESULTANT MODEL: ");
			console.log (result);
		}
		
		jQuery('#output').val( JSON.stringify( result ) );

		// Find discrepancies
//		comparison (result,movie);
	}
}

$(window).load( function() {
	$('#updateMovie').bind( 'click', function() {
		eval( $('#code').val() );
	} );
} );

function comparison (lee,ed) {
	for (key in lee) {
		if (ed[key] !== lee[key]) {
			var c = false;
			console.log ("DISCREPANCY:");
			console.log (lee[key]);
			console.log (ed[key]);
		}
		if (typeof lee[key] == "object") comparison (lee[key],ed[key]);
	}
	return c;
}

function breakDown (model,newMod) {
	for (key in model) {
		// Check if the current key is an object, not an array
		if (typeOf (model[key]) === "object") {
			var checkingObj = checkObj (key);
			
			// Check if the object matches new schema
			if (checkingObj !== false) {
				if (report === true) console.log ("OBJECT: " + key + " BECOMES: " + checkingObj);
				newMod[checkingObj] = {};
				breakDown (model[key],newMod[checkingObj]);
				
			// Otherwise check object's properties matching new schema
			}else{
				var checkingObj = checkObj (model[key]["structType"]);
				if (checkingObj !== false) {
					if (report === true) console.log ("OBJECT: " + key + " IS A: " + checkingObj);
					newMod[key] = {};
					breakDown (model[key],newMod[key]);
				}
			}

		}else{
			var checkingPr = checkProperty (key, model[key]);
			var value = checkPropertyValue (checkingPr, model[key]);
			if (checkingPr !== false) {
				if (report === true) console.log ("        PROPERTY: " + key + " BECOMES: " + checkingPr + " WITH VALUE: " + value);
				newMod[checkingPr] = value;
			}
		}
	}
	return newMod;
}

function move (model,newMod) {
	for (key in model) {
		if (typeOf (model[key]) === "object") {
			checkMov = checkMoveMerge (model[key],key);
			if (checkMov.action === "move") {
				for (subKey in model[key]) {

					// Move according to property name
					for (movProp in checkMov.prName) {
						if (subKey === checkMov.prName[movProp]) {
							if (report === true) console.log ("MOVING: " + subKey + " INTO: " + checkMov.newObj);
							if (typeof newMod[key][checkMov.newObj] != "object") newMod[key][checkMov.newObj] = {};
							newMod[key][checkMov.newObj][subKey] = model[key][subKey];
							delete newMod[key][subKey];
						}
					}

					// Move according to contained string
					var checkStr = subKey.search(checkMov.prString); 
					if (checkStr !== -1 && checkMov.prString !== "") {
						if (report === true) console.log ("MOVING: " + subKey + " INTO: " + checkMov.newObj);
						if (typeof newMod[key][checkMov.newObj] != "object") newMod[key][checkMov.newObj] = {};
						newMod[key][checkMov.newObj][subKey] = model[key][subKey];
						delete newMod[key][subKey];
					}
				}
			}
			move (model[key],newMod[key]);
		}
	}
	return newMod;
}

function merge (model,newMod) {
	for (key in model) {
		for (subKey in model[key]) {
			if (typeOf (model[key][subKey]) === "object") {
				checkMov = checkMoveMerge (model[key][subKey],subKey);
				if (checkMov.action === "merge") {
					if (report === true) console.log ("MERGING: " + subKey + " FROM: " + key + " UP AS: " + checkMov.newObj);
					newMod[checkMov.newObj] = model[key][subKey];
					delete newMod[key][subKey];
					
				}
			}
		}
	}
	return newMod;
}

function checkObj (objectValue) {
	switch (objectValue) {
		case "images" :
			var o = "assets";
			break;
		case "image" :
			var o = "image";
			break;
		case "elements" :
			var o = "elements";
			break;
		case "widget" :
			var o = "widget";
			break;
		case "element" :
			var o = "element";
			break;
		case "statesByKey" :
			var o = "states";
			break;
		case "_default" :
			var o = "_default";
			break;
		case "_over" :
			var o = "_over";
			break;
		case "_down" :
			var o = "_down";
			break;
		case "_selected" :
			var o = "_selected";
			break;
		case "frames" :
			var o = "frames";
			break;
		case "framesByKey" :
			var o = "hash";
			break;
		case "frame" :
			var o = "frame";
			break;
		case "composition" :
			var o = "children"; // remember to move all none 'keys' into 'hash' inside these objects
			break;
		case "fill" :
			var o = "fill";
			break;
		case "mouse-behavior" :
			var o = "behaviour";
			break;
		case "release" :
			var o = "click";
			break;
		case "over" :
			var o = "mouseover";
			break;
		case "out" :
			var o = "mouseout";
			break;
		case "asset-name" :
			var o = "asset";
			break;
		case "transitionOptions" :
			var o = "transition";
			break;
		case "release" :
			var o = "click";
			break;
		default :
			var o = false;
			break;
	}
	if (o === false) {
		if (typeof objectValue === "string") {
			if (objectValue.search(/frame_/) !== -1) o = true;
		}
	}
	if (o === true) o = "" + objectValue + "";
	return o;
}

function checkProperty (property, value) {
	switch (property) {
		case "structType" :
			var p = "type";
			break;
		case "url" :
			var p = "url";
			break;
		case "height" :
			var p = "height";
			break;
		case "width" :
			var p = "width";
			break;
		case "top" :
			var p = "top";
			break
		case "bottom" :
			var p = "bottom";
			break;
		case "left" :
			var p = "left";
			break;
		case "right" :
			var p = "right";
			break;
		case "typeName" :
			var p = "type" ;			
			break;
		case "overflow-y" :
			var p = "overflow-y"; // remember to move into props
			break;
		case "overflow-x" :
			var p = "overflow-x";
			break;
		case "border-radius" :
			var p = "border-radius";
			break;
		case "border-width" :
			var p = "border-width";
			break;
		case "border-color" :
			var p = "border-color";
			break;
		case "font-size" :
			var p = "font-size";
			break;
		case "font-weight" :
			var p = "font-weight";
			break;
		case "line-height" :
			var p = "line-height";
			break;
		case "background-color" :
			var p = "background-color";
			break;
		case "opacity" :
			var p = "opacity";
			break;
		case "orderedKeys" :
			var p = "keys";
			break;
		case "name" :
			var p = "name";
			break;
		case "src" :
			var p = "src";
			break;
		case "color" :
			var p = "color";
			break;
		case "text-align" :
			var p = "text-align";
			break;
		case "color1" :
			var p = "color1";
			break;
		case "color2" :
			var p = "color2";
			break;
		case "fillType" :
			var p = "fillType";
			break;
		case "text" :
			var p = "text";
			break;
		case "selectedEventType" :
			var p = "selectionEvent";
			break;
		case "actionType" :
			var p = "action";
			break;
		case "frameName" :
			var p = "frameId";
			break;
		case "duration" :
			var p = "duration";
			break;
		case "easing" :
			var p = "easing";
			break;
		case "after" :
			var p = "after";
			break;
		case "url" :
			var p = "url";
			break;
		case "target" :
			var p = "target";
			break;
		case "asset" :
			var p = "asset";
			break;
		default :
			var p = false;
			break;
	}
	if (p === "type" && value === "element") var p = false;
	if (p === "type" && value === "frames") var p = false;
	if (p === "type" && value === "frame") var p = false;
	if (p === "type" && value === "composition") var p = false;
	return p;
}

function checkPropertyValue (object, value) {
	var v = value;
	switch(object) {
		case "selectionEvent" :
			if ( v == "release" )
				v = "click";
			if ( v == "out" )
				v = "mouseout";
			if ( v == "over" )
				v = "mouseover";
			break;
		case "action" :
			switch ( v ) {
				case "goto_previous" :
					v = "gotoPrevState";
					break;
				case "goto_next" :
					v = "gotoNextState";
					break;
				case "goto_frame" :
					v = "gotoFrame";
					break;
				case "goto_website" :
					v = "gotoWebUrl";
					break;
			}
			break;
	}
	return v;	
}

function checkMoveMerge (object,keyName) {

	// Move props
	if (typeof object["frames"] == "object" ||
	keyName === "_default" ||
	keyName === "_down" ||
	keyName === "_over" ||
	keyName === "_selected" ||
	keyName.search (/frame_/) !== -1 ) {
		return {
			action : "move",
			newObj : "props",
			prString : null,
			prName : ["overflow-y","overflow-x","height","width","background-color","color","opacity","top","bottom","left","right","fill","font-size","border-radius","border-color","border-width","padding","text-align","font-family","line-height"] // Specific properties to move/merge
		}
	}

	// Move 'child_'s from 'children' into 'children.hash'
	if (keyName === "children") {
		return {
			action : "move",
			newObj : "hash",
			prString : /child_/
		}
	}

	// Merge __main__
	if (keyName === "__main__") {
		return {
			action : "merge",
			newObj : "movie"
		}
	}

	return false;
}

// Because of bloody stupid typeof functionality
function typeOf (value) {
	var usefulType = typeof value;
	if (usefulType === "object") {
		if (value) {
			if (value instanceof Array) {
				usefulType = "array";
			}
		} else {
			usefulType = "null";
		}
	}
	return usefulType;
}

