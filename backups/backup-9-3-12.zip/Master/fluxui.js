/**
 * @author Lee Sylvester
 * @copyright Influxis
 **/
 
( function( $ ) {

	var flux = $.fn.fluxui = function( $movie ) {
		$container = $(this);
		$container.empty();
		return this.each( function() {
			if ( !$movie ) flux.log( "No movie to parse. Exiting." );
			if ( $movie ) {
				var _assets = new Array();
				for ( a in $movie.assets ) {
					_assets.push( $movie.assets[a].url );
				}
				if ( _assets.length > 0 ) {
					types.system.preload( _assets );
				}
				$.extend( true, assets, $movie.assets );
			}
			var m;
			if ( !!$movie.elements && !!$movie.movie ) {
				m = types.system.createMovie( $movie.movie, types.system.nextMovieCounter() );
			} else {
				flux.log( "Movie structure corrupt." );
			}
			if ( 'absolute' != $(this).css( 'position' ) && 'relative' != $(this).css( 'position' ) )
				$(this).css( 'position', 'relative' );
			$container.css( 'width', $(m).width() );
			$container.css( 'height', $(m).height() );
			$container.append( m );
		} );
	};

	flux.initialise = function( $options ) {
		$.extend( true, this.settings, $options );
	};

	/**
	 * global assets lookup
	 **/
	var assets = flux.assets = flux.assets || {};
	
	/**
	 * global data container
	 **/
	var fdata = flux.fdata = flux.fdata || {};

	/**
	 * types lookup - stores all classes for all movies
	 **/
	var types = flux.types = flux.types || {};
	
	/**
	 * class builder object
	 **/
	var $$class = flux.$class = flux.$class || {};
	
	$$class.create = function( param ) {
		if ( !param )
			return function() {};

		if ( !param.namespace )
			throw new Error( "Please specify the Namespace." );
		
		if ( !types[param.namespace] ) {

			var clazz = function() {
				//analyse fields of the class
				if ( param.fields ) {
					param.fields.className = param.namespace;
					var fields = param.fields;
					for ( var field in fields ) {
						if ( typeof fields[field] == "function" )
							throw new TypeError( "Field [" + field + "] cannot be a function!" );
						if ( field == "props" ) { // hack to inherit properties
							if ( !this[field] ) this[field] = {};
							for ( var prop in fields[field] )
								this[field][prop] = fields[field][prop];
						}
						else if ( !this[field] )
							this[field] = fields[field];
					}
				}
				
				// get and execute the constructor to do the initialize process.
				if ( param.constructor ) {
					if ( typeof param.constructor != "function" )
						throw new TypeError("Illegal function [" + method + "]!");
					param.constructor.apply( this, arguments );
				}
				
			};
		
			// set parent class and field "Super" for class         
			var parentClass = param.inherits || Object;
			if ( typeof parentClass != "function" )
				throw new TypeError( "The parent class is not a function." );
			if ( parentClass != Object ) {
				function F() {};
				F.prototype = parentClass.prototype;
				var prototype = new F();
				prototype.constructor = clazz;
				clazz.prototype = prototype;
			}
			clazz.prototype.Super = parentClass;
		
			// read methods and add to class(use prototype)
			if ( param.methods ) {
				var methods = param.methods;
				for ( var method in methods ) {
					if ( typeof methods[method] != "function" )
						throw new TypeError( "Illegal function [" + method + "]!" );
					clazz.prototype[method] = methods[method];
				}
			}
			
			// read static variables and methods and add to class
			if ( param.statics ) {
				var statics = param.statics;
				for ( var name in statics )
					clazz[name] = statics[name];
			}
			// create the specified namespace and append the class to it.
			var name = param.namespace;
			if ( name.length == 0 || name.indexOf( " " ) != -1 || name.charAt( 0 ) == '.' 
					|| name.charAt( name.length - 1 ) == '.' || name.indexOf( ".." ) != -1 )
				throw new Error( "illegal Namespace: " + name );
			var parts = name.split( '.' );
			var container = types;
			for( var i = 0; i < parts.length - 1; i++ ) {
				var part = parts[i];
				// If there is no property of container with this name, create an empty object.
				if (!container[part]) {
					container[part] = {};
				} else if (typeof container[part] != "object") {
					// If there is already a property, make sure it is an object
					var n = parts.slice(0, i).join('.');
					throw new Error(n + " already exists and is not an object");
				}
				container = container[part];
			}
			container[parts[parts.length - 1]] = clazz;
		} else
			var clazz = types[param.namespace];
		
		return clazz;
	};
	
	$$class.create( {
		namespace : 'timer',
		statics : {
			timerID : 0,
			timers : [],
			start : function() {
				if ( types.timer.timerID )
					return;
				( function(){
					for ( var i = 0; i < types.timer.timers.length; i++ )
						if ( types.timer.timers[i]() === false ) {
							types.timer.timers.splice(i, 1);
							i--;
						}
					types.timer.timerID = setTimeout( arguments.callee, 0 );
				} )();
			},
			stop: function(){
				clearTimeout( types.timer.timerID );
				types.timer.timerID = 0;
			},
			add: function( fn ){
				types.timer.timers.push( fn );
				types.timer.start();
			}
		}
	} );
	
	$$class.create( {
		namespace : 'style',
		statics : {
			css : function( $node, $style, $value ) {
				$($node).css( $style, $value );
			},
			decorate : function( $key, $value ) {
				return ( types.style.isNumeric( $key ) && $value > 0 ) ? $value + 'px' : $value;
			},
			raw : function( $value ) {
				return Number( String( $value ).split( 'px' ).join( '' ) );
			},
			normaliseFill : function( $fillType, $color1, $color2 ) {
				var ret;
				switch( $fillType ) {
					case "gradient" :
						ret = types.style.normaliseBackground( $color1, $color2 );
						break;
					case "solid" :
						ret = types.style.normaliseBackground( $color1, $color1 );
						break;
				}
				return ret;
			},
			normaliseBorder : function( $size ) {
				return { "border-radius" : $size,
				"-moz-border-radius" : $size,
				"-webkit-border-radius" : $size };
			},
			normaliseBackground : function( $color1, $color2 ) {
				var fromRGBAStr = types.color.RGBAToString( types.color.objToRGBA( $color1 ) ),
					toRGBAStr = types.color.RGBAToString( types.color.objToRGBA( $color2 ) ),
					fromRGBA = types.color.RGBAToHex( types.color.objToRGBA( $color1 ), true ),
					toRGBA = types.color.RGBAToHex( types.color.objToRGBA( $color2 ), true );
				return { filter : "progid:DXImageTransform.Microsoft.gradient(startStr='" + fromRGBA + "', EndStr='" + toRGBA + "')",
					background : ["-webkit-gradient(linear, left top, left bottom, from(" + fromRGBAStr + "), to(" + toRGBAStr + "))",
					"-webkit-linear-gradient(top, " + fromRGBAStr + ", " + toRGBAStr + ")",
					"-moz-linear-gradient(top, " + fromRGBAStr + ", " + toRGBAStr + ")",
					"-ms-linear-gradient(top, " + fromRGBAStr + ", " + toRGBAStr + ")",
					"-o-linear-gradient(top, " + fromRGBAStr + ", " + toRGBAStr + ")",
					"linear-gradient(top, " + fromRGBAStr + ", " + toRGBAStr + ")"] };
			},
			getPropertyDiff : function( $curProps, $nextProps, $merged ) {
				var diff = false;
				if ( !$curProps )
					$curProps = {};
				for ( var prop in $nextProps ) {
					if ( $nextProps.hasOwnProperty( prop ) ) {
						if ( !$curProps[prop] && typeof $nextProps[prop] != 'object' ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
							continue;
						}
						if ( typeof $nextProps[prop] === 'object'  ) {
							var obj = {};
							if ( types.style.getPropertyDiff( $curProps[prop], $nextProps[prop], obj ) ) {
								if ( !$merged[prop] ) $merged[prop] = {}
								if ( prop == "fill" )
									$.extend( true, $merged[prop], $nextProps[prop] );
								else
									$.extend( true, $merged[prop], obj );
								diff = true;
							}
						} else if ( $curProps[prop] != $nextProps[prop] ) {
							$merged[prop] = $nextProps[prop];
							diff = true;
						}
					}
				}
				return diff;
			},
			canAnimate : function( $prop ) {
				return ['opacity', 'color', 'fill', 'background-color', 'border-color', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'].indexOf( $prop ) > -1;
			},
			isColor : function( $prop ) {
				return ['color', 'fill', 'background-color', 'border-color'].indexOf( $prop ) > -1;
			},
			isNumeric : function( $prop ) {
				return ['opacity', 'border-width', 'border-radius', 'line-height', 'font-size', 'width', 'height', 'top', 'left'].indexOf( $prop ) > -1;
			}
		}
	} );
	
	$$class.create( {
		namespace : 'system',
		statics : {
			// load all images used in the movie. likely not needed, but future proofs code
			preload : function( $assets ) {
				for ( a in $assets )
					$('<img/>')[0].src = $assets[a];
			},
			// guarantees a unique movie id
			nextMovieCounter : function() {
				fdata.counter = fdata.counter || 0;
				return fdata.counter++;
			},
			createMovie : function( $clip, $movieId, $state ) {
				$state = $state || '_default';
				var node = new types.element( 'root_' + $movieId, $clip.states[$state] );
				$(node).attr( 'entity', 'movie' );
				return node.node;
			},
			htmlEncode : function(value){
				return $('<div/>').text(value).html();
			},
			htmlDecode : function(value){
				return $('<div/>').html(value).text();
			},
			clone : function( $obj ) {
				var newObj = ( $obj instanceof Array ) ? [] : {};
				for ( i in $obj ) {
					if ( $obj[i] && typeof $obj[i] == "object" ) {
						newObj[i] = types.system.clone( $obj[i] );
					} else newObj[i] = $obj[i]
				}
				return newObj;
			},
			isObject : function( $val ) {
				return $val === Object( $val );
			},
			isArray : function( $val ) {
				return $val.constructor == Array;
			},
			isString : function( $val ) {
				return toString.call( $val ) == '[object String]';
			},
			isEmpty : function( $val ) {
				if ( types.system.isArray( $val ) || types.system.isString( $val ) ) return $val.length === 0;
				for ( var key in $val ) if ( $val.hasOwnProperty( key ) ) return false;
				return true;
			}
		}
	} );
	
	$$class.create( {
		namespace : 'tween',
		statics : {
			getRGBTransition : function( $start, $end, $pc ) {
				var r1 = $start[0],
					g1 = $start[1],
					b1 = $start[2],
					a1 = $start[3];
			
				var r2 = $end[0],
					g2 = $end[1],
					b2 = $end[2],
					a2 = $end[3];
			
				return [Math.floor( r1 + ( $pc * ( r2 - r1 ) ) + .5 ),
						Math.floor( g1 + ( $pc * ( g2 - g1 ) ) + .5 ),
						Math.floor( b1 + ( $pc * ( b2 - b1 ) ) + .5 ),
						Math.floor( a1 + ( $pc * ( a2 - a1 ) ) + .5 )];
			},
			animate : function( $node, $props, $duration, $easing, $callback ) {
				if ( !$easing ) $easing = "linearTween";
				var aprops = {};
				var hasProps = false;
				for ( var key in $props ) {
					if ( !!$duration && $props.hasOwnProperty( key ) && types.style.canAnimate( key ) ) {
						aprops[key] = $props[key];
						hasProps = true;
					} else {
						if ( $props[key].constructor == Array )
							for ( j in $props[key] )
								types.style.css( $node, key, types.style.decorate( key, $props[key][j] ) );
						else
							types.style.css( $node, key, types.style.decorate( key, $props[key] ) );
					}
				}
				if ( hasProps ) {
					types.tween.doAnimation( $node, aprops, $duration, $easing, $callback );
				} else if ( !!$callback ) $callback();
			},
			doAnimation : function( $node, $props, $duration, $easing, $callback ) {
				var startTime = new Date().getTime();
				var ease = types.tween[$easing];
				var inst = types.element.getInstance( $node );
				inst.props = inst.props || {};
				var fills = [], colors = [], css = [];
				for ( var prop in $props ) {
					if ( types.style.isColor( prop ) ) {
						if ( prop == 'fill' ) {
							if ( inst.props.fill == null )
								inst.props.fill = { color1 : 'transparent', color2 : 'transparent', fillType : 'solid' };
							console.log( inst.props.fill, $props[prop] );
							var pc1 = types.color.colorNameToRGBA( inst.props.fill.color1 ),
								pc2 = types.color.colorNameToRGBA( inst.props.fill.color2 || inst.props.fill.color1 ),
								nc1 = types.color.colorNameToRGBA( $props[prop].color1 ),
								nc2 = types.color.colorNameToRGBA( $props[prop].color2 || $props[prop].color1 );
							if ( !!$props.opacity && $props.opacity != null ) {
								nc1[3] = $props.opacity * 255;
								nc2[3] = $props.opacity * 255;
							}
							if ( !( pc1 == nc1 && pc2 == nc2 ) ) {
								fills.push( { 
									fillType : $props[prop].fillType || 'solid', 
									from1 : pc1,
									from2 : pc2, 
									to1 : nc1,
									to2 : nc2,
								} );
							}
							continue;
						} else {
							var val = inst.props[prop] || inst.$node().css( prop );
							if ( !val || val == '' || val == 'initial' ) val = 'transparent';
							if ( val != $props[prop] ) {
								var pcolor = types.color.colorNameToRGBA( val );
								var ncolor = types.color.colorNameToRGBA( $props[prop] );
								if ( !!$props.opacity && $props.opacity != null )
									ncolor[3] = $props.opacity * 255;
								colors.push( { prop : prop, from : pcolor, to : ncolor } );
							}
							continue;
						}
					}
					if ( types.style.isNumeric( prop ) ) {
						var val = ( inst.props[prop] || inst.$node().css( prop ) ),
							newProp = $props[prop];
						val = types.style.raw( val );
						if ( val != newProp )
							css.push( { prop : prop, from : val, to : newProp } );
					}
				}
				if ( $duration > 0 ) {
					types.timer.add( function() {
						var time = Math.min( new Date().getTime() - startTime, $duration );
						var perc = ease( time, 0, 1, $duration );
						if ( fills.length > 0 ) {
							for ( var i = 0; i < fills.length; i++ ) {
								inst.setStyle( 'background-image', { 
									color1 : types.tween.getRGBTransition( fills[i].from1, fills[i].to1, perc ), 
									color2 : types.tween.getRGBTransition( fills[i].from2, fills[i].to2, perc ), 
									fillType : fills[i].fillType
								} );
							}
						}
						if ( colors.length > 0 ) {
							for ( var i = 0; i < colors.length; i++ ) {
								console.log( colors[i].prop, colors[i].to );
								inst.setStyle(
									colors[i].prop,
									types.tween.getRGBTransition( colors[i].from, colors[i].to, perc )
								);
							}
						}
						if ( css.length > 0 ) {
							for ( var i = 0; i < css.length; i++ ) {
								var nv = Math.floor( css[i].from + ( perc * ( css[i].to - css[i].from ) ) + .5 );
								inst.setStyle( css[i].prop, nv );
							}
						}
						if ( time >= $duration ) {
							$callback();
							return false;
						}
					} );
				} else {
					for ( var i = 0; i < fills.length; i++ )
						inst.setStyle( 'background-image', { 
							color1 : fills[i].to1, 
							color2 : fills[i].to2, 
							fillType : fills[i].fillType
						} );
					for ( var i = 0; i < colors.length; i++ ) {
						console.log( colors[i].prop, colors[i].to );
						inst.setStyle( colors[i].prop, colors[i].to );
					}
					for ( var i = 0; i < css.length; i++ )
						inst.setStyle( css[i].prop, css[i].to );
				}
			},
			// t: current time, b: beginning value, c: change in value, d: duration
			// t and d can be in frames or seconds/milliseconds
			linearTween : function( t, b, c, d ) {
				return c * t / d + b;
			},
			easeInQuad : function( t, b, c, d ) {
				return c * ( t /= d ) * t + b;
			},
			easeOutQuad : function( t, b, c, d ) {
				return -c * ( t /= d ) * ( t - 2 ) + b;
			},
			easeInOutQuad : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t + b;
				return -c / 2 * ( ( --t ) * ( t - 2 ) - 1 ) + b;
			},
			easeInCubic : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t + b;
			},
			easeOutCubic : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t + 1 ) + b;
			},
			easeInOutCubic : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t + 2 ) + b;
			},
			easeInQuart : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t + b;
			},
			easeOutQuart : function( t, b, c, d ) {
				return -c * ( ( t = t / d - 1 ) * t * t * t - 1 ) + b;
			},
			easeInOutQuart : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t + b;
				return -c / 2 * ( ( t -= 2 ) * t * t * t - 2 ) + b;
			},
			easeInQuint : function( t, b, c, d ) {
				return c * ( t /= d ) * t * t * t * t + b;
			},
			easeOutQuint : function( t, b, c, d ) {
				return c * ( ( t = t / d - 1 ) * t * t * t * t + 1 ) + b;
			},
			easeInOutQuint : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * t * t * t * t * t + b;
				return c / 2 * ( ( t -= 2 ) * t * t * t * t + 2 ) + b;
			},
			easeInSine : function( t, b, c, d ) {
				return -c * Math.cos( t / d * ( Math.PI / 2 ) ) + c + b;
			},
			easeOutSine : function( t, b, c, d ) {
				return c * Math.sin( t / d * ( Math.PI / 2 ) ) + b;
			},
			easeInOutSine : function( t, b, c, d ) {
				return -c / 2 * ( Math.cos( Math.PI * t / d ) - 1 ) + b;
			},
			easeInExpo : function( t, b, c, d ) {
				return ( t == 0 ) ? b : c * Math.pow( 2, 10 * ( t / d - 1 ) ) + b;
			},
			easeOutExpo : function( t, b, c, d ) {
				return ( t == d ) ? b + c : c * ( - Math.pow( 2, -10 * t / d ) + 1 ) + b;
			},
			easeInOutExpo : function( t, b, c, d ) {
				if ( t == 0 ) return b;
				if ( t == d ) return b + c;
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * Math.pow( 2, 10 * ( t - 1 ) ) + b;
				return c / 2 * ( - Math.pow( 2, -10 * --t ) + 2 ) + b;
			},
			easeInCirc : function( t, b, c, d ) {
				return -c * ( Math.sqrt( 1 - ( t /= d ) * t ) - 1 ) + b;
			},
			easeOutCirc : function( t, b, c, d ) {
				return c * Math.sqrt( 1 - ( t = t / d - 1 ) * t ) + b;
			},
			easeInOutCirc : function( t, b, c, d ) {
				if ( ( t /= d / 2 ) < 1 ) return -c / 2 * ( Math.sqrt( 1 - t * t ) - 1 ) + b;
				return c / 2 * ( Math.sqrt( 1 - ( t -= 2 ) * t ) + 1) + b;
			},
			easeInElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return -( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
			},
			easeOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d ) == 1 ) return b + c;  if ( !p ) p = d * .3;
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				return a * Math.pow( 2, -10 * t ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) + c + b;
			},
			easeInOutElastic : function( t, b, c, d ) {
				var s = 1.70158; var p = 0; var a = c;
				if ( t == 0 ) return b;  if ( ( t /= d / 2 ) == 2 ) return b + c;  if ( !p ) p = d * ( .3 * 1.5 );
				if ( a < Math.abs( c ) ) { a = c; var s = p / 4; }
				else var s = p / ( 2 * Math.PI ) * Math.asin( c / a );
				if ( t < 1 ) return -.5 * ( a * Math.pow( 2, 10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) ) + b;
				return a * Math.pow( 2 , -10 * ( t -= 1 ) ) * Math.sin( ( t * d - s ) * ( 2 * Math.PI ) / p ) * .5 + c + b;
			},
			easeInBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( t /= d ) * t * ( ( s + 1 ) * t - s ) + b;
			},
			easeOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158;
				return c * ( ( t = t / d - 1 ) * t * ( ( s + 1 ) * t + s ) + 1 ) + b;
			},
			easeInOutBack : function( t, b, c, d, s) {
				if ( s == undefined ) s = 1.70158; 
				if ( ( t /= d / 2 ) < 1 ) return c / 2 * ( t * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t - s ) ) + b;
				return c / 2 * ( ( t -= 2 ) * t * ( ( ( s *= ( 1.525 ) ) + 1 ) * t + s ) + 2 ) + b;
			},
			easeInBounce : function( t, b, c, d ) {
				return c - types.tween.easeOutBounce( d - t, 0, c, d ) + b;
			},
			easeOutBounce : function( t, b, c, d ) {
				if ( ( t /= d ) < ( 1 / 2.75 ) ) {
					return c * ( 7.5625 * t * t ) + b;
				} else if ( t < ( 2 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 1.5 / 2.75 ) ) * t + .75 ) + b;
				} else if ( t < ( 2.5 / 2.75 ) ) {
					return c * ( 7.5625 * ( t -= ( 2.25 / 2.75 ) ) * t + .9375 ) + b;
				} else {
					return c * ( 7.5625 * ( t -= ( 2.625 / 2.75 ) ) * t + .984375 ) + b;
				}
			},
			easeInOutBounce : function( t, b, c, d ) {
				if ( t < d / 2 ) return types.tween.easeInBounce( t * 2, 0, c, d ) * .5 + b;
				return types.tween.easeOutBounce( t * 2 - d, 0, c, d ) * .5 + c * .5 + b;
			}
		}
	} );
	
	$$class.create( {
		namespace : 'color',
		statics : {
			base16 : function( $num ) {
				return 16 > $num ? "0" + $num.toString(16) : $num.toString(16);
			},
			hexToDec : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !Math.isNaN( Number( $hex ) ) ? $hex : parseInt( $hex[1], 16 ) << 16 + parseInt( $hex[2], 16 ) << 8 + parseInt( $hex[3], 16 );
			},
			hexToRGBA : function( $hex ) {
				$hex = /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec( $hex );
				return !$hex ? $hex : [ parseInt( $hex[1], 16 ), parseInt( $hex[2], 16 ), parseInt( $hex[3], 16 ), 255 ];
			},
			objToRGBA : function( $obj ) {
				if ( $obj == "transparent" ) return [255, 255, 255, 0];
				if ( $obj.constructor == Array ) return $obj;
				var hex = types.color.hexToRGBA( $obj );
				return hex ? hex : ( hex = types.color.rgbaStringToRGBA( $obj ) ) ? hex : [255, 255, 255, 255];
			},
			RGBAToString : function( $num ) {
				if ( $num.constructor == Array ) {
					var a = new Array();
					for ( i = 0; i < $num.length && i < 4; i++ )
						a.push( ( i == 3 ) ? $num[i] / 255 : $num[i] );
					return "rgba(" + a.join() + ")";
				}
			},
			rgbaStringToRGBA : function( $str ) {
				$str = /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/.exec( $str );
				return !$str ? $str : [ parseInt( $str[1], 10 ), parseInt( $str[2], 10 ), parseInt( $str[3], 10 ), parseInt( void 0 == $str[4] ? 255 : $str[4], 10 )];
			},
			RGBAToHex : function( $num, $useAlpha ) {
				if ( $num.constructor == Array ) {
					if ( $num.length > 3 ) {
						var alpha = $num.pop();
						if ( $useAlpha )
							$num.unshift( alpha );
					}
					var hashed = new Array();
					for ( i in $num )
						hashed.push( types.color.base16( $num[i] ) );
					return '#' + hashed.join(''); 
				}
			},
			colorNameToHex : function( $color ) {
				var colors = {"aliceblue":"#f0f8ff","antiquewhite":"#faebd7","aqua":"#00ffff","aquamarine":"#7fffd4","azure":"#f0ffff","beige":"#f5f5dc","bisque":"#ffe4c4","black":"#000000","blanchedalmond":"#ffebcd","blue":"#0000ff","blueviolet":"#8a2be2","brown":"#a52a2a","burlywood":"#deb887","cadetblue":"#5f9ea0","chartreuse":"#7fff00","chocolate":"#d2691e","coral":"#ff7f50","cornflowerblue":"#6495ed","cornsilk":"#fff8dc","crimson":"#dc143c","cyan":"#00ffff","darkblue":"#00008b","darkcyan":"#008b8b","darkgoldenrod":"#b8860b","darkgray":"#a9a9a9","darkgreen":"#006400","darkkhaki":"#bdb76b","darkmagenta":"#8b008b","darkolivegreen":"#556b2f","darkorange":"#ff8c00","darkorchid":"#9932cc","darkred":"#8b0000","darksalmon":"#e9967a","darkseagreen":"#8fbc8f","darkslateblue":"#483d8b","darkslategray":"#2f4f4f","darkturquoise":"#00ced1","darkviolet":"#9400d3","deeppink":"#ff1493","deepskyblue":"#00bfff","dimgray":"#696969","dodgerblue":"#1e90ff","firebrick":"#b22222","floralwhite":"#fffaf0","forestgreen":"#228b22","fuchsia":"#ff00ff","gainsboro":"#dcdcdc","ghostwhite":"#f8f8ff","gold":"#ffd700","goldenrod":"#daa520","gray":"#808080","green":"#008000","greenyellow":"#adff2f","honeydew":"#f0fff0","hotpink":"#ff69b4","indianred ":"#cd5c5c","indigo ":"#4b0082","ivory":"#fffff0","khaki":"#f0e68c","lavender":"#e6e6fa","lavenderblush":"#fff0f5","lawngreen":"#7cfc00","lemonchiffon":"#fffacd","lightblue":"#add8e6","lightcoral":"#f08080","lightcyan":"#e0ffff","lightgoldenrodyellow":"#fafad2","lightgrey":"#d3d3d3","lightgreen":"#90ee90","lightpink":"#ffb6c1","lightsalmon":"#ffa07a","lightseagreen":"#20b2aa","lightskyblue":"#87cefa","lightslategray":"#778899","lightsteelblue":"#b0c4de","lightyellow":"#ffffe0","lime":"#00ff00","limegreen":"#32cd32","linen":"#faf0e6","magenta":"#ff00ff","maroon":"#800000","mediumaquamarine":"#66cdaa","mediumblue":"#0000cd","mediumorchid":"#ba55d3","mediumpurple":"#9370d8","mediumseagreen":"#3cb371","mediumslateblue":"#7b68ee","mediumspringgreen":"#00fa9a","mediumturquoise":"#48d1cc","mediumvioletred":"#c71585","midnightblue":"#191970","mintcream":"#f5fffa","mistyrose":"#ffe4e1","moccasin":"#ffe4b5","navajowhite":"#ffdead","navy":"#000080","oldlace":"#fdf5e6","olive":"#808000","olivedrab":"#6b8e23","orange":"#ffa500","orangered":"#ff4500","orchid":"#da70d6","palegoldenrod":"#eee8aa","palegreen":"#98fb98","paleturquoise":"#afeeee","palevioletred":"#d87093","papayawhip":"#ffefd5","peachpuff":"#ffdab9","peru":"#cd853f","pink":"#ffc0cb","plum":"#dda0dd","powderblue":"#b0e0e6","purple":"#800080","red":"#ff0000","rosybrown":"#bc8f8f","royalblue":"#4169e1","saddlebrown":"#8b4513","salmon":"#fa8072","sandybrown":"#f4a460","seagreen":"#2e8b57","seashell":"#fff5ee","sienna":"#a0522d","silver":"#c0c0c0","skyblue":"#87ceeb","slateblue":"#6a5acd","slategray":"#708090","snow":"#fffafa","springgreen":"#00ff7f","steelblue":"#4682b4","tan":"#d2b48c","teal":"#008080","thistle":"#d8bfd8","tomato":"#ff6347","turquoise":"#40e0d0","violet":"#ee82ee","wheat":"#f5deb3","white":"#ffffff","whitesmoke":"#f5f5f5","yellow":"#ffff00","yellowgreen":"#9acd32"};
				if (typeof colors[ $color.toLowerCase() ] != 'undefined' )
					return colors[ $color.toLowerCase() ];
			
				return $color;
			},
			colorNameToRGBA : function( $color ) {
				if ( !$color || $color == 'transparent' )
					return [255,255,255,0];
				else if ( $color.constructor == Array )
					return $color;
				else if ( "string" == typeof $color && $color.substr( 0, 3 ) == "rgb" ) {
					var re = /rgb?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/;
					var segs = re.exec( $color );
					return !segs ? segs : [parseInt(segs[1], 10), parseInt(segs[2], 10), parseInt(segs[3], 10), parseInt(void 0 == segs[4] ? 255 : segs[4], 10)];
				} else
					return types.color.hexToRGBA( types.color.colorNameToHex( $color ) );
			}
		}
	} );

	$$class.create( { 
		namespace : 'element',
		constructor : function( $id, $state ) {
			var np = ( !!$state ) ? $state.props : null;
			var p = {};
			$.extend( true, p, this.props );
			$.extend( true, p, np );
			this.node = $(this.markup).get( 0 );
			this.entity( this.className );
			this.fluxid( $id );
			//types.style.normalisePropStack( p );
			this.applyProperties( { props : p } );
			this.data( $state );
			//this.stateName();
			this.$node().data( 'currentInstance', this );
			if ( !!$state && $state.children ) {
				for ( indx in $state.children.keys ) {
					var child = $state.children.hash[$state.children.keys[indx]];
					if ( !!child )
						this.$node().append( new types[child.type]( $state.children.keys[indx], child.states._default ).node );
				}
			}
			this.gotoState( '_default' );
		},
		fields : {
			markup : '<div />',
			props : {
				'position' : 'absolute',
				'padding' : 0,
				'margin' : 0,
				'box-sizing' : 'border-box',
				'vertical-align' : 'baseline',
				'word-wrap' : 'break-word',
				'max-width' : 'none',
				'max-height' : 'none'
			}
		},
		methods : {
			fluxid : function( value ) {
				if ( !!value )
					this.$node().attr( 'fluxid', value );
				return this.$node().attr( 'fluxid' );
			},
			entity : function( value ) {
				if ( !!value )
					this.$node().attr( 'entity', value );
				return this.$node().attr( 'entity' );
			},
			parentNode : function() {
				return this.node().parent();
			},
			parentInstance : function() {
				return types.element.getInstance( this.$node().parent().get( 0 ) );
			},
			
			data : function( $data ) {
				if ( !!$data )
					this.$node().data( 'nodeData', $data );
				return this.$node().data( 'nodeData' );
			},
			$node : function() {
				return $(this.node);
			},
			
			stateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'currentState', $stateName );
				return this.$node().data( 'currentState' );
			},
			nextStateName : function( $stateName ) {
				if ( !!$stateName )
					this.$node().data( 'nextState', $stateName );
				return this.$node().data( 'nextState' );
			},
			
			applyProperties : function( $props, $state ) {
				if ( !!$props && $props.props ) {
					types.tween.animate( this.node, $props.props, ( !!$state ? $state.duration : null ), ( !!$state ? $state.easing : null ), ( !!$state ? $state.complete : null ) );
				}
			},
			setBackground : function( $color1, $color2, $fillType ) {
				$fillType = $fillType || 'solid';
				var bg = types.style.normaliseFill( $fillType, [$color1[0], $color1[1], $color1[2], $color1[3]], [$color2[0], $color2[1], $color2[2], $color2[3]] );
				for ( var c = 0; c < bg.background.length; c++ )
					this.$node().css( 'background', bg.background[c] );
				this.$node().css( 'filter', bg.filter );
				this.props.fill.color1 = $color1;
				this.props.fill.color2 = $color2;
				this.props.fill.fillType = $fillType;
			},
			setBorderRadius : function( $radius ) {
				$radius = types.style.normaliseBorder( $radius );
				this.$node().css( 'border-radius', Math.round( $radius ) );
				this.props['border-radius'] = $radius;
			},
			setStyle : function( $prop, $value ) {
				switch( $prop ) {
					case 'background-image' :
						this.setBackground( $value.color1, $value.color2, $value.fillType );
						break;
					case 'border-radius' :
						this.setBorderRadius( $value );
						break;
					default :
						this.props[$prop] = $value;
						if ( $value.constructor == Array )
							$value = types.color.RGBAToString( $value );
						if ( types.style.isNumeric( $prop ) )
							$value = $value + 'px';
						this.$node().css( $prop, $value );
						break;
				}
			},
			doAction : function( $action, $data ) {
				this[$action]( $data );
			},
			play : function() {
				this.gotoNextState();
			},
			gotoFrame : function( $data ) {
				console.log( $data );
				this.gotoState( $data.frameId );
			},
			gotoWebUrl : function( $data ) {
				if ( $data.target == "_blank" )
					window.open( $data.url, '_blank' );
				else
					window.location.href = $data.url;
			},
			gotoNextState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i >= d.frames.keys.length - 1 ) ? d.frames.keys[0] : d.frames.keys[i + 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
			},
			gotoPrevState : function() {
				var d = this.data();
				var s = this.stateName();
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == s ) {
							s = ( i <= 0 ) ? d.frames.keys[d.frames.keys.length - 1] : d.frames.keys[i - 1];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
			},
			gotoState : function( $state ) {
				var d = this.data();
				var s = '_default';
				if ( !!d.frames )
					for ( i = 0; i < d.frames.keys.length; i++ )
						if ( d.frames.keys[i] == $state ) {
							s = d.frames.keys[i];
							break;
						}
				//this.stateName( s );
				this.changeState( s, d );
			},
			changeState : function( $stateName, $stateData ) {
				
				// if the previous state and current state match, then there's nothing to do
				if ( $stateName == this.stateName() )
					return;
				
				// if we have no frames or children, theres no point continuing
				if ( !( !!$stateData.frames && !!$stateData.frames.hash[$stateName] && !!$stateData.children ) ) 
					return;
				
				// set base transform values
				var duration = settings.defaultTransform.duration;
				var easing = settings.defaultTransform.easing;
				var completeAction = settings.defaultTransform.after;
				
				// store the new state names for merging
				var nextStateNames = [];
				nextStateNames.push( "_default" );
				if ( $stateName != "_default" )
					nextStateNames.push( $stateName );
					
				var curStateNames = [];
				if ( !!this.stateName() ) {
					curStateNames.push( "_default" );
					if ( this.stateName() != "_default" )
						curStateNames.push( this.stateName() );
				}
				
				// get the next state data
				var nextState = $stateData.frames.hash[$stateName];
				
				// if the next state has a transition, lets update the default transition values
				if ( !!nextState.transition ) {
					duration = nextState.transition.duration || duration;
					ease = nextState.transition.easing || easing;
					completeAction = nextState.transition.after || completeAction;
				}
				
				// once the transition is over, we're probably going to have a transition complete action
				// on the parent, so we need to setup a callback to handle this.
				var me = this;
				var callback = function() {
					if ( !!me  && !!me.pendingAction ) {
						me.stateName( $stateName );
						var pa = me.pendingAction;
						delete me.pendingAction;
						me.doAction( pa );
					}
				};
				
				// if the parent has a pending action (when the transition is complete), let's set that now.
				if ( completeAction != "stop" )
					this.pendingAction = completeAction;
					
				// now we know what our transition parameters will be, let's enforce them on the state object
				var transition = { duration : duration, easing : ease, complete : callback };
				
				// now for the intensive part.  we need to animate / transition the children.
				for ( c in $stateData.children.keys ) {
					var name = $stateData.children.keys[c];
					var child = $stateData.children.hash[name];
					
					// this will contain the prop values to transition
					var props = {};
					// and this will contain the current element props
					var curProps = {};
					
					if ( !!child.states ) {
						for ( var u in nextStateNames )
							if ( !!child.states[nextStateNames[u]] )
								$.extend( true, props, child.states[nextStateNames[u]] );
						for ( var u in curStateNames )
							if ( !!child.states[curStateNames[u]] )
								$.extend( true, curProps, child.states[curStateNames[u]] );
					}
					
					// get animate-able prop values where the previous state and next
					// state properties merge and differ
					var diff = {};
					
					if ( !types.style.getPropertyDiff( curProps, props, diff ) ) {
						this.stateName( $stateName );
						continue;
					}
					
					//types.style.normalisePropStack( diff.props );
					var n = types.element.getInstance( this.$node().find("[fluxid='" + name + "']") );
					this.stateName( $stateName );
					if ( !!n && !!n.applyProperties )
						n.applyProperties( diff, transition );
				}
			}
		},
		statics : {
			getInstance : function( $node ) {
				return $($node).data( 'currentInstance' );
			}
		}
	} );
	
	$$class.create( {
		namespace : 'widget',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
		},
		inherits : types.element
	} );
	
	$$class.create( {
		namespace : 'box',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
		},
		inherits : types.element,
		fields : {
			props : {
				'zoom' : 1,
				'overflow' : 'hidden',
				'border' : 'solid',
				'border-radius' : 0,
				'border-width' : 0,
				'border-color' : [0,0,0,0],
				'border-style' : 'solid',
				'left' : '50px',
				'top' : '90px',
				'width' : '310px',
				'height' : '110px'
			}
		}
	} );
		
	$$class.create( {
		namespace : 'image',
		fields : {
			markup : '<img />'
		},
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.src )
				this.$node().attr( 'src', assets[$state.src].url );
		},
		methods : {
			applyProperties : function( $props, $state ) {
				if ( !!$props.props )
					types.tween.animate( this.node, $props.props, !!$state ? $state.duration : null, !!$state ? $state.easing : null, !!$state ? $state.complete : null );
				if ( !!$props && !!$props.src && !!assets[$props.src] )
					this.$node().attr( 'src', assets[$props.src].url );
			}
		}
	} );
	
	$$class.create( {
		namespace : 'button',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			this.$node().css( 'cursor', 'pointer' );
			this.$node().bind( 'mouseenter', { element : this, stateName : '_over', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseleave', { element : this, stateName : '_default', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mousedown', { element : this, stateName : '_down', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} ),
			this.$node().bind( 'mouseup', { element : this, stateName : '_selected', state : $state }, function( e ) {
				e.data.element.changeState( e.data.stateName, e.data.state );
			} );
			if ( !!$state.behaviour ) {
				var b = $state.behaviour;
				for ( var ev in b )
					if ( b.hasOwnProperty( ev ) ) {
						this.$node().bind( ev, { caller : this, event : b[ev] }, function( e ) {
							e.data.caller.parentInstance().doAction( e.data.event.action, e.data.event );
						} );
					}
			}
		}
	} );
	
	$$class.create( {
		namespace : 'text',
		inherits : types.element,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.text )
				this.$node().html( $state.text );
		},
		fields : {
			props : {
				'overflow' : 'hidden',
				'font-family' : 'arial',
				'font-size' : 12
			}
		}
	} );
	
	$$class.create( {
		namespace : 'textarea',
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( !!$state.text )
				this.$node().html( types.system.htmlEncode( $state.text ) );
		},
		fields : {
			markup : '<textarea />'
		},
		inherits : types.element
	} );

	// stores global fluxui settings
	var settings = flux.settings = {
		debug : false,
		defaultTransform : {
			duration : 300,
			easing : "linearTween",
			after : "stop"
		}
	};

	// logs important debug messages to the browser
	flux.log = function( $msg ) {
		if ( this.settings.debug ) {
			if ( !!window.console && !!window.console.log ) {
				Object.apply( console.log, arguments );
			} else {
				alert( $msg );
			}
		}
	};

} )( jQuery );