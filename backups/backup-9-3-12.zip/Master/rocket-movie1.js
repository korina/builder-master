window.RocketUI.embed({
    targetId: '.ruitarget_55001',
    uifilestruct: {
        "images": {
            "face_02.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/hfSm3qdWjciLW5_zFJRHT-0UtQZhsX-5J_ubyXwNvIpvRZS5n5EXjya0EKbGTmxWiFf7uOU8c_3u69xwk5ZK1z3U=s80",
                "blob_key": "AMIfv95yG1j8lRMWoazj-14NdKQmP20t4WqFJEbPyeElAqh9PMa-j0R-s2xRhUWWWxV6PUPNEZqC-IFN7Xf-8vbzMOhGj0Do1XQ9KbZHvzCQbCRORcecgUBlipIL-1cRGtcLw0zkyn2nLlgWF2xwkhAP4Betwr-l1A",
                "height": 40,
                "width": 80,
                "filename": "face_02.png",
                "id": 58003
            },
            "face_03.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/M8WRyxcz3q7T5kImhQH4tJXZ80yu1it3joxdneajfhlSTk9hxfeOWpIes-nz9TdJrXzQuTmVhdyOUgIg8Or35vJx=s80",
                "blob_key": "AMIfv971XQkvXMIK15sx6N1AwPsuxq_uM3eMJEv8Y3hQK9mAYRYh9AV91VJVAminrIZ_FdqlbgSes3tNk7YJ_BA2xK2BKb4sq8tcrlrSighCvT0QWbxeHNEx_0AJAB7KZefOUyldXPpcUbGyVTTXkLS30rvomarzrQ",
                "height": 40,
                "width": 80,
                "filename": "face_03.png",
                "id": 56005
            },
            "mountain.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/VhpNxvK6GbFXIR6vt14jur_oVMggx7eLDviF6Lq0hpKfgRQiGcd1ol_m30mSrk5A35FpIGUbJ_CRTZIemsfPbz8s=s170",
                "blob_key": "AMIfv94uI5U6XFJPL9lInu2miZ1H1fWISuF6MPaqXNSH1dV19zdmX8AVj99SoyudUHkTxB6yuYWKPzImQLBCAaNDwIu2flqexzjO51VVxtV2uV01ekhbsrDzxNeoZUUjmRux7A2ow6SyxQJ4e3QTrkYHEc4J1qY28A",
                "height": 170,
                "width": 140,
                "filename": "mountain.png",
                "id": 58002
            },
            "face_01.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/nnywc4-8IYg7UtRlr-s8l6AiAHUNQ6AGiwi1-hKfILApQTsB69kD9Q-6Jr66_xS6NKfSrGCzpodmgTJZLPOeMg=s80",
                "blob_key": "AMIfv96p5ps3k-D5lcIHYqtV3EjVNJmL2s7wI29FVizEhUNxWK8Obfn6ZBle4TQ8KeFG7_OJWTCFMLhoeEmiPfxDN73N-FJOgeN7PT8H_v6h3DHbo6nSq7s2EWac9NgX_ccrrY4iW_lkAvQ1NugaI7gb3RDO4DHHww",
                "height": 40,
                "width": 80,
                "filename": "face_01.png",
                "id": 60001
            },
            "face_06.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh4.ggpht.com\/oQgevVlV2PY94OKp35uHndnhMF1FJkoabbrXi6HxxBvC7QcW22GAc_-s3flBVZlX8gH45D3yBqWzeBrac87XWnU=s80",
                "blob_key": "AMIfv94LDYZOsLauz9eyGqHTjvIuA4jhRlqhFC7iYOfT_BOKhb_wdNX8YDLed5eCMm0iogLETxcJqLmLnsA08vidOfPLiEh4XsWZu8sJFZN3qCplRn7ssF6QXXwH42d90R4lZnwQjxY65TIjIQgDY95MtXmkXSir8A",
                "height": 40,
                "width": 80,
                "filename": "face_06.png",
                "id": 56004
            },
            "face_04.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/UXAc-ovpzGWCMKuKLWdxdSHvxoVX_7ndznRIF14nVge9Mliwewy8j1k61dX3qDUpPSbIy4ubewY1iWxLmgtH9Q=s80",
                "blob_key": "AMIfv97tdbo2du0yCs694kBtTmsLZ7gYE-1FytS_SVk0ianNptIjWJTTCk8whzijw0aJSythLChdrPEYnRrJczlAyuV_tEM3uqZCNpgT3JMauKCO1r0U0XXjhnNkaFA3oMcKdvMqu1F9tauC1ZyVR51lq4WBYwAflw",
                "height": 40,
                "width": 80,
                "filename": "face_04.png",
                "id": 61001
            },
            "face_05.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/-_XoZJAwebc3-CuuOj7Pcc2r2dtwfqUtNl8ARGice-6wYvfGBmGNxdEZ2hErs1m621eW9PpM17Odo_EHnvjgmw=s80",
                "blob_key": "AMIfv95V8XKi5ZC_7iLQT5ozcqVmSFNtPYnuUC3velbDBvlB82LbRM0qg_ajlzIsjS2HfrYufCedTA7rhkowejIAYlyZea-rK-ZFt1J1EtDfkM-7fV07FJ3uk-kYiYMnYKBihhEzXSI6oCpDDCOYCEqpDDYq9ZrrjA",
                "height": 40,
                "width": 80,
                "filename": "face_05.png",
                "id": 56002
            },
            "2123773ed57ubrzo1.gif": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh3.ggpht.com\/u_YgKcmKxBybLDl8Ka3spKLSk1TrsPxhMWRWa5VeHENhMeHW6fQclNtuoyC7r8AXQEMJqCXLhcP5isiP4paebQ=s90",
                "blob_key": "AMIfv97WWxiIwF7XjdUndG0NYnU2htNm-EGLjK3p-6haRBjFiGQjEVqZMzIQyV3BRCbfKGMGysBNFXxB8N7jjaJErrtcbXEYO1WtUm89uWnt8QAbNIwvM5x-oJYhK8PvaP7E8hLscV95dfol1KYIazoSNSao1KXMPg",
                "height": 90,
                "width": 90,
                "filename": "2123773ed57ubrzo1.gif",
                "id": 56003
            },
            "rocket_launch.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh4.ggpht.com\/gSiqD6rWYYSCjFS_7491dD6sQfYLIZn1MySNHlhGVIZPzE-F0WfU5SiI-SCJN3DoP14l58OSa7bqCJEHJ5Tjc5k=s155",
                "blob_key": "AMIfv94cahOuyaMS1HH1wNs31-bbCNbZWXWgrmHoyyUUcj7CnB_Iw64300Nz0YfAup2kGRp7iwMNmEjhCO4VMOPtdTyJOHS_mqF591uvAk5TT20rjGNtiYyhezaE0NUhREv7Dl1CEWy6j4ew17NLgiA7zvvd970VxA",
                "height": 151,
                "width": 155,
                "filename": "rocket_launch.png",
                "id": 55005
            },
            "sun.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/os_yYRygush_fHtA5BINO8AOQZAol_8wXJ-Rhm3vtNogKvE3UP2XH4um6xL3uGBinuJvJwap7u9vL977ZO7WW7o=s151",
                "blob_key": "AMIfv94OF_leW-QmL773YL2yT1QEKfp2Mv5RE_NfMjKFZ04ja_eSkc5_diOpr7AZka9VPJJo0DFWLw93xW9X9XGWrP3T1sNTUktOyqWdD2ABphlb-O59r4Boe2-8KtI2-3YzVjZcaldd7JTISULBBm8TPkqDgIUNAg",
                "height": 151,
                "width": 151,
                "filename": "sun.png",
                "id": 57002
            },
            "rocket.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh4.ggpht.com\/sU2ywvHHFWw8kdSw3QGaiJ3_fG1vxdRFFEq8IziPtSuSsdDt1nJEOuhfXWXhAKKEBnynfq91DHJVbAZxx_dqzg=s141",
                "blob_key": "AMIfv97X9xWuOT_TiX89tuFSNrwK_Lq7gWdZNA3ogs5N_aeu1F9yy-rQCf42CexKO-uVUYeuio-UL2khw0Uf-pqlw75CqtwdeMQHq9j9iqDPzoVRRYu3KRCjYTwsCWpNjSfgmYLqnyUg0Fu9Wn1HzVHonyWFFL4Ajw",
                "height": 141,
                "width": 96,
                "filename": "rocket.png",
                "id": 58001
            },
            "grass.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh4.ggpht.com\/Rn9MF2JIb4ipTms1Lta54r7F0Pzz39BrYd_RQE3lvHwvwoSKXh33bVwztuAfa31HGIRd5RnCQMb21gAJmhbAaUqw=s1280",
                "blob_key": "AMIfv959J2kRaD7SfA152mg3_BpiCXpI3wWrfej80dXc4Rdd2qdZW6brWhsT2PdbHEvqWbvkRaQxBpbrfOfN2cLuSXCUtOZCLeDLYFfvnotP2A2V-QQlI7cTh3IPhQq5dlBlJPTXtc2_GanNWjQaAFSsFkOKfLwuAw",
                "height": 122,
                "width": 1280,
                "filename": "grass.png",
                "id": 56001
            },
            "cloud.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/AlD5ipr4N_Pb7GeBXxJxpNpwiav_pDlamk0ey354inqis1BjHKi7mxd5M1_QHjnnA3myjIq7a85RJBTRzJL1sxcS=s110",
                "blob_key": "AMIfv949H6xXlv89zdoB6kxqwzfrhHFWP_U_pcDGXNNj95cM0OwymQ-6phNMaRslzaVvyGya340TeNUtr3IuL42824hdnu9chsCxOwLOrgzSqBLVYAWGOoPMceEMGwulYZ93pjEos2PqE96HNVBqYrA3z0IzdlJHjg",
                "height": 77,
                "width": 110,
                "filename": "cloud.png",
                "id": 55002
            },
            "arrow_previous.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/RAJH3gaQpj7Y8h92-zkXtasWqdrP7U4BW_H4xgT_aDnTGrdDzLuMLfkyYY1odU0UVINFSm3sLUXP-Vc6dtsgaMI=s100",
                "blob_key": "AMIfv96U0qLsO7IBdgllvHvWs9auhsPU2VxmeU35JoHTa1gcETL_TtEEm01zcw3a4fBwLPj275BWkHAh5S745y1leLKpz8XpNxjt4f-Ki1yFeQtixcz1IUNIjh5pc_3TZ4rwdhTQMnYm2TTm5IgrIPB8pM9nmtescg",
                "height": 100,
                "width": 40,
                "filename": "arrow_previous.png",
                "id": 57004
            },
            "sign.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/HqThwy88ssVx6JfdTjwMKkdwj1DukjUkVdRlAy-smHC3nHa3pel1JAFv7E-P5ALiV2GkTGaj2UbgNU-IK8yt65A=s240",
                "blob_key": "AMIfv95xSozeJFvlLstW4l3ya7J9Zjz3WtPibbpA_q6LPi8YFPJu2fV6ZlMbse_iCsCsklj5fQvNo5sndsPszyQQFoV0aj1pTR9lxWukgKqPnCyqbNMXrpwXpQjOv-o-CkjFZS9USI52YQqTyx8irl-zvAevd-cG7A",
                "height": 190,
                "width": 240,
                "filename": "sign.png",
                "id": 59002
            },
            "seattle.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh6.ggpht.com\/k5dW3BgcHX81uiiKqgxRXsVUXQHN1UJQq-Tlxmr0t9x23jv282xEVkf3egdVzwm-hCIwu8ikXBsAhqzGU1w71IfU=s453",
                "blob_key": "AMIfv96kWjZKqkFEpIbGlkGZcI_OjdohAcPXt8m3kDoAtckih9B6fVQ2O4TM1wZ5XZsZZU0HqS260Vw2AeOutC2h9uH3q_HS9w0FdOBcPGmB6qe20koVlKK0K_hNrNUin-sg_oX_gAAoQU87dyFvWr-CF0V0WbexMA",
                "height": 185,
                "width": 453,
                "filename": "seattle.png",
                "id": 59001
            },
            "text.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh3.ggpht.com\/KLyMajXG1hF7PbpiIgjYaVVtFhyR6AHQuz3-3buMg1QRY8B5bQHxTPJvUeYU-Jv7dC766aGnfeN6KxP1Kmoijw=s1280",
                "blob_key": "AMIfv97HyQZAjyuA8dFtcQH5RDWPH8AInyJoQWiU769inDCWzzn4dlnM-MZpgLT1UNt5xCRF7bmMirdR6dhA8Hj1XUM4O2EEJDvvXEJo68RNqEmrrmlh62w_4Af6a6Yh3MNdWjE5v9UwIBa0RWThIlng945ikCKsug",
                "height": 85,
                "width": 1280,
                "filename": "text.png",
                "id": 62001
            },
            "arrow_next.png": {
                "structType": "image",
                "user_id": 1001,
                "uifile_name": "widget_embed",
                "url": "http:\/\/lh5.ggpht.com\/clKfPNEIAXLL6x3u-Ryyj39Ylbo4zT2iDmaKpj_v1U4OagDnwhypsKQXjIAq5yPsIyQJINKxc1Ig6DXGQCrRyAA=s100",
                "blob_key": "AMIfv97sCYLjA7JdlG1YTE8LFamVs-htbcqU1KXUtVvZ3zeGIpUlgje8CrQx_2IDgsfOUgcbLg_J1yAk7WEe2YbU-dNKIEo2iWEQtsU0NPhvAuMPJ1bBN0FSj0Yzo_O4BiXdW7nwbj4QS76ObwUruFaa3z4SDJo6CA",
                "height": 100,
                "width": 40,
                "filename": "arrow_next.png",
                "id": 55004
            }
        },
        "elements": {
            "button previous": {
                "structType": "element",
                "statesByKey": {
                    "_default": {
                        "overflow-y": "hidden",
                        "overflow-x": "hidden",
                        "height": 100,
                        "width": 40,
                        "frames": {
                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                            "structType": "frames",
                            "framesByKey": {
                                "_over": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_default": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_down": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_selected": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                }
                            }
                        },
                        "composition": {
                            "orderedKeys": ["child_1"],
                            "structType": "composition",
                            "child_1": {
                                "structType": "element",
                                "statesByKey": {
                                    "_over": {
                                        "opacity": 1
                                    },
                                    "_default": {
                                        "opacity": 0.5,
                                        "src": "arrow_previous.png",
                                        "top": 0,
                                        "height": 100,
                                        "width": 40,
                                        "left": 0
                                    },
                                    "_down": {
                                        "opacity": 1,
                                        "top": 0,
                                        "left": -5
                                    }
                                },
                                "typeName": "image"
                            }
                        },
                        "background-color": "transparent"
                    }
                },
                "typeName": "button"
            },
            "button": {
                "structType": "element",
                "statesByKey": {
                    "_default": {
                        "overflow-y": "hidden",
                        "overflow-x": "hidden",
                        "height": 20,
                        "width": 100,
                        "frames": {
                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                            "structType": "frames",
                            "framesByKey": {
                                "_over": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_default": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_down": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_selected": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                }
                            }
                        },
                        "composition": {
                            "orderedKeys": [],
                            "structType": "composition"
                        },
                        "background-color": "transparent"
                    }
                },
                "typeName": "button"
            },
            "button next": {
                "structType": "element",
                "statesByKey": {
                    "_default": {
                        "overflow-y": "hidden",
                        "overflow-x": "hidden",
                        "height": 100,
                        "width": 40,
                        "frames": {
                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                            "structType": "frames",
                            "framesByKey": {
                                "_over": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_default": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                },
                                "_down": {
                                    "structType": "frame",
                                    "transitionOptions": {
                                        "duration": 0,
                                        "easing": "linearTween",
                                        "after": "stop"
                                    },
                                    "name": "Untitled Frame"
                                },
                                "_selected": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "Untitled Frame"
                                }
                            }
                        },
                        "composition": {
                            "orderedKeys": ["child_1"],
                            "structType": "composition",
                            "child_1": {
                                "structType": "element",
                                "statesByKey": {
                                    "_over": {
                                        "opacity": 1
                                    },
                                    "_default": {
                                        "opacity": 0.5,
                                        "src": "arrow_next.png",
                                        "top": 0,
                                        "height": 100,
                                        "width": 40,
                                        "left": 0
                                    },
                                    "_down": {
                                        "opacity": 1,
                                        "top": 0,
                                        "left": 5
                                    }
                                },
                                "typeName": "image"
                            }
                        },
                        "background-color": "transparent"
                    }
                },
                "typeName": "button"
            },
            "__main__": {
                "structType": "element",
                "statesByKey": {
                    "_default": {
                        "overflow-y": "hidden",
                        "overflow-x": "hidden",
                        "top": 0,
                        "height": 480,
                        "width": 320,
                        "frames": {
                            "orderedKeys": ["_default", "frame_1", "frame_2", "frame_3"],
                            "structType": "frames",
                            "framesByKey": {
                                "frame_1": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "02"
                                },
                                "_default": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "01"
                                },
                                "frame_2": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "03"
                                },
                                "frame_3": {
                                    "structType": "frame",
                                    "transitionOptions": {},
                                    "name": "04"
                                }
                            }
                        },
                        "composition": {
                            "child_8": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 220,
                                        "left": 507
                                    },
                                    "_default": {
                                        "height": 185,
                                        "width": 453,
                                        "top": 220,
                                        "left": 827,
                                        "src": "seattle.png"
                                    },
                                    "frame_2": {
                                        "top": 220,
                                        "left": 187
                                    },
                                    "frame_3": {
                                        "top": 220,
                                        "left": -133
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_9": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 240,
                                        "left": 40
                                    },
                                    "_default": {
                                        "height": 190,
                                        "width": 240,
                                        "top": 240,
                                        "left": 360,
                                        "src": "sign.png"
                                    },
                                    "frame_2": {
                                        "top": 240,
                                        "left": -280
                                    },
                                    "frame_3": {
                                        "top": 240,
                                        "left": -600
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_4": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 246,
                                        "left": -280
                                    },
                                    "_default": {
                                        "height": 141,
                                        "width": 96,
                                        "top": 246,
                                        "left": 40,
                                        "src": "rocket.png"
                                    },
                                    "frame_2": {
                                        "top": 246,
                                        "left": -600
                                    },
                                    "frame_3": {
                                        "top": 246,
                                        "left": -920
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_5": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": -20,
                                        "left": -40
                                    },
                                    "_default": {
                                        "height": 151,
                                        "width": 151,
                                        "top": -30,
                                        "left": 220,
                                        "src": "sun.png"
                                    },
                                    "frame_2": {
                                        "top": -20,
                                        "left": 210
                                    },
                                    "frame_3": {
                                        "top": -40,
                                        "left": -160
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_6": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 60,
                                        "left": 205
                                    },
                                    "_default": {
                                        "height": 77,
                                        "width": 110,
                                        "top": 60,
                                        "left": 320,
                                        "src": "cloud.png"
                                    },
                                    "frame_2": {
                                        "top": 70,
                                        "left": 5
                                    },
                                    "frame_3": {
                                        "top": 60,
                                        "left": -135
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_7": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 10,
                                        "left": -310
                                    },
                                    "_default": {
                                        "height": 77,
                                        "width": 110,
                                        "top": 10,
                                        "left": 10,
                                        "src": "cloud.png"
                                    },
                                    "frame_2": {
                                        "top": 10,
                                        "left": -630
                                    },
                                    "frame_3": {
                                        "top": 10,
                                        "left": -950
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_1": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 0,
                                        "left": -320
                                    },
                                    "_default": {
                                        "height": 480,
                                        "width": 1280,
                                        "top": 0,
                                        "left": 0,
                                        "fill": {
                                            "color1": "#d0fffe",
                                            "color2": "transparent",
                                            "fillType": "gradient"
                                        }
                                    },
                                    "frame_2": {
                                        "top": 0,
                                        "left": -640
                                    },
                                    "frame_3": {
                                        "top": 0,
                                        "left": -960
                                    }
                                },
                                "typeName": "box"
                            },
                            "child_2": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 358,
                                        "left": -320
                                    },
                                    "_default": {
                                        "height": 122,
                                        "width": 1280,
                                        "top": 358,
                                        "left": 0,
                                        "src": "grass.png"
                                    },
                                    "frame_2": {
                                        "top": 358,
                                        "left": -640
                                    },
                                    "frame_3": {
                                        "top": 358,
                                        "left": -960
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_3": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 160,
                                        "left": -320
                                    },
                                    "_default": {
                                        "height": 85,
                                        "width": 1280,
                                        "top": 160,
                                        "left": 0,
                                        "src": "text.png"
                                    },
                                    "frame_2": {
                                        "top": 160,
                                        "left": -640
                                    },
                                    "frame_3": {
                                        "top": 160,
                                        "left": -960
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_16": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 250,
                                        "left": 60
                                    },
                                    "_default": {
                                        "font-size": 12,
                                        "text": "<script src='https:\/\/rocketui.com\/embed\/55001'><\/script> <div class='ruitarget_55001'><\/div>",
                                        "top": 250,
                                        "border-width": 0,
                                        "height": 120,
                                        "padding": "10",
                                        "width": 200,
                                        "text-align": "center",
                                        "font-family": "arial",
                                        "line-height": 20,
                                        "left": 380
                                    },
                                    "frame_2": {
                                        "top": 250,
                                        "left": -270
                                    },
                                    "frame_3": {
                                        "top": 250,
                                        "left": -590
                                    }
                                },
                                "typeName": "textarea"
                            },
                            "structType": "composition",
                            "child_14": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "src": "face_01.png",
                                        "top": 75,
                                        "left": 20
                                    },
                                    "_default": {
                                        "height": 40,
                                        "width": 80,
                                        "top": 60,
                                        "left": 240,
                                        "src": "face_03.png"
                                    },
                                    "frame_2": {
                                        "src": "face_05.png",
                                        "top": 60,
                                        "left": 220
                                    },
                                    "frame_3": {
                                        "top": 60,
                                        "left": -120
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_12": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 50,
                                        "left": -280
                                    },
                                    "_default": {
                                        "height": 40,
                                        "width": 80,
                                        "top": 50,
                                        "left": 40,
                                        "src": "face_01.png"
                                    },
                                    "frame_2": {
                                        "top": 50,
                                        "left": -600
                                    },
                                    "frame_3": {
                                        "top": 50,
                                        "left": -920
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_13": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "src": "face_03.png",
                                        "top": 100,
                                        "height": 40,
                                        "width": 80,
                                        "left": 210
                                    },
                                    "_default": {
                                        "height": 40,
                                        "width": 80,
                                        "top": 100,
                                        "left": 335,
                                        "src": "face_05.png"
                                    },
                                    "frame_2": {
                                        "src": "face_04.png",
                                        "top": 110,
                                        "left": 30
                                    },
                                    "frame_3": {
                                        "top": 100,
                                        "left": -130
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_10": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 310,
                                        "left": 300
                                    },
                                    "_default": {
                                        "height": 170,
                                        "width": 140,
                                        "top": 250,
                                        "left": 620,
                                        "src": "mountain.png"
                                    },
                                    "frame_2": {
                                        "top": 250,
                                        "left": 10
                                    },
                                    "frame_3": {
                                        "top": 250,
                                        "left": -150
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_18": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "height": 77,
                                        "width": 110,
                                        "top": 20,
                                        "left": 490,
                                        "src": "cloud.png"
                                    },
                                    "frame_2": {
                                        "top": 60,
                                        "left": 490
                                    },
                                    "frame_3": {
                                        "top": 70,
                                        "left": 200
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_19": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "height": 40,
                                        "width": 80,
                                        "top": 50,
                                        "left": 500,
                                        "src": "face_05.png"
                                    },
                                    "frame_2": {
                                        "top": 90,
                                        "left": 500
                                    },
                                    "frame_3": {
                                        "src": "face_06.png",
                                        "top": 100,
                                        "height": 40,
                                        "width": 80,
                                        "left": 210
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_17": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "height": 90,
                                        "width": 90,
                                        "top": 340,
                                        "left": 370,
                                        "src": "2123773ed57ubrzo1.gif"
                                    },
                                    "frame_2": {},
                                    "frame_3": {
                                        "top": 340,
                                        "left": 120
                                    }
                                },
                                "typeName": "image"
                            },
                            "orderedKeys": ["child_1", "child_8", "child_4", "child_10", "child_2", "child_3", "child_5", "child_7", "child_9", "child_12", "child_14", "child_17", "child_18", "child_19", "child_21", "child_6", "child_13", "child_26", "child_16", "child_22", "child_23", "child_25", "child_27"],
                            "child_23": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {
                                        "top": 152,
                                        "left": 0
                                    },
                                    "_default": {
                                        "overflow-y": "hidden",
                                        "overflow-x": "hidden",
                                        "top": 152,
                                        "height": 100,
                                        "width": 40,
                                        "mouse-behavior": {
                                            "selectedEventType": "release",
                                            "release": {
                                                "actionType": "goto_previous"
                                            }
                                        },
                                        "asset-name": "button previous",
                                        "frames": {
                                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                                            "structType": "frames",
                                            "framesByKey": {
                                                "_over": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_default": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_down": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_selected": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                }
                                            }
                                        },
                                        "composition": {
                                            "orderedKeys": ["child_1"],
                                            "structType": "composition",
                                            "child_1": {
                                                "structType": "element",
                                                "statesByKey": {
                                                    "_over": {
                                                        "opacity": 1
                                                    },
                                                    "_default": {
                                                        "opacity": 0.5,
                                                        "src": "arrow_previous.png",
                                                        "top": 0,
                                                        "height": 100,
                                                        "width": 40,
                                                        "left": 0
                                                    },
                                                    "_down": {
                                                        "opacity": 1,
                                                        "top": 0,
                                                        "left": -5
                                                    }
                                                },
                                                "typeName": "image"
                                            }
                                        },
                                        "background-color": "transparent",
                                        "left": -40
                                    },
                                    "frame_2": {
                                        "top": 152,
                                        "left": 0
                                    },
                                    "frame_3": {
                                        "top": 152,
                                        "left": 0
                                    }
                                },
                                "typeName": "button"
                            },
                            "child_22": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "overflow-y": "hidden",
                                        "overflow-x": "hidden",
                                        "top": 152,
                                        "height": 100,
                                        "width": 40,
                                        "mouse-behavior": {
                                            "selectedEventType": "release",
                                            "release": {
                                                "actionType": "goto_next"
                                            }
                                        },
                                        "asset-name": "button next",
                                        "frames": {
                                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                                            "structType": "frames",
                                            "framesByKey": {
                                                "_over": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_default": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_down": {
                                                    "structType": "frame",
                                                    "transitionOptions": {
                                                        "duration": 0,
                                                        "easing": "linearTween",
                                                        "after": "stop"
                                                    },
                                                    "name": "Untitled Frame"
                                                },
                                                "_selected": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                }
                                            }
                                        },
                                        "composition": {
                                            "orderedKeys": ["child_1"],
                                            "structType": "composition",
                                            "child_1": {
                                                "structType": "element",
                                                "statesByKey": {
                                                    "_over": {
                                                        "opacity": 1
                                                    },
                                                    "_default": {
                                                        "opacity": 0.5,
                                                        "src": "arrow_next.png",
                                                        "top": 0,
                                                        "height": 100,
                                                        "width": 40,
                                                        "left": 0
                                                    },
                                                    "_down": {
                                                        "opacity": 1,
                                                        "top": 0,
                                                        "left": 5
                                                    }
                                                },
                                                "typeName": "image"
                                            }
                                        },
                                        "background-color": "transparent",
                                        "left": 280
                                    },
                                    "frame_2": {},
                                    "frame_3": {
                                        "top": 152,
                                        "left": 320
                                    }
                                },
                                "typeName": "button"
                            },
                            "child_21": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "color": "#406618",
                                        "text": "Made with Rocket UI",
                                        "top": 450,
                                        "height": 30,
                                        "width": 320,
                                        "left": 0,
                                        "text-align": "center"
                                    },
                                    "frame_2": {},
                                    "frame_3": {}
                                },
                                "typeName": "text"
                            },
                            "child_27": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "width": 155,
                                        "top": 190,
                                        "src": "rocket_launch.png",
                                        "left": -160,
                                        "height": 151
                                    },
                                    "frame_2": {},
                                    "frame_3": {
                                        "top": 40,
                                        "left": 0
                                    }
                                },
                                "typeName": "image"
                            },
                            "child_26": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "opacity": 0.1,
                                        "top": 0,
                                        "border-width": 1,
                                        "height": 480,
                                        "width": 320,
                                        "left": 0,
                                        "fill": {
                                            "color1": "transparent",
                                            "fillType": "solid"
                                        }
                                    },
                                    "frame_2": {},
                                    "frame_3": {}
                                },
                                "typeName": "box"
                            },
                            "child_25": {
                                "structType": "element",
                                "statesByKey": {
                                    "frame_1": {},
                                    "_default": {
                                        "overflow-y": "hidden",
                                        "overflow-x": "hidden",
                                        "top": 440,
                                        "height": 40,
                                        "width": 320,
                                        "mouse-behavior": {
                                            "selectedEventType": "release",
                                            "release": {
                                                "url": "http:\/\/www.rocketui.com",
                                                "actionType": "goto_website",
                                                "target": "_self"
                                            }
                                        },
                                        "asset-name": "button",
                                        "frames": {
                                            "orderedKeys": ["_default", "_over", "_down", "_selected"],
                                            "structType": "frames",
                                            "framesByKey": {
                                                "_over": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_default": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_down": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                },
                                                "_selected": {
                                                    "structType": "frame",
                                                    "transitionOptions": {},
                                                    "name": "Untitled Frame"
                                                }
                                            }
                                        },
                                        "composition": {
                                            "orderedKeys": [],
                                            "structType": "composition"
                                        },
                                        "background-color": "transparent",
                                        "left": 0
                                    },
                                    "frame_2": {},
                                    "frame_3": {}
                                },
                                "typeName": "button"
                            }
                        },
                        "background-color": "white",
                        "left": 0
                    }
                },
                "typeName": "widget"
            }
        }
    }
});