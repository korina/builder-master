$(document).ready( function() {
	var $$class = $.fn.fluxui.$class;
	var types = $.fn.fluxui.types;
	var assets = $.fn.fluxui.assets;
	var eventDispatcher = types.events.dispatcher.getInstance();
	
	$$class.create( {
		namespace : 'editor',
		fields : {
			ed : null,
			ws : null,
			stage : null,
			hud : null,
			elementCounter : 0,
			currentItem : null,
			manipulatorObj : {
				attr : {
					drag: {
						restraint : 'stage',
						onDrag : 'stage.element.drag',
						onDrop : 'stage.element.drop'
					}
				},
				frames : { keys : [], hash : {} }
			},
			eventDispatcher : null,
			manipulator : null,
			propSheetNames : [],
			// panels
			propPanel : null,
			stageProps : null,
			colorPanel : null
		},
		constructor : function() {
			this.ed = $('#movie-container');
			this.ws = $("div[fluxid='workspace']");
			this.stage = $('div[fluxid="stage"]');
			this.hud = $('div[fluxid="hud"]');
			this.eventDispatcher = types.events.dispatcher.getInstance();
			this.propPanel = $("div[fluxid='acc-property-panel']");
			this.stageProps = $("div[fluxid='stage-props']");
			this.colorPanel = $("div[fluxid='color-panel']");
			$('body').css( { overflow: 'hidden', margin: 0, padding: 0 } );
			var _editor = this;
			this.currentItem = this.stage;
			this.manipulator = new types.manipulator( 'overlay', this.manipulatorObj );
			this.hud.append( this.manipulator.node );
			this.stage.parent().css( 'background-color', '#ffffff' ).bind( 'click', function() {
				_editor.manipulator.remove();
				_editor.showPropertySheet( 'stage' );
			} );
			this.propPanel.children().each( function() {
				_editor.propSheetNames.push( $(this).attr('fluxid') );
			} );
			this.showPropertySheet( 'stage' );
			
			$(window).resize( function() {
				_editor.ed.width( $(this).width() );
				_editor.ed.height( $(this).height() );
				_editor.updateHud();
			} ).trigger( 'resize' );

			this.ws.resize( function() {
				var p = $(this).find("div[fluxid='stage-container']")
					q = $(this)
				if ( p.height() > q.height() )
					q.scrollTop( ( p.height() - q.height() ) / 2 );
				if ( p.width() > q.width() )
					q.scrollLeft( ( p.width() - q.width() ) / 2 );
				types.element.getInstance( $( '[fluxid=overlay]' ) ).update();
			} );
			
			this.colorPanel.gradientEditor( { flat: true } );
			types.colorpicker.current( types.element.getInstance( $("[fluxid='stage-color-picker']") ) );
			
			// update stage property sheet
			this.eventDispatcher.dispatch(this,'events.stage.width.changed',this.stage.width());
			this.eventDispatcher.dispatch(this,'events.stage.height.changed',this.stage.height());
			this.eventDispatcher.dispatch(this,'events.stage.id.changed',this.stage.attr('id'));
			this.eventDispatcher.dispatch(this,'events.stage.class.changed',this.stage.attr('class'));
			
			// attach events
			this.eventDispatcher.addListener( 'properties.element.*', function( $ns, $evt ) {
				var c = $($evt.target);
				var t = types.element.getInstance( types.element.targets[0].get(0) ),
					i = types.manipulator.getInstance(),
					n = parseInt( c.val() ),
					s = c.val(),
					fid = c.attr( 'fluxid' ),
					p;
				switch( fid ) {
					case 'x':
						p = { 'left' : n };
						i.applyProperties( {props: p} );
						break;
					case 'y':
						p = { 'top' : n };
						i.applyProperties( {props: p} );
						break;
					case 'width':
						p = { 'width' : n };
						i.applyProperties( {props: p} );
						break;
					case 'height':
						p = { 'height' : n };
						i.applyProperties( {props: p} );
						break;
					case 'color':
						t.$node().css( 'color', types.colorpicker.current().color );
						p = null;
						break;
					case 'bgcolor':
						types.colorpicker.colorize( t.$node(), types.colorpicker.current().color );
						p = null;
						break;
					case 'border-width':
						p = { 'border-width' : n };
						break;
					case 'border-radius':
						p = { 'border-radius' : n };
						break;
					case 'border-color':
						p = { 'border-color' : types.colorpicker.current().color };
						break;
					case 'id':
						t.$node().attr('id',s);
						break;
					case 'class':
						t.$node().removeClass(t.$node().attr('class'));
						t.$node().addClass(s);
						break;
					case 'create-style':
						var cn = c.parent().find( '[fluxid="style-name"]' ).val().replace( / /g, '-' );
						if ( cn != '' ) {
							var val =  'font-family:' + '"' + c.parent().find( '[fluxid="typeface"]' ).val() + '"' + ' !important;' +
								'text-decoration:' + c.parent().find( '[fluxid="decoration"]' ).val() + ' !important;' +
								'font-size:' + c.parent().find( '[fluxid="font-size"]' ).val() + 'px !important;' +
								'font-weight:' + c.parent().find( '[fluxid="weight"]' ).val() + ' !important;';
							if ( c.parent().find( '[fluxid="align"]' ).val() !== 'inline' )
								val = val + 'text-align:' + c.parent().find( '[fluxid="align"]' ).val() + ' !important;display:block';
							types.manipulator.getInstance().setStyleClass( cn, val );
							_editor.eventDispatcher.dispatch( _editor,'properties.style.update' );
						} else
							alert( 'Please give this configuration a class name' );
						break;
				}
				if ( p != null )
					t.applyProperties( { props: p } );
				types.manipulator.getInstance().update();
			} );

			this.eventDispatcher.addListener( 'properties.style.update', function() {
				var classes = types.manipulator.getInstance().returnStyleClasses();
				$( '[fluxid="list-styles"]' ).empty();
				for ( c in classes )
					$( '[fluxid="list-styles"]' ).append( types.element.make( 'listItem', _editor.makeStyleItem( classes[c] ), 'style-' + classes[c] ).node );
			} );
			this.eventDispatcher.addListener( 'properties.style.toggle', function( $nt, $evt ) {
				var style = $( $evt.target ).parent().attr( 'fluxid' ).replace( 'style-', '' );
				types.manipulator.getInstance().toggleStyleClass( style );
			} );
			this.eventDispatcher.addListener( 'properties.style.remove', function( $nt, $evt ) {
				var style = $( $evt.target ).parent().find( '[fluxid="style-name"]' ).val().replace( / /g, '-' );
				if ( confirm( 'Are you sure you want to delete ' + style + '?' ) ) {
					types.manipulator.getInstance().removeStyleClass( style );
					_editor.eventDispatcher.dispatch( _editor,'properties.style.update' );
				}
			} );
			
			var updateElementProperties = function() {
				var e = types.element;
				var t = e.targets[0],
					d = _editor.eventDispatcher;
				var i = e.getInstance( t );
				d.dispatch(_editor,'events.element.width.changed',t.width());
				d.dispatch(_editor,'events.element.height.changed',t.height());
				d.dispatch(_editor,'events.element.x.changed',parseInt(t.css('left')));
				d.dispatch(_editor,'events.element.y.changed',parseInt(t.css('top')));
				d.dispatch(_editor,'events.element.border-radius.changed',i.props['border-radius']);
				d.dispatch(_editor,'events.element.border-width.changed',parseInt(t.css('border-left-width')));
				d.dispatch(_editor,'events.element.border-color.changed',i.props['border-color']);
				d.dispatch(_editor,'events.element.id.changed',t.attr('id'));
				d.dispatch(_editor,'events.element.class.changed',t.attr('class'));
				d.dispatch(_editor,'events.element.textcontent.changed',t.html());
				//d.dispatch(_editor,'events.element.typeface.changed',t.css( 'font-family' ));	
				//d.dispatch(_editor,'events.element.align.changed',i.props['text-align']);
				//d.dispatch(_editor,'events.element.decoration.changed',i.props['text-decoration']);
				//d.dispatch(_editor,'events.element.font-size.changed', i.props['font-size'] );
				//d.dispatch(_editor,'events.element.weight.changed', i.props['font-weight'] );
				d.dispatch(_editor,'events.element.bgcolor.changed',i.props['fill']);
				d.dispatch(_editor,'events.element.color.changed',t.css('color'));
				//d.dispatch(_editor,'events.element.font-family.changed',t.css('font-family'));
				//d.dispatch(_editor,'events.element.font-size.changed',parseInt(t.css('font-size')));
			};

			this.eventDispatcher.addListener( 'properties.align.*', function( $ns, $evt ) {
				var ts = types.element.targets, align,
				    i = types.element.getInstance,
				    evt = $ns.replace( 'properties.align.', '' );
				i( $( '[fluxid=overlay]' ) ).addTargets( 'overlay' );
				switch ( evt ) {
					case 'left' :
						align = parseInt( ts[0].css( 'left' ) );
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' && parseInt( ts[t].css( 'left' ) ) < align )
								align = parseInt( ts[t].css( 'left' ) );
						for ( t in ts )
							ts[t].css( 'left', align );
						break;
					case 'right' :
						align = parseInt( ts[0].css( 'left' ) ) + parseInt( ts[0].outerWidth() );
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' && ( parseInt( ts[t].css( 'left' ) ) + parseInt( ts[t].outerWidth() ) ) > align )
								align = parseInt( ts[t].css( 'left' ) ) + parseInt( ts[t].outerWidth() );
						for ( t in ts )
							ts[t].css( 'left', align - parseInt( ts[t].outerWidth() ) );
						break;
					case 'top' :
						align = parseInt( ts[0].css( 'top' ) );
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' && parseInt( ts[t].css( 'top' ) ) < align )
								align = parseInt( ts[t].css( 'top' ) );
						for ( t in ts )
							ts[t].css( 'top', align );
						break;
					case 'bottom' :
						align = parseInt( ts[0].css( 'top' ) ) + parseInt( ts[0].outerHeight() );
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' && ( parseInt( ts[t].css( 'top' ) ) + parseInt( ts[t].outerHeight() ) ) > align )
								align = parseInt( ts[t].css( 'top' ) ) + parseInt( ts[t].outerHeight() );
						for ( t in ts )
							ts[t].css( 'top', align - parseInt( ts[t].outerHeight() ) );
						break;
					case 'center.x' :
						align = 0;
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
								align = align + ( parseInt( ts[t].css( 'left' ) ) + ( parseInt( ts[t].outerWidth() ) / 2 ) );
						for ( t in ts ) {
							var newp = ( align / ( ts.length - 1) ) - ( parseInt( ts[t].outerWidth() ) / 2 ),
							    oldp = parseInt( ts[t].css( 'left' ) );
							if ( ( newp - oldp ) * ( newp - oldp ) >= 2 )
								ts[t].css( 'left', newp )
						}
						break;
					case 'center.y' :
						align = 0;
						for ( t in ts )
							if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
								align = align + ( parseInt( ts[t].css( 'top' ) ) + ( parseInt( ts[t].outerHeight() ) / 2 ) );
						for ( t in ts ) {
							var newp = ( align / ( ts.length - 1) ) - ( parseInt( ts[t].outerHeight() ) / 2 ),
							    oldp = parseInt( ts[t].css( 'top' ) );
							if ( ( newp - oldp ) * ( newp - oldp ) >= 2 )
								ts[t].css( 'top', newp )
						}
						break;
					default :
						console.log( evt );
						break;
				}
				types.manipulator.getInstance().update();
			} );

			this.eventDispatcher.addListener( 'properties.match.*', function( $ns, $evt ) { if ( types.element.targets.length !== 0 ) {
				var ts = types.element.targets, align,
				    evt = $ns.replace( 'properties.match.', '' ),
				    width = 0,
				    height = 0;
				if ( evt === 'width' || evt === 'both' ) {
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' && ts[t].outerWidth() > width )
							width = ts[t].outerWidth();
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
							ts[t].css( 'width', width - ( parseInt( ts[t].css( 'border-left-width' ) ) * 2 ) );
				}
				if ( evt === 'height' || evt === 'both' ) {
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' && ts[t].outerHeight() > height )
							height = ts[t].outerHeight();
					for ( t in ts )
						if ( ts[t].attr( 'fluxid' ) !== 'overlay' )
							ts[t].css( 'height', height - ( parseInt( ts[t].css( 'border-left-width' ) ) * 2 ) );
				}
				types.manipulator.getInstance().update();
			} } );

			this.eventDispatcher.addListener( 'properties.distribute.*', function( $ns, $evt ) { if ( types.element.targets.length !== 0 ) {
				var evt = $ns.replace( 'properties.distribute.', '' ), d = types.manipulator.getInstance().getDimentions(),
				    xy = ( evt === 'left' || evt === 'right' || evt === 'center.x' ) ? 'x' : 'y',
				    nts = types.manipulator.getInstance( ts[0] ).sortTargets( xy ), l = nts.length - 1,
				    w1 = nts[0].outerWidth(), w2 = nts[l].outerWidth(), l1 = nts[0].outerHeight(), l2 = nts[l].outerHeight();
				for ( nt = 1; nt < l; nt++ )
					if ( nt !== 0 && nt !== l ) {
						if ( evt === 'left' )
							nts[nt].css( 'left', d.l + ( ( ( d.w - d.l - w2 )  / ( l ) ) * nt ) );
						if ( evt === 'right' )
							nts[nt].css( 'left', d.l + w1 - nts[nt].outerWidth() + ( ( ( d.w - d.l - w1 ) / ( l ) ) * nt ) );
						if ( evt === 'top' )
							nts[nt].css( 'top', d.t + ( ( ( d.h - d.t - l2 ) / ( l ) ) * nt ) );
						if ( evt === 'bottom' )
							nts[nt].css( 'top', d.t + l1 - nts[nt].outerHeight() + ( ( ( d.h - d.t - l1 ) / ( l ) ) * nt ) );
						if ( evt === 'center.x' )
							nts[nt].css( 'left', d.l + ( w1 / 2 ) + ( ( ( d.w - d.l - ( w1 / 2) - ( w2 / 2 ) ) / ( l ) ) * nt ) - ( nts[nt].outerWidth() / 2 ) );
						if ( evt === 'center.y' )
							nts[nt].css( 'top', d.t + ( l1 / 2 ) + ( ( ( d.h - d.t - ( l1 / 2) - ( l2 / 2 ) ) / ( l ) ) * nt ) - ( nts[nt].outerHeight() / 2 ) );
					}						
				types.manipulator.getInstance().update();
			} } );

			this.eventDispatcher.addListener( 'properties.space.*', function( $ns, $evt ) { if ( types.element.targets.length !== 0 ) {
				var evt = $ns.replace( 'properties.space.', '' ),
				    d = types.manipulator.getInstance().getDimentions(), nts = types.manipulator.getInstance( ts[0] ).sortTargets( evt ),
				    l = nts.length - 1, w1 = nts[0].outerWidth(), w2 = nts[l].outerWidth(), l1 = nts[0].outerHeight(), l2 = nts[l].outerHeight(),
				    xy = ( evt === 'x' ) ? ( d.w - d.l - w1 - w2 ) : ( d.h - d.t - l1 - l2 ), m = 0;
				for ( nt = 1; nt < l; nt++ )
					m = ( evt === 'x' ) ? m + nts[nt].outerWidth() : m + nts[nt].outerHeight();
				m = ( xy - m ) / l;
				for ( nt = 1; nt < l; nt++ )
					if ( nt !== 0 && nt !== l ) {
						if ( evt === 'x' )
							nts[nt].css( 'left', parseInt( nts[nt -1 ].css( 'left' ) ) + nts[nt - 1].outerWidth() + m );
						if ( evt === 'y' )
							nts[nt].css( 'top', parseInt( nts[nt -1 ].css( 'top' ) ) + nts[nt - 1].outerHeight() + m );
					}
				types.manipulator.getInstance().update();
			} } );
			
			this.eventDispatcher.addListener( 'stage.element.selected', updateElementProperties );
			this.eventDispatcher.addListener( 'stage.element.change', updateElementProperties );
			this.eventDispatcher.addListener( 'stage.element.dropped', updateElementProperties );
			
			this.eventDispatcher.addListener( 'events.stage.size', function( ns, stage ) {
				types.element.getInstance( stage ).center( 'both' );
				_editor.updateHud.apply( _editor );
			} );
			
			this.eventDispatcher.addListener( 'properties.stage.*', function( ns, evt ) {
				var c = $(evt.target);
				switch( c.attr( 'fluxid' ) ) {
					case 'width':
						var n = parseInt( c.val() );
						if ( !isNaN( n ) )
							_editor.stage.width( n );
							_editor.eventDispatcher.dispatch( _editor.stage, 'events.stage.size', _editor.stage );
						break;
					case 'height':
						var n = parseInt( c.val() );
						if ( !isNaN( n ) )
							_editor.stage.height( n );
							_editor.eventDispatcher.dispatch( _editor.stage, 'events.stage.size', _editor.stage );
						break;
					case 'stage-color-picker':
						types.colorpicker.colorize( _editor.stage, types.colorpicker.current().color );
						break;
				}
			} );
			
			_editor.eventDispatcher.addListener( 'color.gradient.update', function( ns, color ) {
				var swatch = types.colorpicker.current();
				if ( swatch.allowGradient )
					swatch.setColor( color );
			} );
			
			_editor.eventDispatcher.addListener( 'controls.add.*', function( ns, evt ) {
				var p, mk = types.element.make;
				switch( ns ) {
					case 'controls.add.img':
						p = 'image';
						break;
 					case 'controls.add.lbl':
						p = 'label';
						break;
					default:
						p = 'element';
						break;
				}
				var j = mk( p, _editor.makeState( p ) );
				_editor.currentItem.append( j.node );
				j.fui_selectable = true;
				// we set a background color (overwritten) as an IE hack to fix click binding.
				j.$node().css( 'background-color', '#fff' ).bind( 'click', j.fui_select );
			} );
		
			this.eventDispatcher.addListener( 'stage.element.selected', function( $ns, $prev, $cur ) {
				var inst = types.element.getInstance( $cur );
				_editor.showPropertySheet.call( _editor, inst.entity() );
			} );
			this.setupGlobalKeypressEvents();
		},
		methods : {
			showPropertySheet : function( id ) {
				for ( var t = 0; t < this.propSheetNames.length; t++ )
				{
					//console.log( 'showing sheet ', this.propSheetNames[ t ], this.propSheetNames[ t ] == id + '-props' );
					$("div[fluxid='" + this.propSheetNames[ t ] + "']").toggle( this.propSheetNames[ t ] == id + '-props' );
				}
			},
			updateHud : function() {
				this.hud.css( 'left', this.stage.css( 'left' ) );
				this.hud.css( 'top', this.stage.css( 'top' ) );
			},
			makeState : function( $type ) {
				var eProps = $("div[fluxid='element-props']"),
				    iProps = $("div[fluxid='image-props']"),
				    tProps = $("div[fluxid='text-props']"),
				    data, props;
				switch( $type ) {
					case 'element':
						data = {};
						props = eProps;
						break;
					case 'image':
						data = {
							src: 'empty',
						};
						props = iProps;
						break;
					case 'label':
						data = {
							text: 'Enter text in properties panel',
							editable: true
						};
						props = tProps;
						break;
				}
				data.props = {
					width: Number( props.find("[fluxid='width']").val() ) || 100,
					height: Number( props.find("[fluxid='height']").val() ) || 100,
				};
				var colpick = types.element.getInstance( props.find("[fluxid='bgcolor']") )
				var color = ( !!colpick ) ? colpick.color || '#999999' : '#999999';
				if ( color != null && $type != 'label' ) {
					if ( typeof color == 'string' )
						data.props.fill = {
								type: 'solid',
								colors: [
									{
										rgb: color,
										opacity: 1
									}
								]
							};
					else if ( color.constructor == Array ) {
						data.props.fill = {
								type: 'solid',
								colors: color.slice(0)
							};
					} else
						data.props.fill = color;
				}
				return data;
			},
			makeStyleItem : function( $style ) {
				var data = {
					text : '<input type="submit" value="' + $style + '" />',
					props : {
						'font-family' : 'arial',
						'font-size' : 12,
						'text-align' : 'left',
						position : 'relative',
						width: Number( $( "[fluxid='list-styles']" ).css( 'width' ) ),
						cursor : 'pointer'
					},
					behaviour : {
						click : {
							event : 'properties.style.toggle'
						}
					}
				};
				return data;
			},
			moveForward : function( t ) {
				if ( t.constructor != Array )
					t = [t];
				this.changeIndex( t, 1 );
			},
			moveBack : function( t ) {
				if ( t.constructor != Array )
					t = [t];
				this.changeIndex( t, -1 );
			},
			changeIndex : function( t, dir ) {
				t.sort( function( a, b ) {
					var c = a.index(), d = b.index();
					return ( c < d ) ? -1 : ( c > d ) ? 1 : 0;
				} );
				var n, ni, p, j, data, state;
				for ( var i = 0; i < t.length; i++ ) {
					n = t[i];
					ni = n.index();
					p = n.parent();
					j = types.element.getInstance( n.get( 0 ) );
					state = j.data();
					if ( dir <= 0 && ni == 0 ) continue;
					if ( dir > 0 && ni == p.children().length - 1 ) continue;
					n.remove();
					if ( dir > 0 ) {
						n.insertAfter( p.children().get( ni ) );
					} else {
						n.insertBefore( p.children().get( ni-1 ) );
					}
					j.node = n.get(0);
					n.data( 'currentInstance', j );
					j.data( state );
					n.css( 'background-color', '#fff' ).bind( 'click', j.fui_select );
				}
			},
			setupGlobalKeypressEvents : function() {
				var _editor = this;
				$(document).keydown( function( e ) {
					var c = e.keyCode,
						m = types.manipulator.getInstance().$node(),
						t = types.element.targets;
					var move = function( obj, dir, amt ) {
						obj.css( dir, parseInt( obj.css( dir ) ) + amt );
					}
					if ( c == 46 && t.length > 0 && e.shiftKey === true ) { // delete
						if ( confirm( 'Deleting an item is permanent. Are you sure?' ) ) {
							for ( i = 0; i < t.length; i++ )
								t[i].remove();
							_editor.stage.trigger( 'click' );
						}
					}
					if ( c >= 37 && c <= 40 ) {
						var i;
						if ( e.ctrlKey === true ) {
							switch( c ) {
								case 37:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'left', -1 );
									move( m, 'left', -1 );
									break;
								case 38:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'top', -1 );
									move( m, 'top', -1 );
									break;
								case 39:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'left', 1 );
									move( m, 'left', 1 );
									break;
								case 40:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'top', 1 );
									move( m, 'top', 1 );
									break;
							}
						} else if ( e.ctrlKey === true ) {
							switch( c ) {
								case 37: // left
									break;
								case 38: // up
									_editor.moveForward( t );
									break;
								case 39: // right
									break;
								case 40: // bottom
									_editor.moveBack( t );
									break;
							}
						}
						if ( e.altKey === true || e.ctrlKey === true )
							e.preventDefault();
					}
				} );
			}
		}
	} );
} );
