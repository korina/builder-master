/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	$class.create( {
		namespace : 'video-player',
		inherits : types.component,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			this.entity( 'video-player' );
		},
		fields : {
			isContainer : true
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				var me = this;
				this.bindEvents(); // must call this in order to support the prop sheet
				this.player = this.getChildById( 'video-player-simple' );
				this.video = this.player.getChildById( 'player-video1' );
				this.controls = this.player.getChildById( 'controls-video1' );
				
				// load necessary JQuery code
				var p = types.core.serverPath;
				types.loader.load( [ p + "js/jplayer/jquery.jplayer.min.js", p + "js/jplayer/jplayer.playlist.min.js" ], function() { me.buildPlayer( $id ); } );
			},
			buildPlayer : function( $id ) {
				var me = this;
				console.log( this.video.$node() );
				this.video.$node().jPlayer({
					ready: function() {
						var s = me.states.getCurrentStateData();
						me.setMedia( s.attr.ogv, s.attr.m4v );
					},
					swfPath : types.core.serverPath + 'js',
					supplied : 'ogv, m4v',
					wmode : 'window',
					size : {
						width : me.video.width(),
						height : me.video.height()
					},
					cssSelectorAncestor : '[fluxid="' + $id + '"]'
				});
			},
			setMedia : function( ogv, m4v ) {
				this.video.$node().jPlayer( 'setMedia', {
					ogv : ogv,
					m4v : m4v
				} );
			},
			broadcast : function() {
				var s = this.states.getCurrentStateData();
				this.updatePropSheet( {
					ogv : s.attr.ogv,
					m4v : s.attr.m4v 
				} );
			},
			receive : function( $type, $data ) {
				var s = this.states;
				switch( $type ) {
					case 'ogv' :
					case 'm4v' :
						s.setAttributeOnCurrentState( $type, $data );
						var a = s.getCurrentStateData().attr;
						this.setMedia( a.ogv, a.m4v );
						break;
				}
			}
		}
	} );
	
} )(jQuery,this);