/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var jplayerInstance;
	
	$class.create( {
		namespace : 'jplayer-audiolist',
		inherits : types.component,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			this.entity( 'jplayer-audiolist' );
		},
		fields : {
			isContainer : true
		},
		methods : {
			initialise : function( $id, $descriptor ) {
				var me = this;
				this.bindEvents(); // must call this in order to support the prop sheet
				this.player = this.getChildById( 'audio-player-list' );
				this.audio = this.player.getChildById( 'player-audio2' );
				this.controls = this.player.getChildById( 'controls-audio2' );
				
				// load necessary JQuery code
				types.loader.load( [ "js/jplayer/jquery.jplayer.min.js", "js/jplayer/jplayer.playlist.min.js" ], function() { me.buildPlayer( $id ); } );
			},
			buildPlayer : function( $id ) {
				var s = this.states.getCurrentStateData();
				jplayerInstance = new jPlayerPlaylist({
					jPlayer: this.audio,
					cssSelectorAncestor: this.player
				}, s.attr.audiolist, {
					swfPath: "js/jplayer",
					supplied: "oga, mp3",
					wmode: "window"
				});
			},
			broadcast : function() {
				var s = this.states.getCurrentStateData();
				this.updatePropSheet( {
					audiolist : s.attr.audiolist
				} );
			},
			receive : function( $type, $data ) {
				var s = this.states;
				switch( $type ) {
					case 'addTrack' :
						console.log( jplayerInstance );
						jplayerInstance.add( $data );
						console.log( jplayerInstance );
						//s.setAttributeOnCurrentState( $type, $data );
						break;
					case 'removeTrack' :
						break;
					case 'setPlaylist' :
						jplayerInstance.setPlaylist( $data );
						s.setAttributeOnCurrentState( $type, $data ); 
						break;
				}
			}
		}
	} );
	
} )(jQuery,this);
