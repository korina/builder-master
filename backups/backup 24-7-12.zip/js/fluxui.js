(function($){var eventDispatcher={};$.fn.fluxui=function($movie,onLoaded){var $container=$(this);$container.empty();eventDispatcher=types.events.dispatcher.getInstance();var m;var rtn=this.each(function(){if(!$movie)$.fn.fluxui.log("No movie to parse. Exiting.");if(!!$movie&&!!$movie.assets){var _assets=new Array();for(a in $movie.assets){_assets.push($movie.assets[a]);}
if(_assets.length>0){types.core.preload(_assets);}
$.extend(true,assets,$movie.assets);}
if(!!$movie.movie){var me=this;me.parseMovie=function(){var cb=function(){m=this.node;if('absolute'!=$container.css('position')&&'relative'!=$container.css('position'))
$container.css('position','relative');m=types.element.getInstance(m);}
types.serialiser.parse('root_'+types.core.nextMovieCounter(),$movie.movie,null,cb,$container);if(!!onLoaded)
onLoaded({movie:rtn,eventDispatcher:eventDispatcher,types:types,inst:m});}
var list=types.loader.classesToLoad($movie.movie);if(list.length>0)
types.loader.load(list,function(){me.parseMovie();});else
me.parseMovie();}else{$.fn.fluxui.log("Movie structure corrupt.");}});};var assets=$.fn.fluxui.assets=$.fn.fluxui.assets||{};var fdata=$.fn.fluxui.fdata=$.fn.fluxui.fdata||{};var types=$.fn.fluxui.types=$.fn.fluxui.types||{};var $class=$.fn.fluxui.$class=$.fn.fluxui.$class||{};$.fn.fluxui.initialise=function($options){$.extend(true,this.settings,$options);};$.fn.fluxui.evt=function(){return types.events.dispatcher.getInstance();}
$class.create=$.fn.fluxui.$class.create=function(param){if(!param)
return function(){};if(!param.namespace)
throw new Error("Please specify the Namespace.");if(!types[param.namespace]){var clazz=function(){if(param.fields){param.fields.className=param.namespace;extend(this,param.fields,false)}
if(param.props){if(!this['props'])this['props']={};extend(this.props,param.props,false);}
var parentClass=param.inherits||Object;if(typeof parentClass!="function")
throw new TypeError("The parent class is not a function.");if(parentClass!=Object){function F(){};F.prototype=parentClass.prototype;var prototype=new F();prototype.constructor=this;this.prototype=prototype;}
this.Super=parentClass;if(param.constructor){if(typeof param.constructor!="function")
throw new TypeError("Illegal function ["+method+"]!");param.constructor.apply(this,arguments);}};var parentClass=param.inherits||Object;if(typeof parentClass!="function")
throw new TypeError("The parent class is not a function.");if(parentClass!=Object){function F(){};F.prototype=parentClass.prototype;var prototype=new F();prototype.constructor=clazz;clazz.prototype=prototype;}
clazz.prototype.Super=parentClass;if(param.methods){var methods=param.methods;for(var method in methods){if(typeof methods[method]!="function")
throw new TypeError("Illegal function ["+method+"]!");clazz.prototype[method]=methods[method];}}
if(param.statics){var statics=param.statics;for(var name in statics)
clazz[name]=statics[name];}
var name=param.namespace;if(name.length==0||name.indexOf(" ")!=-1||name.charAt(0)=='.'||name.charAt(name.length-1)=='.'||name.indexOf("..")!=-1)
throw new Error("illegal Namespace: "+name);var parts=name.split('.');var container=types;for(var i=0;i<parts.length-1;i++){var part=parts[i];if(!container[part]){container[part]={};}else if(typeof container[part]!="object"){var n=parts.slice(0,i).join('.');throw new Error(n+" already exists and is not an object");}
container=container[part];}
container[parts[parts.length-1]]=clazz;}else
var clazz=types[param.namespace];return clazz;};var extend=$.fn.fluxui.$class.extend=function(obj,ext,override){var prop;if(override===false){for(prop in ext)
if(!(prop in obj))
obj[prop]=ext[prop];}else{for(prop in ext)
obj[prop]=ext[prop];if(ext.toString!==Object.prototype.toString)
obj.toString=ext.toString;}};var settings=$.fn.fluxui.settings={debug:false,defaultTransform:{duration:300,easing:"linearTween",after:"stop"}};var log=$.fn.fluxui.log=function($msg){if(this.settings.debug){if(!!window.console&&!!window.console.log){var log=Function.prototype.bind.call(console.log,console);log.apply(console,arguments);}else{alert($msg);}}};})(jQuery);(function($,window,undefined){'$:nomunge';var elems=$([]),jq_resize=$.resize=$.extend($.resize,{}),timeout_id,str_setTimeout='setTimeout',str_resize='resize',str_data=str_resize+'-special-event',str_delay='delay',str_throttle='throttleWindow';jq_resize[str_delay]=250;jq_resize[str_throttle]=true;$.event.special[str_resize]={setup:function(){if(!jq_resize[str_throttle]&&this[str_setTimeout]){return false;}
var elem=$(this);elems=elems.add(elem);$.data(this,str_data,{w:elem.width(),h:elem.height()});if(elems.length===1){loopy();}},teardown:function(){if(!jq_resize[str_throttle]&&this[str_setTimeout]){return false;}
var elem=$(this);elems=elems.not(elem);elem.removeData(str_data);if(!elems.length){clearTimeout(timeout_id);}},add:function(handleObj){if(!jq_resize[str_throttle]&&this[str_setTimeout]){return false;}
var old_handler;function new_handler(e,w,h){var elem=$(this),data=$.data(this,str_data);data.w=w!==undefined?w:elem.width();data.h=h!==undefined?h:elem.height();old_handler.apply(this,arguments);};if($.isFunction(handleObj)){old_handler=handleObj;return new_handler;}else{old_handler=handleObj.handler;handleObj.handler=new_handler;}}};function loopy(){timeout_id=window[str_setTimeout](function(){elems.each(function(){var elem=$(this),width=elem.width(),height=elem.height(),data=$.data(this,str_data);if(width!==data.w||height!==data.h){elem.trigger(str_resize,[data.w=width,data.h=height]);}});loopy();},jq_resize[str_delay]);};})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'core',statics:{serverPath:'http://50.97.32.67/',preload:function($assets){for(a in $assets)
$('<img/>')[0].src=$assets[a].url;},nextMovieCounter:function(){fdata.counter=fdata.counter||0;return fdata.counter++;},nextElementCounter:function(){fdata.elmCounter=fdata.elmCounter||0;return fdata.elmCounter++;},htmlEncode:function(value){return $('<div/>').text(value).html();},htmlDecode:function(value){return $('<div/>').html(value).text();},clone:function($obj){if(!isNaN($obj)||typeof $obj=='string')return $obj;var newObj=(types.core.isArray($obj))?[]:{};for(i in $obj){if($obj[i]&&typeof $obj[i]=="object"){newObj[i]=types.core.clone($obj[i]);}else newObj[i]=$obj[i]}
return newObj;},map:function(arr,fun){var len=arr.length;if(typeof fun!="function")
throw new TypeError();var res=new Array(len);var thisp=arguments[2];for(var i=0;i<len;i++){if(i in arr)
res[i]=fun.call(thisp,arr[i],i,arr);}
return res;},processElement:function(obj,f){types.core.map(obj.getChildren(),function(e){f(e);types.core.processElement(e,f);});},indexOf:function($array,$value){if(!types.core.isArray($array))return false;for(var i=0;i<$array.length;i++)
if($array[i]==$value)return true;return false;},isObject:function($val){return $val===Object($val);},isArray:function($val){return(!!$val)?$val.constructor==Array:false;},isString:function($val){return toString.call($val)=='[object String]';},isColor:function($val){return!isNaN($val.r)&&!isNaN($val.g)&&!isNaN($val.b);},isEmpty:function($val){if(types.core.isArray($val)||types.core.isString($val))return $val.length===0;for(var key in $val)if($val.hasOwnProperty(key))return false;return true;},isURL:function($url){var rx=new RegExp("^(http:\/\/|https:\/\/|www.){1}([0-9A-Za-z]+\.)");if(rx.test($url))
return true;return false;},isEqual:function($oa,$ob){var p;for(p in $oa){if(typeof($ob[p])=='undefined'){return false;}}
for(p in $oa){if($oa[p]){switch(typeof($oa[p])){case'object':if(!types.core.isEqual($oa[p],$ob[p])){return false;}
break;case'function':if(typeof($ob[p])=='undefined'||($oa[p].toString()!=$ob[p].toString()))
return false;break;default:if($oa[p]!=$ob[p]){return false;}}}else{if($ob[p])
return false;}}
for(p in $ob){if(typeof($oa[p])=='undefined'){return false;}}
return true;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'events.dispatcher',fields:{delimiter:'.',wildcard:'*',_stack:{}},methods:{addListener:function($evt,$handler){var pntr=types.events.dispatcher.getInstance()._getNamespaceSegment($evt);if(!this.hasListener($evt,$handler))
pntr._handlers.push($handler);},removeListener:function($evt,$handler){var pntr=types.events.dispatcher.getInstance()._getNamespaceSegment($evt);if(!$pntr._handlers)$pntr._handlers=[];for(var t=0;t<$pntr._handlers.length;t++)
if($pntr._handlers[t]==$handler){$pntr._handlers.splice(t);return;}},hasListener:function($evt,$handler){if(!$handler||typeof $handler!='function')throw'Event handler must be supplied as a function';var pntr=types.events.dispatcher.getInstance()._getNamespaceSegment($evt);if(!pntr._handlers)pntr._handlers=[];var f=false;for(var t=0;t<pntr._handlers.length;t++)
if(pntr._handlers[t]==$handler)
f=true;return f;},dispatch:function($obj,$evt){var args=Array.prototype.slice.call(arguments);args.shift();types.events.dispatcher.getInstance()._dispatch.apply($obj,args);},_dispatch:function($evt){var pntr=types.events.dispatcher.getInstance()._getNamespaceSegment($evt,true),args=Array.prototype.slice.call(arguments,0);for(var i=0;i<pntr.length;i++)
for(var j=0;j<pntr[i]._handlers.length;j++)
pntr[i]._handlers[j].apply(arguments.caller,args);},bind:function($obj,$trigger,$event){var t=types.events.dispatcher.getInstance();$obj.bind($trigger,function(){var args=Array.prototype.slice.call(arguments);args.unshift($event);t._dispatch.apply($obj,args);});},unbind:function($obj,$trigger){$obj.unbind($trigger);},_getNamespaceSegment:function($evt,$includeWildcards,$arr){var e=(typeof $evt=='string')?$evt.split(this.delimiter):($evt.constructor==Array)?$evt:null;if(!e)throw'Event listener assigned to unknown type';var pntr=this._stack;for(var i=0;i<e.length;i++){if(typeof e[i]!='string')throw'Event identifier segment not a string value';if(e[i]=="_handlers"||(e[i]==this.wildcard&&i<e.length-1))throw'Invalid name used in event namespace.';if(!pntr[e[i]])pntr[e[i]]={};pntr=pntr[e[i]];}
if(!pntr._handlers)pntr._handlers=[];if($includeWildcards){if(!$arr||$arr.constructor!=Array)$arr=[];$arr.push(pntr);if(e[e.length-1]==this.wildcard)
e.pop();if(e.length>0){e.pop();e.push(this.wildcard);this._getNamespaceSegment(e,$includeWildcards,$arr);}
return $arr;}
return pntr;}},statics:{_instance:null,getInstance:function(){types.events.dispatcher._instance=types.events.dispatcher._instance||new types.events.dispatcher();return types.events.dispatcher._instance;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'color',constructor:function($r,$g,$b,$opacity,$pos){this.r=$r||0;this.g=$g||0;this.b=$b||0;this.opacity=($opacity!=null)?$opacity:1;this.pos=$pos||0;},methods:{toRGB:function(){return[this.r,this.g,this.b];},toRGBA:function(){return[this.r,this.g,this.b,this.opacity];},toHex:function($useAlpha,$alphaFirst){var f=types.color.base16;var rgb=[f(this.r),f(this.g),f(this.b)],a=f(Math.round(this.opacity*255))
if(!!$useAlpha){if(!!$alphaFirst)
rgb.unshift(a);else
rgb.push(a);}
return'#'+rgb.join('');}},statics:{base16:function($num){return 16>$num?"0"+$num.toString(16):$num.toString(16);},base10:function($hex){$hex=/#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec($hex);return!Math.isNaN(Number($hex))?$hex:parseInt($hex[1],16)<<16+parseInt($hex[2],16)<<8+parseInt($hex[3],16);},hexToRGBA:function($hex){$hex=/#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/.exec($hex);return!$hex?$hex:[parseInt($hex[1],16),parseInt($hex[2],16),parseInt($hex[3],16),255];},objToRGBA:function($obj){if($obj=="transparent")return[255,255,255,0];if($obj.constructor==Array)return $obj;var hex=types.color.hexToRGBA($obj);return hex?hex:(hex=types.color.RGBAStringToRGBA($obj))?hex:[255,255,255,150];},fromRGB:function($c){if(!$c||$c.constructor!=Array||$c.length<3)return new types.color();return new types.color($c[0],$c[1],$c[2]);},fromRGBA:function($c){var rgb=types.color.fromRGB($c);if(!!$c&&!!$c[3])rgb.opacity=$c[3];return rgb;},fromARGB:function($c){var rgb=types.color.fromRGB($c);if(!!$c[3])rgb.opacity=$c[3];return rgb;},fromHex:function($c){$c=types.color.hexToRGBA($c);return new types.color($c[0],$c[1],$c[2]);},RGBAToRGBAString:function($num){if($num.constructor==Array){var a=new Array();for(i=0;i<$num.length&&i<4;i++)
a.push((i==3)?$num[i]/255:$num[i]);return"rgba("+a.join()+")";}},RGBAStringToRGBA:function($str){$str=/rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/.exec($str);return!$str?$str:[parseInt($str[1],10),parseInt($str[2],10),parseInt($str[3],10),parseInt(void 0==$str[4]?255:$str[4],10)];},RGBAToHex:function($num,$useAlpha){if($num.constructor==Array){var c=[];for(var i=0;i<$num.length;i++)
c[i]=$num[i];if(c.length>3){var alpha=c.pop();if($useAlpha)
c.unshift(alpha);}
var hashed=new Array();for(i in c)
hashed.push(types.color.base16(c[i]));return'#'+hashed.join('');}}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'style',statics:{normaliseBorder:function($size){return{"border-radius":$size,"-moz-border-radius":$size,"-webkit-border-radius":$size};},normaliseFill:function($fillColor){$fillColor=types.core.clone($fillColor);var $fillType=$fillColor.type||'solid',$direction=$fillColor.direction||'top',$colors=$fillColor.colors;if($colors.length==1)
$colors[1]=$colors[0];var fromIE_RGBA=types.color.RGBAToHex(types.color.objToRGBA($colors[0].rgb),true);var toColor=$colors[$colors.length-1].rgb;var toIE_RGBA=types.color.RGBAToHex(types.color.objToRGBA(toColor),true);var clrList='';var color=null;var grdList='';var grdDir='left top, left bottom';switch($direction){case'0deg':grdDir='left top, right top';break;case'315deg':grdDir='left top, right bottom';break;case'270deg':break;case'225deg':grdDir='right top, left bottom';break;case'180deg':grdDir='right top, left top';break;case'135deg':grdDir='right bottom, left top';break;case'90deg':grdDir='left bottom, left top';break;case'45deg':grdDir='left bottom, right top';break;case'center':grdDir='center center, 0px, center center';break;}
$colors.sort(function(a,b){if(!a.pos||!b.pos||(a.pos<b.pos))
return-1;else if(a.pos>b.pos)
return 1;else
return 0;});for(var i=0;i<$colors.length;i++){if(isNaN($colors[i].pos)){var lastPos=0;if($colors.length==1)lastPos=$colors[i].pos=0;else if(i==$colors.length-1)lastPos=$colors[i].pos=1;else lastPos=$colors[i].pos=(1-lastPos)/($colors.length-(i-1))+lastPos;}else lastPos=$colors[i].pos;color=types.color.hexToRGBA($colors[i].rgb);color[3]=$colors[i].opacity*255||255;clrList+=types.color.RGBAToRGBAString(color)+" "+($colors[i].pos*100)+"%";grdList+="color-stop("+($colors[i].pos*100)+"%"+" "+types.color.RGBAToHex(color)+")";if(i<$colors.length-1){clrList+=", ";grdList+=", ";}}
var ret={};switch($fillType){case'radial':grdDir='center center, 0px, center center';ret.background=["-webkit-radial-gradient(center, ellipse cover, "+clrList+")"];break;case'solid':color=types.color.hexToRGBA($colors[0].rgb);color[3]=$colors[0].opacity*255||255;toIE_RGBA=fromIE_RGBA;clrList=types.color.RGBAToRGBAString(color)+" 0%, "+types.color.RGBAToRGBAString(color)+" 100% ";grdList="color-stop(0%"+" "+types.color.RGBAToHex(color)+"), color-stop(100%"+" "+types.color.RGBAToHex(color)+")";default:ret.background=["-webkit-linear-gradient("+$direction+", "+clrList+")"];break;}
ret.filter="progid:DXImageTransform.Microsoft.gradient(startColorStr='"+fromIE_RGBA+"', EndColorStr='"+toIE_RGBA+"')";ret.background.unshift("-webkit-gradient("+($direction=='center'?'radial':'linear')+", "+grdDir+", "+grdList+")");ret.background.push("-moz-linear-gradient("+$direction+", "+clrList+")");ret.background.push("-ms-linear-gradient("+$direction+", "+clrList+")");ret.background.push("-o-linear-gradient("+$direction+", "+clrList+")");ret.background.push("linear-gradient("+$direction+", "+clrList+")");return ret;},getPropertyDiff:function($curProps,$nextProps,$merged){var diff=false;if(!$curProps)
$curProps={};for(var prop in $nextProps){if($nextProps.hasOwnProperty(prop)){if(!$curProps[prop]&&typeof $nextProps[prop]!='object'){$merged[prop]=$nextProps[prop];diff=true;continue;}
if(typeof $nextProps[prop]==='object'){var obj={};if(types.style.getPropertyDiff($curProps[prop],$nextProps[prop],obj)){if(!$merged[prop])$merged[prop]={}
if(prop=="fill")
$.extend(true,$merged[prop],$nextProps[prop]);else
$.extend(true,$merged[prop],obj);diff=true;}}else if($curProps[prop]!=$nextProps[prop]){$merged[prop]=$nextProps[prop];diff=true;}}}
return diff;},canAnimate:function($prop){return types.core.indexOf(['opacity','color','fill','background-color','border-color','border-width','border-radius','line-height','font-size','width','height','top','left'],$prop);},isColor:function($prop){return types.core.indexOf(['color','fill','background-color','border-color'],$prop);},isNumeric:function($prop){return types.core.indexOf(['opacity','border-width','border-radius','line-height','font-size','width','height','min-width','min-height','top','left'],$prop);}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$.fn.fluxui.$class.create({namespace:'timer',statics:{timerID:0,timers:[],start:function(){if(types.timer.timerID)
return;(function(){for(var i=0;i<types.timer.timers.length;i++)
if(types.timer.timers[i]()===false){types.timer.timers.splice(i,1);i--;}
types.timer.timerID=setTimeout(arguments.callee,0);})();},stop:function(){clearTimeout(types.timer.timerID);types.timer.timerID=0;},add:function(fn){types.timer.timers.push(fn);types.timer.start();}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'tween',statics:{getColorTransition:function($start,$end,$pc){var r1=$start.r,g1=$start.g,b1=$start.b,a1=$start.opacity;var r2=$end.r,g2=$end.g,b2=$end.b,a2=$end.opacity
return new types.color(Math.floor(r1+($pc*(r2-r1))+.5),Math.floor(g1+($pc*(g2-g1))+.5),Math.floor(b1+($pc*(b2-b1))+.5),Math.floor(a1+($pc*(a2-a1))+.5));},to:function($owner,$duration,$data){if(!$data&&!$data.values&&!data.values.props)return;var cb=$data.callback||function(){},easing=$data.easing||types.tween.linearTween,args=$data.args||[],props=types.core.clone($data.values.props),nkeys=[],ckeys=[];var f=types.tween[easing];for(i in props){if(props.hasOwnProperty(i)){if(types.style.isColor(i))
ckeys.push(i);else if(types.style.isNumeric(i))
nkeys.push(i);}}
var start=new Date().getTime();var animation=function(){var i,prop,prct,current=new Date().getTime()-start;for(i=0;i<nkeys;i++){prop=nkeys[i];$owner.style(prop,f(current,$data.props[prop],props[prop],$duration));}
for(i=0;i<ckeys;i++){props=ckeys[i];prct=f(current,0,1,$duration);$owner.style(prop,types.tween.getColorTransition($data.props[prop],props[prop],prct));}
if(current>=d){cb.apply($owner,args);return false;}
return true;};},linearTween:function(t,b,c,d){return c*t/d+b;},easeInQuad:function(t,b,c,d){return c*(t/=d)*t+b;},easeOutQuad:function(t,b,c,d){return-c*(t/=d)*(t-2)+b;},easeInOutQuad:function(t,b,c,d){if((t/=d/2)<1)return c/2*t*t+b;return-c/2*((--t)*(t-2)-1)+b;},easeInCubic:function(t,b,c,d){return c*(t/=d)*t*t+b;},easeOutCubic:function(t,b,c,d){return c*((t=t/d-1)*t*t+1)+b;},easeInOutCubic:function(t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t+b;return c/2*((t-=2)*t*t+2)+b;},easeInQuart:function(t,b,c,d){return c*(t/=d)*t*t*t+b;},easeOutQuart:function(t,b,c,d){return-c*((t=t/d-1)*t*t*t-1)+b;},easeInOutQuart:function(t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t+b;return-c/2*((t-=2)*t*t*t-2)+b;},easeInQuint:function(t,b,c,d){return c*(t/=d)*t*t*t*t+b;},easeOutQuint:function(t,b,c,d){return c*((t=t/d-1)*t*t*t*t+1)+b;},easeInOutQuint:function(t,b,c,d){if((t/=d/2)<1)return c/2*t*t*t*t*t+b;return c/2*((t-=2)*t*t*t*t+2)+b;},easeInSine:function(t,b,c,d){return-c*Math.cos(t/d*(Math.PI/2))+c+b;},easeOutSine:function(t,b,c,d){return c*Math.sin(t/d*(Math.PI/2))+b;},easeInOutSine:function(t,b,c,d){return-c/2*(Math.cos(Math.PI*t/d)-1)+b;},easeInExpo:function(t,b,c,d){return(t==0)?b:c*Math.pow(2,10*(t/d-1))+b;},easeOutExpo:function(t,b,c,d){return(t==d)?b+c:c*(-Math.pow(2,-10*t/d)+1)+b;},easeInOutExpo:function(t,b,c,d){if(t==0)return b;if(t==d)return b+c;if((t/=d/2)<1)return c/2*Math.pow(2,10*(t-1))+b;return c/2*(-Math.pow(2,-10*--t)+2)+b;},easeInCirc:function(t,b,c,d){return-c*(Math.sqrt(1-(t/=d)*t)-1)+b;},easeOutCirc:function(t,b,c,d){return c*Math.sqrt(1-(t=t/d-1)*t)+b;},easeInOutCirc:function(t,b,c,d){if((t/=d/2)<1)return-c/2*(Math.sqrt(1-t*t)-1)+b;return c/2*(Math.sqrt(1-(t-=2)*t)+1)+b;},easeInElastic:function(t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return-(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;},easeOutElastic:function(t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d)==1)return b+c;if(!p)p=d*.3;if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);return a*Math.pow(2,-10*t)*Math.sin((t*d-s)*(2*Math.PI)/p)+c+b;},easeInOutElastic:function(t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0)return b;if((t/=d/2)==2)return b+c;if(!p)p=d*(.3*1.5);if(a<Math.abs(c)){a=c;var s=p/4;}
else var s=p/(2*Math.PI)*Math.asin(c/a);if(t<1)return-.5*(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;return a*Math.pow(2,-10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p)*.5+c+b;},easeInBack:function(t,b,c,d,s){if(s==undefined)s=1.70158;return c*(t/=d)*t*((s+1)*t-s)+b;},easeOutBack:function(t,b,c,d,s){if(s==undefined)s=1.70158;return c*((t=t/d-1)*t*((s+1)*t+s)+1)+b;},easeInOutBack:function(t,b,c,d,s){if(s==undefined)s=1.70158;if((t/=d/2)<1)return c/2*(t*t*(((s*=(1.525))+1)*t-s))+b;return c/2*((t-=2)*t*(((s*=(1.525))+1)*t+s)+2)+b;},easeInBounce:function(t,b,c,d){return c-types.tween.easeOutBounce(d-t,0,c,d)+b;},easeOutBounce:function(t,b,c,d){if((t/=d)<(1/2.75)){return c*(7.5625*t*t)+b;}else if(t<(2/2.75)){return c*(7.5625*(t-=(1.5/2.75))*t+.75)+b;}else if(t<(2.5/2.75)){return c*(7.5625*(t-=(2.25/2.75))*t+.9375)+b;}else{return c*(7.5625*(t-=(2.625/2.75))*t+.984375)+b;}},easeInOutBounce:function(t,b,c,d){if(t<d/2)return types.tween.easeInBounce(t*2,0,c,d)*.5+b;return types.tween.easeOutBounce(t*2-d,0,c,d)*.5+c*.5+b;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var defaultStateName='initial';$.fn.fluxui.$class.create({namespace:'state',constructor:function($initial,$states){if($initial)this.initial=types.core.clone($initial);if($states)this.states=types.core.clone($states);var i;for(i in this.states)
if(this.states.hasOwnProperty(i)){this.states[i].props=this.states[i].props||{};this.states[i].attr=this.states[i].attr||{};}
this.initial.attr=this.initial.attr||{};this.initial.props=this.initial.props||{};},fields:{initial:{props:{},attr:{}},states:{},state:defaultStateName},methods:{currentState:function($s){if(!!$s)
this.state=$s;return $s;},getCurrentStateData:function(){return this.getStateData(this.state);},getStateData:function($name){var i=defaultStateName;var props=types.core.clone(this[i]);if(this.state!=$name)
$.extend(props,this.states[$name]);return props;},style:function(type,prop){var dp=this.initial;if(this.state==defaultStateName){if(!!prop)
dp.props[type]=types.core.clone(prop);return dp.props[type];}else{var sp=this.states[this.state].props;if(!!prop)
sp.props[type]=(types.core.isEqual(dp.props[type],prop))?types.core.clone(prop):null;return sp.props[type];}},setAttributeOnCurrentState:function(attr,value){this.setAttributeOnState(this.state,attr,value);},setAttributeOnAllStates:function(attr,value){for(var i in this.states)
if(this.states.hasOwnProperty(i))
this.setAttributeOnState(i,attr,null);this.setAttributeOnState(defaultStateName,attr,value);},setAttributeOnState:function($state,$attr,$value){if($state==defaultStateName)
this.initial.attr[$attr]=$value
else
this.states[$state].attr[$attr]=$value;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$.fn.fluxui.$class.create({namespace:'serialiser',statics:{parse:function(id,data,parent,cb,node){if(!data.type)data.type=='element';var i=types.element.make(data.type,id,data,node),k,v,n;i.applyStateStyles();if(!!parent&&!!parent.addChild)
parent.addChild(i.node);if(!!data.children)
for(var c=0;c<data.children.keys.length;c++){k=data.children.keys[c];v=data.children.hash[k];n=types.serialiser.parse(k,v,i);}
if(!!cb)
cb.call(i);else if(!!i.initialise)
i.initialise(id,data);i.applyStateAttributes();if(!!i.actions)
i.actions.applyBehaviors();return i;},encode:function(obj,output){if(!output)output={};output.type=obj.entity();output.initial=types.core.clone(obj.states.initial);output.states=types.core.clone(obj.states.states);output.frames=types.core.clone(obj.frames);output.data=types.core.clone(obj.data);var c,h;if(obj.numChildren()>0){h=output.children={keys:obj.getChildIds(),hash:{}};c=obj.getChildren();for(var i=0;i<obj.numChildren();i++)
types.serialiser.encode(c[i],h.hash[c[i].fluxid()]={});}
return output;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var toast=function(resources,complete){var toast=this.toast,resource,node,doc=document,head=doc.getElementsByTagName('head')[0],setTimeout=this.setTimeout,createElement='createElement',appendChild='appendChild',addEventListener='addEventListener',onreadystatechange='onreadystatechange',styleSheet='styleSheet',i,scriptsToLoad,ten=10,isComplete=function(){if(--scriptsToLoad<1&&complete&&complete()===false)
setTimeout(isComplete,ten);},watchStylesheet=function(node){if(node.sheet||node[styleSheet])
isComplete();else
setTimeout(function(){watchStylesheet(node);},ten);},watchScript=function(){if(/ded|co/.test(this.readyState))
isComplete();},watchResourceList=function(local,global){return function(){if(local)
local();global();};};if(head||setTimeout(toast,ten)){if(resources===''+resources)
resources=[resources];i=scriptsToLoad=resources.length;while(resource=resources[--i]){if(resource.pop)
toast(resource[0],watchResourceList(resource[1],isComplete));else if(/\.css$/.test(resource)){node=doc[createElement]('link');node.rel=styleSheet;node.href=resource;head[appendChild](node);watchStylesheet(node);}
else{node=doc[createElement]('script');node.src=resource;head[appendChild](node);if(node[onreadystatechange]===null)
node[onreadystatechange]=watchScript;else
node.onload=isComplete;}}}};$class.create({namespace:'loader',statics:{load:function(resources,complete){toast(resources,complete);},classesToLoad:function($data,$list){$list=$list||[];if(!types.element.classLoaded($data.type))$list.push('components/'+$data.type+'/fluxui.class.js');if(!!$data.children){var c=$data.children;for(var i=0;i<c.keys.length;i++)
types.loader.classesToLoad(c.hash[c.keys[i]],$list)}
return $list;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var eventDispatcher=types.events.dispatcher.getInstance();$class.create({namespace:'selection',constructor:function(){},fields:{_targets:[],targetsRelativePos:{x:[],y:[]},touches:{}},methods:{add:function($t){if(!types.core.isArray($t)){if(this.indexOf($t)<0)this._targets.push($('[fluxid="'+$t+'"]'));}else
for(var o=0;o<$t.length;o++)
if(this.indexOf($t[o])<0)
this._targets.push($('[fluxid="'+$t[o]+'"]'));},remove:function($t){if(!types.core.isArray($t))
this._targets.splice(this.indexOf($t),1);else
for(var o=0;o<$t.length;o++)
this._targets.splice(this.indexOf($t[o]),1);},indexOf:function($t){for(var u=0;u<this.length();u++)
if(this._targets[u].attr('fluxid')==$t)
return u;return-1;},sort:function($evt,$ignore){var ts=this._targets,nts=[];if(ts[0].attr('fluxid')!==$ignore)nts.splice(0,0,ts[0]);else nts.splice(0,0,ts[1]);if($evt==='left')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('left'))<parseInt(nts[nt].css('left'))){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);if($evt==='center.x')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('left'))+(ts[t].outerWidth()/2)<parseInt(nts[nt].css('left'))+(nts[nt].outerWidth()/2)){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);if($evt==='right')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('left'))+ts[t].outerWidth()<parseInt(nts[nt].css('left'))+nts[nt].outerWidth()){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);if($evt==='top')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('top'))<parseInt(nts[nt].css('top'))){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);if($evt==='center.y')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('top'))+(ts[t].outerHeight()/2)<parseInt(nts[nt].css('top'))+(nts[nt].outerHeight()/2)){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);if($evt==='bottom')
for(t in ts)
if(ts[t].attr('fluxid')!==$ignore)
for(nt in nts)
if(parseInt(ts[t].css('top'))+ts[t].outerHeight()<parseInt(nts[nt].css('top'))+nts[nt].outerHeight()){nts.splice(nt,0,ts[t]);break;}else if(nt==nts.length-1&&t!=0)
nts.splice(nt+1,0,ts[t]);return nts;},select:function($ms,$t){if((!$ms||$ms===false)&&$t!='overlay')
this.clear();this.add($t);},clear:function(){this._targets=[];this.targetsRelativePos={x:[],y:[]};},targets:function($t){if(!isNaN($t))
return this._targets[$t];return this._targets.slice(0);},length:function(){return this._targets.length;}},statics:{getInstance:function(){var me=types.selection;if(!me._inst)
me._inst=new me();return me._inst;},initGlobalSelection:function(){types.element.prototype.fui_selectable=false;types.element.fui_selectedItem=null;types.element.prototype.fui_select=function(e){if(e)
e.stopPropagation();if(window.event)
window.event.cancelBubble=true;var c=types.element.getInstance(this);if(c.fui_selectable===true){var a=c.$node().parent().attr('fluxid');if(a=='stage'||a=='view'){var cur=types.element.fui_selectedItem;types.element.fui_selectedItem=this;eventDispatcher.dispatch(this,"stage.element.selected",cur,this,e||window.event);}else{console.log(c.fluxid());c.$node().parent().trigger('click');}}};}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var selection=types.selection.getInstance();$class.create({namespace:'interaction',constructor:function($inst,$behavior,$bind){this.inst=$inst;this.behavior=types.core.clone($behavior)||{};this.bind=types.core.clone($bind)||{};},fields:{},methods:{applyBehaviors:function(){var b=this.behavior;if(!!b)
for(var i in b){if(b.hasOwnProperty(i)){if(!!b[i].action)
this.inst.$node().bind(i,{caller:this,event:b[i]},function(e){e.data.caller.doBehavior(e.data.event.action,e.data.event,e);});if(!!b[i].event)
$.fn.fluxui.evt().bind(this.inst.$node(),i,b[i].event);}}},doBehavior:function($action,$data,$e){this.inst[$action]($data,$e);},initDrag:function($c,$d){if(types.interaction.eventSupport('touchstart')===true){$c.$node().unbind('touchstart',this.dragHandler)
$c.$node().bind('touchstart',{params:$d,caller:$c,mobile:true},this.dragHandler);}else{$c.$node().unbind('mousedown',this.dragHandler)
$c.$node().bind('mousedown',{params:$d,caller:$c},this.dragHandler);}},dragHandler:function($event){var sk=$event.shiftKey,d=$event.data,c=d.caller,m=d.mobile,mp=c.mousePosition($event),p=(typeof d.params==='object')?d.params:{},t=p.target;if(!t)t=c.fluxid();if(m!==true)$event.preventDefault();selection.select(sk,t.toString());if(sk===false){for(var t=0;t<selection.length();t++){selection.targetsRelativePos.x[t]=mp.x-parseInt(selection.targets(t).css('left'));selection.targetsRelativePos.y[t]=mp.y-parseInt(selection.targets(t).css('top'));selection.targets(t).trigger('dragged');}
var data={c:c,sk:sk};if(m===true){$('body').bind('touchmove',data,c.actions.moveHandler);$('body').bind('touchend',data,c.actions.dropHandler);}else{$('body').bind('mousemove',data,c.actions.moveHandler);$('body').bind('mouseup',data,c.actions.dropHandler);}}
if($event)
$event.stopPropagation();if(window.event)
window.event.cancelBubble=true;},moveHandler:function($event){$event.preventDefault();var c=$event.data.c,mp=c.mousePosition($event);$('body').css('cursor','move');var move=c.actions.move.call(c,mp);if(move==='drop')
c.actions.dropHandler($event);},dropHandler:function($event){var d=$event.data,c=d.c,sk=d.sk;if(sk===false){for(var t=0;t<selection.length();t++)
selection.targets(t).fadeTo(0,1);$('body').unbind('touchmove',this.moveHandler);$('body').unbind('touchstop',this.dropHandler);$('body').unbind('mousemove',this.moveHandler);$('body').unbind('mouseup',this.dropHandler);$('body').css('cursor','default');}
if($event)
$event.stopPropagation();if(window.event)
window.event.cancelBubble=true;if($event.ctrlKey===true){for(i=0;i<12;i++)
c.move(false,false,{x:40,y:-4});}},move:function($mp,$m){if($mp!==false){for(var t=0;t<selection.length();t++){var c=types.element.getInstance(selection.targets(t));c.$node().fadeTo(0,0.6);c.x($mp.x-selection.targetsRelativePos.x[t],1);c.y($mp.y-selection.targetsRelativePos.y[t],1);}}else if($m)
for(var t=0;t<selection.length();t++){var c=types.element.getInstance(selection.targets(t));c.x(parseInt(selection.targets(t).css('left'))+$m.x,1);c.y(parseInt(selection.targets(t).css('top'))+$m.y,1);}}},statics:{eventSupport:function($eventName){var el=document.createElement('div');$eventName='on'+$eventName;var isSupported=($eventName in el);if(!isSupported){el.setAttribute($eventName,'return;');isSupported=typeof el[$eventName]==='function';}
el=null;return isSupported;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var eventDispatcher=types.events.dispatcher.getInstance();var defaultStateName='initial';$class.create({namespace:'element',constructor:function($id,$descriptor,$node){this._fluxid=$id;this.states=new types.state($descriptor.initial,$descriptor.states);this.frames=types.core.clone($descriptor.frames)||{keys:[],hash:{}};this.data=types.core.clone($descriptor.data)||{};this.actions=new types.interaction(this,$descriptor.behavior,$descriptor.bind);this.makeNode($node);this.__container=this;this.__bg=this;this.__bgOuter=this;this.__border=this;this._children=[];},fields:{markup:'<div />',states:null,frames:{keys:[],hash:{}},frame:defaultStateName,propStore:{}},props:{'position':'absolute','top':0,'left':0,'padding':0,'margin':0,'box-sizing':'border-box','vertical-align':'baseline','word-wrap':'break-word','max-width':'none','max-height':'none','zoom':1,'overflow':'hidden','border':'solid','border-radius':0,'border-width':0,'border-color':new types.color(0,0,0,0),'border-style':'solid'},methods:{fluxid:function(value){if(!!value)
this.$node().attr('fluxid',value);return this.$node().attr('fluxid');},entity:function(value){if(!!value)
this.$node().attr('entity',value);return this.$node().attr('entity');},$node:function(){return $(this.node);},makeNode:function($node){var data=this.states.getCurrentStateData();var n=(!!$node)?$node:$(this.markup);n.data('currentInstance',this);this.node=n.get(0);this.entity(this.className);this.fluxid(this._fluxid);return this.node;},addChild:function(n){var c=types.element.getInstance(n);return this.addChildFromClass(c);},addChildFromClass:function(c){this.__container.$node().append(c.$node());this._children.push(c);c._parent=this;return c;},getChildAt:function(i){var c=this.__container.$node().children().get(i);if(!!c)
return types.element.getInstance(c);},getChildrenById:function(id){var c=this.__container.$node().find("*[fluxid='"+id+"']");if(!!c){if(types.core.isArray(c)&&c.length>0)
for(var i=0;i<c.length;i++)
c[i]=types.element.getInstance(c[i]);else
c=[types.element.getInstance(c)];}
return c;},getChildById:function(id){return this.getChildrenById(id)[0];},getChildren:function($selector){if(!$selector)$selector='*';var t,r=[],c=this.__container.$node().children($selector);if(c.length>0)
for(var i=0;i<c.length;i++){t=types.element.getInstance(c[i]);if(!!t)
r.push(t);}
return r;},getChildIds:function(){var r=[],c=this.getChildren();for(var i=0;i<c.length;i++)
r.push(c[i].fluxid());return r;},numChildren:function(){return this.getChildren().length;},removeChild:function(n){var c=types.element.getInstance(n);this._children.splice(n.index(),1);$(n).remove();return c;},removeChildAt:function(i){var c=this.getChildAt(i);this._children.splice(i,1);if(!c)
return;c.$node().remove();return c;},remove:function(){this.$node().remove();},empty:function(){this._children=[];this.__container.$node().empty();},$parent:function(){return this.$node().parent();},parent:function(){return this._parent;},numFrames:function(){return this.frames.keys.length;},changeFrame:function($frameName,$callback){if($frameName==this.frame||($frameName!=defaultStateName&&(!types.core.indexOf(this.frames.keys,$frameName)||this.numFrames()<1))||this.numChildren()<1)
return;var f=this.frames.hash[$frameName]||{};var duration=f.duration||$.fn.fluxui.settings.defaultTransform.duration;var easing=f.easing||$.fn.fluxui.settings.defaultTransform.easing;var completeAction=f.after||$.fn.fluxui.settings.defaultTransform.after;var c=this.getChildren();var completed=c.length;var callback=function(){completed--;if(completed==0&&!!$callback)
$callback.call(this);}
this.frame=$frameName;for(var i=0;i<c.length;i++)
c[i].updateState.call(c[i],$frameName,duration,easing,callback);},checkAllChildrenTransitioned:function(){var c=this.getChildren();for(var i=0;i<c.length;i++)
if(c[i].states.currentState()!=this.frame)
return false;return true;},updateState:function($stateName,$duration,$easing,$callback){var props=this.states.getStateData($stateName);if(props.attr)
this.applyAttributes(props.attr);if(!isNaN($duration)&&$duration>0){var cb=function(){this.states.currentState($stateName);$callback.call(this);};types.tween.to(this,$duration,{values:props,easing:$easing,callback:cb});}else{if(props.props)
this.applyStyles(props.props);this.states.currentState($stateName);$callback.call(this);}},applyStateStyles:function(){var p=types.core.clone(this.props);var s=this.states.getCurrentStateData();$.extend(p,s.props||{});this.applyStyles(p);},applyStyles:function(props){var n=this.$node();for(var v in props)
if(props.hasOwnProperty(v))
this.style(v,props[v]);},style:function(type,prop,updateState){if(!!prop)
if(!!updateState)
this.states.style(type,types.core.clone(prop));var h=this.styleHyjack(type,prop,updateState);if(h!=false)return h;if(type=='border-radius'){this.numericStyle('-moz-border-radius',prop);this.numericStyle('-webkit-border-radius',prop);this.numericStyle('-khtml-border-radius',prop);}
if(type=='fill')
return this.backgroundStyle(type,prop);if(types.style.isColor(type))
return this.colorStyle(type,prop);if(!isNaN(parseInt(prop)))
return this.numericStyle(type,prop);return this.stringStyle(type,prop);},styleHyjack:function(type,prop,updateState){return false;},removeStyle:function(type){if(!!type)
this.$node().css(type,'');},numericStyle:function(type,val){if(!isNaN(parseInt(val))){if(val.toString().indexOf('%')>-1)
this.$node().css(type,parseInt(val)+"%");else
this.$node().css(type,parseInt(val)+"px");}
return parseInt(this.$node().css(type));},stringStyle:function(type,val){if(typeof val=="string"&&val!="")
this.$node().css(type,val);return this.$node().css(type);},colorStyle:function(type,val){if(typeof val=='string')
val=types.color.fromHex(val);if(types.core.isColor(val))
this.$node().css(type,val.toHex());return types.color.fromRGBA(types.color.hexToRGBA(this.$node().css(type)||'#00000000'));},backgroundStyle:function(type,val){if(!!val&&!!val.colors&&types.core.isArray(val.colors)){val.type=val.type||'solid';var bg=types.style.normaliseFill(val);this.__bg.$node().css('filter',bg.filter);for(var c=0;c<bg.background.length;c++)
this.__bg.$node().css('background',bg.background[c]);}
return this.propStore[type]||new types.color();},applyStateAttributes:function(){var s=this.states.getCurrentStateData();this.applyAttributes(s.attr);},applyAttributes:function(attrs){for(var i in attrs)
if(attrs.hasOwnProperty(i))
this.attribute(i,attrs[i]);},attribute:function(attr,value,updateState){if(!!value){if(!!updateState)
this.states.setAttributeOnCurrentState(attr,value);switch(attr){case'anchor':case'center':case'drag':this[attr](value);break;default:this.$node().attr(attr,value);}}
return this.$node().attr(attr);},anchor:function($a){if($a!=null&&$a.constructor==Array){var $a=$a.slice(0);switch($a.length){case 1:var v=$a[0];$a=[v,v,v,v];break;case 2:var v=$a[0],w=$a[1];$a=[v,w,v,w];break;case 3:$a[3]=$a[2];break;default:break;}
var p=this.$parent();var t=this.$node(),me=this;var loc=[me.y(),p.width()-me.width()-me.x(),p.height()-me.height()-me.y(),me.x()];p.resize(function(){if($a[1]!=0){if($a[3]!=0)
me.width(p.width()-me.x()-loc[1]);else
me.x(p.width()-me.width()-loc[1]);}
if($a[2]!=0){if($a[0]!=0)
me.height(p.height()-me.y()-loc[2]);else
me.y('y',p.height()-me.height()-loc[2]);}});}},center:function($c){if(!!$c&&typeof $c=='string'){var me=this,t=this.$node(),p=this.$parent();p.resize(function(){if($c=='horz'||$c=='both'){me.x((p.outerWidth()-t.outerWidth())/2);}if($c=='vert'||$c=='both'){me.y((p.outerHeight()-t.outerHeight())/2);}});p.trigger('resize');}},drag:function($d){if($d.ondrag){eventDispatcher.unbind(this.$node(),'dragged',$d.ondrag);eventDispatcher.bind(this.$node(),'dragged',$d.ondrag);}
if($d.ondrop){eventDispatcher.unbind(this.$node(),'dropped',$d.ondrop);eventDispatcher.bind(this.$node(),'dropped',$d.ondrop);}
this.actions.initDrag(this,$d);},rect:function($r){if(!!$r){if(!isNaN($r.x))this.x($r.x);if(!isNaN($r.y))this.y($r.y);if(!isNaN($r.w))this.width($r.w);if(!isNaN($r.h))this.height($r.h);}
return{x:this.x(),y:this.y(),w:this.width(),h:this.height()};},x:function($x){return parseInt(this.style('left',$x,arguments[1]!=null));},y:function($y){return parseInt(this.style('top',$y,arguments[1]!=null));},width:function($w){return parseInt(this.style('width',$w,arguments[1]!=null));},height:function($h){return parseInt(this.style('height',$h,arguments[1]!=null));},visible:function($v){$v=($v!=null)?((!!$v)?'inherit':'hidden'):null;return(this.style('visibility',$v,arguments[1]!=null)!='hidden');},mousePosition:function($event){var e=$event?$event:window.event,m=types.interaction.eventSupport('touchstart');return{x:m===true?e.originalEvent.touches[0].pageX:e.pageX,y:m===true?e.originalEvent.touches[0].pageY:e.pageY}}},statics:{getInstance:function($node){return $($node).data('currentInstance');},classLoaded:function($type){return!!types[$type];},make:function($type,$id,$descriptor,$node){if(!$id||$id=="")$id=$type+'_'+types.core.nextElementCounter();if(!$descriptor)$descriptor={initial:{},states:{}};return new types[$type]($id,$descriptor,$node);}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var eventDispatcher=types.events.dispatcher.getInstance();$.fn.fluxui.$class.create({namespace:'component',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);},methods:{bindEvents:function(){eventDispatcher.addListener('properties.'+this.className+'.*',this.propSheetNotification);},updatePropSheet:function($data){for(var i in $data)
if($data.hasOwnProperty(i))
eventDispatcher.dispatch(this,'events.'+this.className+'.'+i+'.changed',$data[i]);},propSheetNotification:function($ns,$evt){var t=$ns.split('.').pop(),c=types.element.getInstance($($evt.target)),id=c.entity(),d;switch(id){case'textarea':case'textfield':case'radiogroup':d=c.text();break;case'dropdown':d=c.value();break;}
this.receive(t,d);},broadcast:function(){},receive:function($type,$data){}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;var eventDispatcher=types.events.dispatcher.getInstance();var defaultStateName='initial';$class.create({namespace:'container',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);this.entity('container');if($.browser.msie){if($.browser.version>=9){this.__bg=new types.element(this.fluxid()+'__bg',{});this.__bg.applyStateStyles();this.__bgOuter=new types.element(this.fluxid()+'__bgOuter',{});this.__bgOuter.$node().append(this.__bg.$node());this.__bgOuter.applyStateStyles();this.$node().append(this.__bgOuter.$node());this.__container=new types.element(this.fluxid()+'__container',{});this.__container.applyStateStyles();this.$node().append(this.__container.$node());this.__border=new types.element(this.fluxid()+'__border',{});this.__border.applyStateStyles();this.$node().append(this.__border.$node());}}},fields:{isContainer:true},methods:{style:function(type,prop,updateState){if(!!prop)
if(!!updateState)
this.states.style(type,types.core.clone(prop));if($.browser.msie&&$.browser.version>=9){if(type.indexOf('border')==0){if(type=='border-radius'){this.__bgOuter.style(type,prop);this.__border.style(type,prop);}else
this.__border.style(type,prop);return;}
if(type=='width'||type=='height'){this.__bgOuter.style(type,prop);this.__bg.style(type,prop);this.__border.style(type,prop);}}
if(type=='fill')
return this.backgroundStyle(type,prop);if(types.style.isColor(type))
return this.colorStyle(type,prop);if(!isNaN(parseInt(prop)))
return this.numericStyle(type,prop);return this.stringStyle(type,prop);}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'button',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);this.entity('button');this.$node().css('cursor','pointer');this.$node().bind('mouseenter',{element:this,stateName:'_over'},function(e){e.data.element.changeFrame(e.data.stateName);}),this.$node().bind('mouseleave',{element:this,stateName:'initial'},function(e){e.data.element.changeFrame(((e.data.element.isSelected)?e.data.element.selectedState:e.data.stateName));}),this.$node().bind('mousedown',{element:this,stateName:'_down'},function(e){e.data.element.changeFrame(e.data.stateName);}),this.$node().bind('mouseup',{element:this,stateName:'_over'},function(e){e.data.element.changeFrame(e.data.stateName);});},fields:{isSelected:false,selectedState:'_selected'},methods:{selected:function(set){this.isSelected=set;var state=(set)?"_selected":"initial";this.changeFrame(state);}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$.fn.fluxui.$class.create({namespace:'form',statics:{getAllFormNames:function($element){if(!$element)
$element='body';var formNames=[];$($element).find('[formName]').each(function(){var thisForm=$(this).attr('formName');var pushing;for(formName in formNames)
if(formNames[formName]===thisForm)
pushing=false;if(pushing!==false)
formNames.push(thisForm);});return formNames;},getByFormName:function($formName,$elClass,$tag,$type){if(!$formName)
var $formName=types.core.getAllFormNames()[0];if(!$elClass&&!$tag&&!$type)
return $('[formName="'+$formName+'"]');else{var returnEls=[];$('[formName="'+$formName+'"]').each(function(){if(!!$elClass&&$(this).hasClass($elClass)===true){for(el in returnEls)
if(returnEls[el]!==this)
var pushing=false;if(pushing!==false)
returnEls.push(this);};if(!!$tag&&this.tagName===$tag){for(el in returnEls)
if(returnEls[el]!==this)
var pushing=false;if(pushing!==false)
returnEls.push(this);};if(!!$type&&$(this).attr('type')===$type){for(el in returnEls)
if(returnEls[el]!==this)
var pushing=false;if(pushing!==false)
returnEls.push(this);}});return returnEls;}}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'input',constructor:function($id,$descriptor){this.Super($id,$descriptor);var me=this;var d=$descriptor,i=d.initial;if(!!i.attr){var a=i.attr;if(a.formName)
this.$node().attr('formName',a.formName);}
if(!!d.bind){var b=d.bind;for(var i in b){if(b.hasOwnProperty(i)){if(!!b[i].event)
$.fn.fluxui.evt().addListener(b[i].event,function($ns,$data){if(i=='text')
me.$node().val($data);else
me.$node().attr(i,$data);});}}}},fields:{markup:'<input />'},inherits:types.element,methods:{addChild:function($id,$elem,$marker,$value,$type,$group,$chosen){$chosen=!$chosen?'':' '+$chosen;$value=!$value?'':' value="'+$value+'"';$type=!$type?'':' type="'+$type+'"';$group=!$group?'':' name="'+$group+'"';$id.append('<'+$elem+$type+$value+$group+$chosen+' >'+$marker+'</'+$elem+'><br />');},removeChild:function($id,$html,$value,$position){if(!$html&&!$value&&!$position)
$id.empty();else
for(option in $id)
if($id[option].html()===$html||$id[option].val===$value||option===$position)
$id[option].remove();}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'checkbox',inherits:types.input,constructor:function($id,$descriptor){this.Super($id,$descriptor);var i=$descriptor.initial;this.$node().attr('type','checkbox');if(!i.attr)return;var a=i.attr;if(a.formName)
this.$node().attr('formName',a.formName);if(a.checked)
this.$node().attr('checked','checked');},methods:{checked:function(){return this.$node().is(':checked');}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'dropdown',inherits:types.input,constructor:function($id,$descriptor){this.Super($id,$descriptor);var i=$descriptor.initial;if(!i.attr)return;var a=i.attr;if(a.formName)
this.$node().attr('formName',a.formName);for(i in a.labels){var elText=a.labels[i];this.addItem(elText,a.values[i])}},fields:{markup:'<select />'},methods:{addItem:function($label,$url){this.addChild(this.$node(),'option',$label,$url);},removeItem:function($label){var c=this.$node().children();var url;for(var i=0;i<c.length;i++)
if($(c[i]).html()==$label){url=$(c[i]).val();$(c[i]).remove();}
return url;},removeAll:function(){this.$node().empty();},index:function($i){if(!isNaN($i))
this.$node().selectedIndex=$i;return this.$node().selectedIndex;},value:function($v){if(!!$v)
this.$node().val($v);return this.$node().val();},text:function($t){if(!!$t)
this.$node().find('option:contains('+$t+')').attr('selected','selected');return this.$node().text();}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'openselect',inherits:types.dropdown,constructor:function($id,$descriptor){this.Super($id,$descriptor);var a=i.attr;this.$node().attr('size',a.labels.length);}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'radiogroup',inherits:types.input,constructor:function($id,$descriptor){this.Super($id,$descriptor);var i=$descriptor.initial;if(!i.attr)return;var a=i.attr;if(a.formName)
this.$node().attr('formName',a.formName);if(!a.text){var text=null}else{var text=a.text};for(l in a.labels){var elText=a.labels[l];this.addChild(this.$node(),'input',elText,a.values[l],'radio',text);}},fields:{markup:'<div class="radiogroup" />'}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'textarea',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);var me=this;var d=$descriptor,i=d.initial;a=i.attr;if(!!a&&!!a.formName)
this.$node().attr('formName',a.formName);if(!!a&&!!a.text)
this.text(a.text);var b=d.bind;if(!!b)
for(var i in b){if(b.hasOwnProperty(i)){if(!!b[i].event){$.fn.fluxui.evt().addListener(b[i].event,function($ns,$data){if(i=='text')
me.$node().val($data);else
me.$node().attr(i,$data);});}}}},fields:{markup:'<textarea />'},methods:{text:function($t){if(!!$t)
this.$node().val($t);return this.$node().val();}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'textfield',inherits:types.input,constructor:function($id,$descriptor){this.Super($id,$descriptor);var i=$descriptor.initial;if(!i.attr)return;var a=i.attr;if(!!a.formName)
this.$node().attr('formName',a.formName);if(a.text==="password"){this.$node().attr('type','password');}else{this.$node().attr('type','text');if(!!a.text)
this.text(a.text);}},fields:{markup:'<input />'},methods:{text:function($t){if(!!$t||$t=='')
this.$node().val(types.core.htmlEncode($t));return this.$node().val();}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'image',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);this.entity('image');},fields:{markup:'<img />'},props:{border:'none'},methods:{src:function($t){if(!!$t)
this.$node().attr('src',$t);return this.$node().attr('src');},initialise:function(){this.clearSrc();},attribute:function(attr,value,updateState){if(!!value){if(!!updateState)this.states.setAttributeOnCurrentState(attr,value);if(attr=='src'){if(!!assets[value]){this.$node().attr(attr,assets[value].url);if(assets[value].height)this.$node().attr('height',assets[value].height);if(assets[value].width)this.$node().attr('width',assets[value].width);}else this.clearSrc();}
else
this.$node().attr(attr,value);}
return this.$node().attr(attr);},styleHyjack:function(type,prop,updateState){return(type=='fill')?null:false;},resetSize:function(cb){var me=this;$("<img/>").attr("src",me.src()).load(function(){var w=this.width,h=this.height;me.width(w);me.height(h);if(!!cb)cb(w,h);});},clearSrc:function(){this.src('http://placehold.it/'+this.width()+'x'+this.height());}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'label',inherits:types.element,constructor:function($id,$descriptor){this.Super($id,$descriptor);this.entity('label');},props:{'overflow':'hidden','font-family':'arial','font-size':12},methods:{text:function($t){if(!!$t){if(!!arguments[1])
this.states.setAttributeOnCurrentState('text',$t);this.$node().html($t);}
return this.$node().html();},attribute:function(attr,value,updateState){if(!!value){if(!!updateState)this.states.setAttributeOnCurrentState(attr,value);if(attr=='text')
this.text(value);else
this.$node().attr(attr,value);}
return this.$node().attr(attr);},styleHyjack:function(type,prop,updateState){return(type=='fill'||type.substr(0,7)=='border-')?0:false;}}});})(jQuery,this);;(function($){var types=$.fn.fluxui.types;var fdata=$.fn.fluxui.fdata;var assets=$.fn.fluxui.assets;var $class=$.fn.fluxui.$class;$class.create({namespace:'unorderedList',constructor:function($id,$descriptor,$node){this._fluxid=$id;this.states=new types.state($descriptor.initial,$descriptor.states);this.frames=types.core.clone($descriptor.frames)||{keys:[],hash:{}};this.data=types.core.clone($descriptor.data)||{};this.actions=new types.interaction(this,$descriptor.behavior,$descriptor.bind);this.makeNode($node);this.__container=this;this.__bg=this;this.__bgOuter=this;this.__border=this;this._children=[];},fields:{markup:'<ul />'},inherits:types.element});$class.create({namespace:'orderedList',constructor:function($id,$descriptor){this.Super($id,$descriptor);},fields:{markup:'<ol />'},inherits:types.element});$class.create({namespace:'item',constructor:function($id,$descriptor){this.Super($id,$descriptor);},fields:{markup:'<li />'},inherits:types.element});})(jQuery,this);