/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Submit class
	 * Provides for the input submit HTML tags.
	 **/
	$class.create( {
		namespace : 'submit',
		inherits : types.input,
		constructor : function( $id, $state ) {
			this.Super( $id, $state );
			if ( $state.formName )
				this.$node().attr( 'formName', $state.formName );
			else {
				this.$node().attr( 'type', 'submit' );
			if ( !!$state.text )
				this.$node().val( types.core.htmlEncode( $state.text ) );
			}
		},
		fields : {
			markup : '<input />'
		}
	} );
	
} )(jQuery,this);
