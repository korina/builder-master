( function( $ ) {
	/*
	var boot = function() {
		var files = [
						"colorpicker/js/colorpicker.js",
						"colorpicker/js/gradient-editor.js",
						
						"js/fluxui/fluxui.js",
						"js/fluxui/fluxui.core.js",
						"js/fluxui/fluxui.events.dispatcher.js",
						"js/fluxui/fluxui.color.js",
						"js/fluxui/fluxui.style.js",
						"js/fluxui/fluxui.timer.js",
						"js/fluxui/fluxui.tween.js",
						"js/fluxui/fluxui.display.element.js",
						"js/fluxui/fluxui.display.button.js",
						"js/fluxui/fluxui.display.form.js",
						"js/fluxui/fluxui.display.form.input.js",
						"js/fluxui/fluxui.display.form.checkbox.js",
						"js/fluxui/fluxui.display.form.dropdown.js",
						"js/fluxui/fluxui.display.form.openselect.js",
						"js/fluxui/fluxui.display.form.radiogroup.js",
						"js/fluxui/fluxui.display.form.textarea.js",
						"js/fluxui/fluxui.display.form.textfield.js",
						"js/fluxui/fluxui.display.image.js",
						"js/fluxui/fluxui.display.label.js",
						"js/fluxui/fluxui.display.lists.js",
						
						"fluxui.controls.js",
						"editor.controls.js",
						"editor.js"
					];
					
		var loadfile = function() {
			if ( files.length > 0 )
				$.getScript( files.shift(), loadfile );
			else
				$.fn.fluxui.evt().dispatch( this, 'app.loaded' );
		};
		loadfile( files.unshift() );
	}
	boot();
	*/

} )(jQuery,this);

$(window).load( function() {
	$.fn.fluxui.evt().dispatch( this, 'app.loaded' );
} );