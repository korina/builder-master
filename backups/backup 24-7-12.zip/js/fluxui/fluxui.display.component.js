/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var eventDispatcher = types.events.dispatcher.getInstance();

	/**
	 * Component class
	 * Provides base functionality for components within the editor.
	 **/
	$.fn.fluxui.$class.create( {
		namespace : 'component',
		inherits : types.element,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
		},
		methods : {
			bindEvents : function() {
				eventDispatcher.addListener( 'properties.' + this.className + '.*', this.propSheetNotification );
			},
			updatePropSheet : function( $data ) {
				for ( var i in $data )
					if ( $data.hasOwnProperty( i ) )
						eventDispatcher.dispatch( this, 'events.' + this.className + '.' + i + '.changed', $data[i] );
			},
			propSheetNotification : function( $ns, $evt ) {
				var t = $ns.split('.').pop(), // type
					c = types.element.getInstance( $($evt.target) ), // control
					id = c.entity(), // control id
					d; // data
				switch ( id ) {
					case 'textarea' :
					case 'textfield' :
					case 'radiogroup' :
						d = c.text();
						break;
					case 'dropdown' :
						d = c.value();
						break;
				}
				this.receive( t, d );
			},
			broadcast : function() {
				// override in subclass
			},
			receive : function( $type, $data ) {
				// override in subclass
			}
		}
	} );
	
} )(jQuery,this);