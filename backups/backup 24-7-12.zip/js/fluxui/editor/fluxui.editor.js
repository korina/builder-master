$(document).ready( function() {
	var $$class = $.fn.fluxui.$class;
	var types = $.fn.fluxui.types;
	var assets = $.fn.fluxui.assets;
	var selection = types.selection.getInstance();
	var eventDispatcher = types.events.dispatcher.getInstance();
	
	$$class.create( {
		namespace : 'editor',
		fields : {
			ed : null,
			ws : null,
			stage : null,
			hud : null,
			view : null,
			movie : null,
			menu : null,
			library : null,
			elementCounter : 0,
			currentItem : null,
			manipulatorObj : {
				initial : {
					attr : {
						drag: {
							restraint : 'workspace',
							ondrag : 'stage.element.drag',
							ondrop : 'stage.element.drop'
						}
					}
				},
				frames : { keys : [], hash : {} }
			},
			eventDispatcher : null,
			manipulator : null,
			propSheetNames : [],
			// panels
			propPanel : null,
			stageProps : null,
			colorPanel : null
		},
		constructor : function( $movie ) {
			var _editor = this;
			this.ed = $('#movie-container');
			this.ws = $movie.getChildById( 'workspace' );
			this.stage = $movie.getChildById( 'stage' );
			this.container = $movie.getChildById( 'stage-container' );
			this.view = $movie.getChildById( 'view' );
			this.menu = $movie.getChildById( 'menu' );
			this.hud = $movie.getChildById( 'hud' );
			this.library = $movie.getChildById( 'library-panel' );
			this.propPanel = $movie.getChildById( 'acc-property-panel' );
			this.stageProps = $movie.getChildById( 'stage-props' );
			this.colorPanel = $movie.getChildById( 'color-panel' );
			$('body').css( { overflow: 'hidden', margin: 0, padding: 0 } );
			this.currentItem = this.stage;
			this.manipulator = types.manipulator.getInstance( 'overlay', this.manipulatorObj );
			
			this.manipulator.applyStateStyles();
			this.hud.addChild( this.manipulator.node );
			this.manipulator.initialise();
			this.manipulator.applyStateAttributes();
			
			this.initialise( $movie );
		},
		methods : {
			initialise : function( $movie ) {
				var _editor = this;
				var ws = this.ws;
				
				// apply selection functions to element class
				types.selection.initGlobalSelection();
				
				this.container.$node().bind( 'click', function() {
					_editor.manipulator.remove();
					_editor.showPropertySheet( 'stage' );
				} );
				this.container.$node().bind( 'dblclick', function() {
					_editor.closeElement();
				} );
				this.propPanel.$node().children().each( function() {
					_editor.propSheetNames.push( $(this).attr('fluxid') );
				} );
				this.showPropertySheet( 'stage' );
							
				$(window).resize( function() {
					_editor.ed.width( $(this).width() );
					_editor.ed.height( $(this).height() );
					_editor.updateHud();
				} ).trigger( 'resize' );
	
				this.ws.$node().resize( function() {
					_editor.handleWorkspaceResize();
				} );
				
				//this.colorPanel.$node().gradientEditor( { flat: true } );
				types.colorpicker.current( $movie.getChildById( 'stage-color-picker' ).$node() );
				
				// update stage property sheet
				eventDispatcher.dispatch(this,'events.stage.width.changed',this.stage.width());
				eventDispatcher.dispatch(this,'events.stage.height.changed',this.stage.height());
				eventDispatcher.dispatch(this,'events.stage.id.changed',this.stage.attribute( 'id' ));
				eventDispatcher.dispatch(this,'events.stage.class.changed',this.stage.attribute( 'class' ));
				
				// attach events
				eventDispatcher.addListener( 'properties.element.*', function( $ns, $evt ) {
					_editor.handlePropertyChange( $($evt.target) );
				} );
				
				eventDispatcher.addListener( 'stage.element.selected', this.handleElementChange );
				eventDispatcher.addListener( 'stage.element.change', this.handleElementChange );
				eventDispatcher.addListener( 'stage.element.dropped', this.handleElementChange );
				
				eventDispatcher.addListener( 'events.stage.size', function( ns, stage ) {
					types.element.getInstance( stage ).center( 'both' );
					_editor.updateHud.apply( _editor );
				} );
				
				eventDispatcher.addListener( 'properties.stage.*', function( ns, evt ) {
					_editor.handleStagePropertyChange( $(evt.target) );
				} );
				
				eventDispatcher.addListener( 'color.gradient.update', function( ns, color ) {
					var swatch = types.colorpicker.current();
					if ( swatch.allowGradient )
						swatch.setColor( color );
				} );
				
				eventDispatcher.addListener( 'controls.add.*', function( ns, evt ) {
					_editor.addElement( ns );
				} );
				
				eventDispatcher.addListener( 'components.add', function( ns, data ) {
					_editor.addComponent( data );
				} );
				
				eventDispatcher.addListener( 'stage.element.selected', function( $ns, $prev, $cur, $evt ) {
					var inst = types.element.getInstance( $cur );
					_editor.showPropertySheet.call( _editor, inst.entity() );
				} );
				
				eventDispatcher.addListener( 'properties.library.item.added', function( $ns, $label, $url ) {
					_editor.propPanel.getChildById( 'asset-source' ).addItem( $label );
				} );
				eventDispatcher.addListener( 'properties.library.item.removed', function( $ns, $label ) {
					_editor.propPanel.getChildById( 'asset-source' ).removeItem( $label );
				} );
				eventDispatcher.addListener( 'events.element.open', function() {
					_editor.openElement();
				} );
				eventDispatcher.addListener( 'menu.*', function( $ns ) {
					_editor.handleMenu( $ns );
				} );
				eventDispatcher.addListener( 'dialog.confirm.save-movie', function( $ns, $filename ) {
					_editor.movieName = $filename;
					_editor.save( $filename );
					types.dialog.getInstance().hide();
				} );
				eventDispatcher.addListener( 'dialog.confirm.open-movie', function( $ns, $filename ) {
					_editor.open( $filename );
					types.dialog.getInstance().hide();
				} );
				eventDispatcher.addListener( 'dialog.confirm.register-user', function( $ns, $user, $pass ) {
					_editor.register( $user, $pass );
				} );
				this.setupGlobalKeypressEvents();
				this.alignment = new types.alignment();
				this.propPanel.getChildById( 'asset-source' ).addItem( '-- Please select --', '-' );
			},
			
			// Event handlers
			handleMenu : function( $evt ) {
				var o = $evt.split('.').pop();
				switch( o ) {
					case 'new':
						this.newRequest();
						break;
					case 'open':
						this.openRequest();
						break;
					case 'save':
						this.saveRequest();
						break;
					case 'login':
						this.loginRequest();
						break;
					case 'register':
						this.registerRequest();
						break;
					case 'embed':
						this.embedRequest();
						break;
				}
			},
			newRequest : function( $force ) {
				this.postSaveCB = null;
				var ed = this;
				if ( this.stage.numChildren() > 0 && !$force ) {
					if ( confirm( 'Do you wish to save your current project?' ) ) {
						this.postSaveCB = function() {
							ed.newRequest( true );
						};
						this.saveRequest();
						return;
					}
				}
				this.newProject();	
			},
			saveRequest : function() {
				var d = types.dialog.getInstance();
				if ( !d.isOpen() ) {
					while ( this.currentItem == this.view )
						this.closeElement();
					if ( this.movieName == null ) {
						var d = types.dialog.getInstance();
						d.setContent( d.saveMovie );
						d.show();
					} else this.save( this.movieName );
				}
			},
			save : function( $name ) {
				var f = {};
				f.movie = types.serialiser.encode( this.stage );
				f.assets = this.library.getAssets();
				var s = this.stageProps;
				f.movie.initial = {
					props: {
						width: s.getChildById( 'width' ).text(),
						height: s.getChildById( 'height' ).text()
					},
					attr: {
						id: s.getChildById( 'id' ).text(),
						class: s.getChildById( 'class' ).text()
					}
				};
				if ( !s.getChildById( 'transparent' ).checked() )
					f.movie.initial.props.fill = {
							type: 'solid',
							colors: [ {
								rgb: s.getChildById( 'stage-color-picker' ).color,
								opacity: 1
							} ]
						}
				var d = JSON.stringify( f );
				var ed = this;
				$.post( "data/?action=put", { name : $name, data : d }, function( data ) {
					if ( data == "-1" ) return alert( 'Could not save. Please login, then try again.' );
					var cb = ed.postSaveCB;
					ed.postSaveCB = null;
					if ( !!cb )
						cb();
				} );
			},
			openRequest : function( $force ) {
				this.postSaveCB = null;
				var ed = this;
				if ( this.stage.numChildren() > 0 && !$force ) {
					if ( confirm( 'Do you wish to save your current project?' ) ) {
						this.postSaveCB = function() {
							ed.openRequest( true );
						};
						this.saveRequest();
						return;
					}
				}
				$.ajax( {
					url: "data/?action=list"
				} ).done( function( data ) {
					ed.updateOpenDialog( data );
				} );
			},
			updateOpenDialog : function( $d ) {
				var l = JSON.parse( $d );
				if ( l == -1 )
					return alert( 'Please login.' );
				if ( l.constructor != Array )
					return alert( 'An error occurred trying to retrieve your files. Please contact an Administrator.' );
				var d = types.dialog.getInstance();
				if ( !d.isOpen() ) {
					while ( this.currentItem == this.view )
						this.closeElement();
					var d = types.dialog.getInstance();
					var lst = d.getChildById( d.fileOpenList );
					lst.removeAll();
					lst.addItem( '-- Please Select --', '-' );
					for ( var i = 0; i < l.length; i++ )
						lst.addItem( l[i].name );
					d.setContent( d.openMovie );
					d.show();
				}				
			},
			open : function( $filename ) {
				var ed = this;
				$.post( "data/?action=get", { name : $filename }, function( data ) {
					var d = JSON.parse( data );
					ed.addMovie( d.data, ed.stage, d.name );
				} );
			},
			addMovie : function( data, view, name ) {
				var i,
				movie = JSON.parse( data ),
				m = movie.movie,
				l = movie.assets,
				c = m.children,
				me = this;
				if ( !!name ) {
					this.newProject();
					this.movieName = name;
				}
				for ( i in l )
					if ( l.hasOwnProperty( i ) )
						this.library.addAsset( l[i].url, i );
				eval( 'var json = ' + data );
				var process = function() {
					for ( i = 0; i < c.keys.length; i++ )
						types.serialiser.parse( i, c.hash[c.keys[i]], view ).fui_selectable = true;
					types.core.processElement( view, function( e ) {
						e.fui_selectable = true;
						e.$node().bind( 'click', e.fui_select );
					} );
					if ( !!name ) {
						var p = json.movie.initial.props;
						eventDispatcher.dispatch(me,'events.stage.width.changed',me.stage.width( parseInt( p.width ) ));
						eventDispatcher.dispatch(me,'events.stage.height.changed',me.stage.height( parseInt( p.height ) ));
					}
				};
				var list = types.loader.classesToLoad( json.movie );
				if ( list.length > 0 )
					types.loader.load( list, function() { process(); } );
				else
					process();
			},
			loginRequest : function( data ) {
				var u = this.menu.getChildById( 'user-txt' ),
					p = this.menu.getChildById( 'pass-txt' ),
					ed = this;
				$.post( "data/?action=login", { u : u.text(), p : p.text() }, function( data ) { 
					switch ( Number( data ) ) {
						case 1:
							ed.menu.showOptions();
							break;
						case 0:
							return alert( 'Unable to login. Did you enter the correct user and pass?' );
							break;
						default:
							return alert( 'An error occurred on the server. If the problem persists, please contact an administrator.' );
							break;
					}
				} );
			},
			registerRequest : function( data ) {
				var d = types.dialog.getInstance();
				if ( !d.isOpen() ) {
					var d = types.dialog.getInstance();
					d.setContent( d.registerUser );
					d.show();
				}
			},
			register : function( user, pass ) {
				var d = types.dialog.getInstance();
				$.post( "data/?action=register", { u : user, p : pass }, function( data ) {
					switch ( Number( data ) ) {
						case 1:
							d.hide();
							alert( 'User successfully registered. Please login.' );
							break;
						case 0:
							alert( 'Username already exists. Please enter another and try again.' );
							break;
						default:
							alert( 'An error occurred on the server. If the problem persists, please contact an administrator.' );
							break;
					}
				} );
			},
			embedRequest : function() {
				var ed = this;
				if ( this.movieName == null )
					return alert( 'Please save your project before requesting to embed.' );
				$.post( "data/?action=embed", { name: this.movieName }, function( data ) { 
					if ( data != '-1' )
						ed.embed( data );
					else
						alert( 'An error occurred on the server. If the problem persists, please contact an administrator.' );
				} );
			},
			embed : function( data ) {
				var d = types.dialog.getInstance();
				d.getChildById( d.embedTxt ).text( data );
				d.setContent( d.embedMovie );
				d.show();
			},
			newProject : function() {
				this.movieName = null;
				this.stage.empty();
				this.stage.width( 400 );
				this.stage.height( 300 );
				this.library.clear();
			},
			handlePropertyChange : function( $control ) {
				if ( selection._targets.length < 1 ) return;
				var t = types.element.getInstance( selection.targets(0).get(0) ),
					i = this.manipulator,
					n = parseInt( $control.val() ),
					s = $control.val(),
					fid = $control.attr( 'fluxid' );
				switch( fid ) {
					case 'x':
						i.x( n );
						t.x( n, 1 );
						break;
					case 'y':
						i.y( n );
						t.y( n, 1 );
						break;
					case 'width':
						i.width( n );
						t.width( n, 1 );
						break;
					case 'height':
						i.height( n );
						t.height( n, 1 );
						break;
					case 'color':
					case 'border-color':
						t.style( fid, types.colorpicker.current().color, 1 );
						break;
					case 'font-family':
					case 'font-size':
					case 'border-width':
					case 'border-radius':
						t.style( fid, s, 1 );
						break;
					case 'bgcolor':
						var c = types.colorpicker.current();
						if ( typeof c.color == 'string' )
							t.style( 'fill', { type: 'solid', colors: [ { rgb: c.color, opacity: c.opacity } ] }, 1 );
						else
							t.style( 'fill', types.core.clone( c.color ), 1 );
						break;
					case 'class':
					case 'id':
						t.attribute( fid, s, 1 );
						break;
					case 'align':
						t.style( 'text-align', s, 1 );
						break;
					case 'decoration':
						t.style( 'text-decoration', s, 1 );
						break;
					case 'weight':
						t.style( 'font-weight', s, 1 );
						break;
					case 'text-content':
						t.text( s, 1 );
						break;
					case 'asset-source':
						t.attribute( 'src', s, 1 );
						break;
					case 'reset-asset':
						t.resetSize( function( w, h ) {
							t.width( i.width( w ), 1 );
							t.height( i.height( h ), 1 );
						} );
						break;
					case 'placeholder-asset':
						t.clearSrc();
						this.propPanel.getChildById( 'asset-source' ).index( 0 );
						break;
				}
				this.manipulator.update();
			},
			handleElementChange : function( $ns, $prev, $cur, $evt ) {
				if ( !!$evt )
					selection.select( $evt.shiftKey, $( $cur ).attr( 'fluxid' ) );
				var t = selection.targets(0),
					d = eventDispatcher;
				var i = types.element.getInstance( t );
				d.dispatch( this, 'events.element.width.changed', i.width() );
				d.dispatch( this, 'events.element.height.changed', i.height() );
				d.dispatch( this, 'events.element.x.changed', parseInt( i.x() ) );
				d.dispatch( this, 'events.element.y.changed', parseInt( i.y() ) );
				d.dispatch( this, 'events.element.border-radius.changed', i.states.style( 'border-radius' ) );
				d.dispatch( this, 'events.element.border-width.changed', parseInt( t.css( 'border-left-width' ) ) );
				//d.dispatch( this, 'events.element.border-color.changed', types.core.clone( i.states.style( 'border-color' ) || '#999999' ) );
				d.dispatch( this, 'events.element.id.changed', i.attribute( 'id' ) );
				d.dispatch( this, 'events.element.class.changed', i.attribute( 'class' ));	
				d.dispatch( this, 'events.element.align.changed', i.states.style( 'text-align' ) );
				d.dispatch( this, 'events.element.decoration.changed', i.states.style( 'text-decoration' ) );
				d.dispatch( this, 'events.element.font-family.changed', i.states.style( 'font-family' ) );
				d.dispatch( this, 'events.element.font-size.changed', i.states.style( 'font-size' ) );
				d.dispatch( this, 'events.element.weight.changed', i.states.style( 'font-weight' ) );
				d.dispatch( this, 'events.element.bgcolor.changed', types.core.clone( i.states.style( 'fill' ) || '#999999' ) );
				//d.dispatch( this, 'events.element.color.changed', types.core.clone( i.states.style( 'color' ) || '#000000' ) );
				d.dispatch( this, 'events.element.font-family.changed', i.states.style( 'font-family' ) );
				d.dispatch( this, 'events.element.font-size.changed', parseInt( i.states.style( 'font-size' ) ) );
				d.dispatch( this, 'events.element.source.changed', i.attribute( 'src' ) );
				
				if ( !!i.text )
					d.dispatch( this, 'events.element.textcontent.changed', i.text() );
			},
			handleStagePropertyChange : function( $control ) {
				var t = $control.attr( 'fluxid' );
				switch( t ) {
					case 'width':
					case 'height':
						var n = parseInt( $control.val() );
						if ( !isNaN( n ) ) {
							this.stage[t]( n );
							this.eventDispatcher.dispatch( this.stage, 'events.stage.size', this.stage );
						}
						break;
					case 'stage-color-picker':
						var c = types.colorpicker.current();
						this.stagecolor = c.color;
						this.stage.style( 'fill', { type: 'solid', colors: [ { rgb: c.color, opacity: c.opacity } ] }, 1 );
						break;
				}
			},
			handleWorkspaceResize : function() {
				var o, p = this.container.$node();
					q = this.ws.$node();
				if ( p.height() > q.height() )
					q.scrollTop( ( p.height() - q.height() ) / 2 );
				if ( p.width() > q.width() )
					q.scrollLeft( ( p.width() - q.width() ) / 2 );
				o = this.ws.getChildById( 'overlay' );
				if ( !!o.update )
					o.update();
			},
			
			
			addElement : function( ns ) {
				var p, mk = types.element.make;
				switch( ns ) {
					case 'controls.add.div':
						p = 'container';
						break;
					case 'controls.add.img':
						p = 'image';
						break;
					case 'controls.add.lbl':
						p = 'label';
						break;
					default:
						p = 'element';
						break;
				}
				var j = mk( p, null, this.makeState( p ) );
				j.applyStateStyles();
				this.currentItem.addChild( j.node );
				if ( !!j.initialise )
					j.initialise();
				j.applyStateAttributes();
				j.fui_selectable = true;
				// we set a background color (overwritten) as an IE hack to fix click binding.
				j.$node().bind( 'click', j.fui_select );
			},
			addComponent : function( $data ) {
				this.addMovie( $data, this.currentItem );
			},
			showPropertySheet : function( id ) {
				var target = id + '-props',
					fnd = false;
				for ( var t = 0; t < this.propSheetNames.length; t++ ) {
					this.propPanel.getChildById( this.propSheetNames[ t ] ).$node().toggle( this.propSheetNames[ t ] == target );
					if ( this.propSheetNames[ t ] == target ) fnd = true;
				}
				if ( !fnd )
					this.propPanel.getChildById( 'container-props' ).$node().toggle( true );
			},
			updateHud : function() {
				this.hud.x( this.currentItem.x() );
				this.hud.y( this.currentItem.y() );
			},
			openElement : function() {
				var t = selection.targets();
				for ( var i = 0; i < 2 && t.length == 2; i++ )
					if ( t[i].attr( 'fluxid' ) != 'overlay' )
						this.render( types.element.getInstance( t[i] ) );
			},
			closeElement : function() {
				if ( this.currentItem != this.stage )
					this.render( this.view.pointer.parent() );
			},
			render : function( $e ) {
				var e = $e.entity();
				var isStage = ( $e == this.container || $e == this.stage );
				if ( !!$e.isContainer || isStage ) {
					this.manipulator.remove();
					( isStage ) ? this.showStage() : this.showView();
					if ( this.view.pointer != null ) {
						var c = this.view._children.splice( 0 );
						this.view.pointer.empty();
						for ( var i = 0; i < c.length; i++ )
							this.view.pointer.addChildFromClass( c[i] ); // yes, we want the parent element to be reset!
					}
					this.view.pointer = ( isStage ) ? null : $e;
					this.view.empty();
					this.view.width( $e.width() );
					this.view.height( $e.height() );
					var c = $e._children.splice( 0 );
					for ( var i = 0; i < c.length; i++ ) {
						this.currentItem.addChild( c[i].$node() );
						c[i].fui_selectable = true;
						c[i].$node().bind( 'click', c[i].fui_select );
					}
				}
			},
			showStage : function() {
				this.stage.visible( true );
				this.view.visible( false );
				this.currentItem = this.stage
			},
			showView : function() {
				this.stage.visible( false );
				this.view.visible( true );
				this.currentItem = this.view;
			},
			makeState : function( $type ) {
				var eProps = this.propPanel.getChildById( 'container-props' );
				var iProps = this.propPanel.getChildById( 'image-props' );
				var tProps = this.propPanel.getChildById( 'label-props' );
				var data = { type : $type, initial : {} }, props;
				var i = data.initial;
				switch( $type ) {
					case 'image':
						props = iProps;
						break;
					case 'label':
						i.attr = { text: 'Enter text in properties panel' };
						props = tProps;
						break;
					default:
						i.attr = {};
						props = eProps;
						break;
				}
				data.initial.props = {
					width: parseInt( props.getChildById( 'width' ).text() ) || 100,
					height: parseInt( props.getChildById( 'height' ).text() ) || 100
				};
				var colpick = props.getChildById( 'bgcolor' );
				var color = ( !!colpick ) ? colpick.color || '#999999' : '#999999';
				if ( color != null && $type != 'label' && $type != 'image' ) {
					if ( typeof color == 'string' )
						i.props.fill = {
								type: 'solid',
								colors: [
									{
										rgb: color,
										opacity: 1
									}
								]
							};
					else if ( color.constructor == Array ) {
						i.props.fill = {
								type: 'solid',
								colors: color.slice(0)
							};
					} else
						i.props.fill = color;
				}
				return data;
			},
			moveForward : function( t ) {
				if ( t.constructor != Array )
					t = [t];
				this.changeIndex( t, 1 );
			},
			moveBack : function( t ) {
				if ( t.constructor != Array )
					t = [t];
				this.changeIndex( t, -1 );
			},
			changeIndex : function( t, dir ) {
				t.sort( function( a, b ) {
					var c = a.index(), d = b.index();
					return ( c < d ) ? -1 : ( c > d ) ? 1 : 0;
				} );
				var n, ni, p, j, data;
				for ( var i = 0; i < t.length; i++ ) {
					n = t[i];
					ni = n.index();
					p = n.parent();
					j = types.element.getInstance( n.get( 0 ) );
					if ( dir <= 0 && ni == 0 ) continue;
					if ( dir > 0 && ni == p.children().length - 1 ) continue;
					n.remove();
					if ( dir > 0 ) {
						n.insertAfter( p.children().get( ni ) );
					} else {
						n.insertBefore( p.children().get( ni-1 ) );
					}
					j.node = n.get(0);
					n.data( 'currentInstance', j );
					n.bind( 'click', j.fui_select );
				}
			},
			setupGlobalKeypressEvents : function() {
				var _editor = this;
				$(document).keydown( function( e ) {
					var inst = function( $i ) { return types.element.getInstance( $i ); };
					var move = function( $i, $f, $n ) {
						var v = inst( $i ), t = v[$f]() + $n;
						v[$f]( t );
					};
					var c = e.keyCode,
						m = types.manipulator.getInstance(),
						t = selection.targets();
					if ( t.length < 1 ) return;
					if ( c == 46 && t.length > 0 ) { // delete
						if ( confirm( 'Deleting an item is permanent. Are you sure?' ) ) {
							for ( i = 0; i < t.length; i++ )
								if ( t[i].attr( 'fluxid' ) != 'overlay' )
									t[i].remove();
							_editor.stage.$node().trigger( 'click' );
						}
					}
					if ( c >= 37 && c <= 40 ) {
						var i;
						if ( e.shiftKey && !e.ctrlKey ) {
							switch( c ) {
								case 37:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'x', - 5 );
									m.x( m.x() - 5 );
									break;
								case 38:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'y', - 5 );
									m.y( m.y() - 5 );
									break;
								case 39:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'x', + 5 );
									m.x( m.x() + 5 );
									break;
								case 40:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'y', + 5 );
									m.y( m.y() + 5 );
									break;
							}
						} else if ( e.shiftKey && e.ctrlKey ) {
							
						} else if ( e.ctrlKey ) {
							switch( c ) {
								case 37: // left
									break;
								case 38: // up
									_editor.moveForward( t );
									break;
								case 39: // right
									break;
								case 40: // bottom
									_editor.moveBack( t );
									break;
							}
						} else {
							switch( c ) {
								case 37:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'x', - 1 );
									m.x( m.x() - 1 );
									break;
								case 38:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'y', - 1 );
									m.y( m.y() - 1 );
									break;
								case 39:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'x', + 1 );
									m.x( m.x() + 1 );
									break;
								case 40:
									for ( i = 0; i < t.length; i++ )
										move( t[i], 'y', + 1 );
									m.y( m.y() + 1 );
									break;
							}
						}
						e.preventDefault();
					}
				} );
			}
		}
	} );
} );
