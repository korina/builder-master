/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Unordered list class
	 * Provides for the select HTML tag
	 **/
	$class.create( {
		namespace : 'unorderedList',
		constructor : function( $id, $descriptor, $node ) {
			this._fluxid = $id;
			this.states = new types.state( $descriptor.initial, $descriptor.states );
			this.frames = types.core.clone( $descriptor.frames ) || {keys : [], hash : {}};
			this.data = types.core.clone( $descriptor.data ) || {};
			this.actions = new types.interaction( this, $descriptor.behavior, $descriptor.bind );
			this.makeNode( $node );
			this.__container = this;
			this.__bg = this;
			this.__bgOuter = this;
			this.__border = this;
			this._children = [];
		},
		fields : {
			markup : '<ul />'
		},
		inherits : types.element
	} );
	
	/**
	 * Ordered list class
	 * Provides for the select HTML tag
	 **/
	$class.create( {
		namespace : 'orderedList',
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
		},
		fields : {
			markup : '<ol />'
		},
		inherits : types.element
	} );
	
	/**
	 * List item class
	 * Provides the item tag for both ordered and unordered lists
	 **/
	$class.create( {
		namespace : 'item',
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
		},
		fields : {
			markup : '<li />'
		},
		inherits : types.element
	} );
	
} )(jQuery,this);
