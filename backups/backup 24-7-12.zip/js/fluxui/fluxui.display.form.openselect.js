/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Openselect class
	 * Provides for multiple lined select HTML tag
	 **/
	$class.create( {
		namespace : 'openselect',
		inherits : types.dropdown,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			var a = i.attr;
			this.$node().attr( 'size', a.labels.length );
		}
	} );
	
} )(jQuery,this);