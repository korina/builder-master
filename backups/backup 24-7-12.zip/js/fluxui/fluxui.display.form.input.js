/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Input class
	 * Provides for the input HTML tag.
	 **/
	$class.create( {
		namespace : 'input',
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			var me = this;
			var d = $descriptor,
				i = d.initial;
			if ( !!i.attr ) {
				var a = i.attr;
				if ( a.formName )
					this.$node().attr( 'formName', a.formName );
			}
			if ( !!d.bind ) {
				var b = d.bind;
				for ( var i in b ) {
					if ( b.hasOwnProperty( i ) ) {
						if ( !!b[i].event )
							$.fn.fluxui.evt().addListener( b[i].event, function( $ns, $data ) {
								if ( i == 'text' )
									me.$node().val( $data );
								else
									me.$node().attr( i, $data );
							} );
					}
				}
			}
		},
		fields : {
			markup : '<input />'
		},
		inherits : types.element,
		methods : {
			// Add a child element
			addChild : function ( $id, $elem, $marker, $value, $type, $group, $chosen ) {
				$chosen = !$chosen ? '' : ' ' + $chosen; // Typically 'selected' or 'checked'
				$value = !$value ? '' : ' value="' + $value + '"';
				$type = !$type ? '' : ' type="' + $type + '"';
				$group = !$group ? '' : ' name="' + $group + '"';
				$id.append( '<' + $elem + $type + $value + $group + $chosen + ' >' + $marker + '</' + $elem + '><br />' );
			},
			// Remove any number of children from an element (passed as a JQuery element)
			removeChild: function ( $id, $html, $value, $position ) {
				if ( !$html && !$value && !$position )
					$id.empty();
				else
					for ( option in $id )
						if ( $id[option].html() === $html || $id[option].val === $value || option === $position )
							$id[option].remove();
			}
		}
	} );
	
} )(jQuery,this);