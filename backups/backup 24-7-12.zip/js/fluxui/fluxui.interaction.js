/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	var selection = types.selection.getInstance();
	
	$class.create( {
		namespace : 'interaction',
		constructor : function( $inst, $behavior, $bind ) {
			this.inst = $inst;
			this.behavior = types.core.clone( $behavior ) || {};
			this.bind = types.core.clone( $bind ) || {};
		},
		fields : {
		},
		methods : {
			
			/**
			 * Behaviors
			 * Applies behaviors to the node. May need re-adding on remove / re-add.
			 **/
			
			applyBehaviors : function() {
				var b = this.behavior;
				if ( !!b )
					for ( var i in b ) {
						if ( b.hasOwnProperty( i ) ) {
							if ( !!b[i].action ) 
								this.inst.$node().bind( i, { caller : this, event : b[i] }, function( e ) {
									// Passing 'doAction' the action, event, and also the whole event object for pageX &c. and 'this' hack
									e.data.caller.doBehavior( e.data.event.action, e.data.event, e );
								} );
							if ( !!b[i].event )
								$.fn.fluxui.evt().bind( this.inst.$node(), i, b[i].event );
						}
					}
			},
			
			// Performs a given action (from string)
			doBehavior : function( $action, $data, $e ) {
				this.inst[$action]( $data, $e );
			},
			
			/**
			 * Drag handlers
			 **/
			
			initDrag : function( $c, $d ) {
				// Check for mobile events support, else use mouse events
				if ( types.interaction.eventSupport( 'touchstart' ) === true ) {
					$c.$node().unbind( 'touchstart', this.dragHandler ) // Reset to avoid multiples when using 'overlay'
					$c.$node().bind( 'touchstart', { params : $d, caller : $c, mobile : true }, this.dragHandler );
				} else {
					$c.$node().unbind( 'mousedown', this.dragHandler ) // Reset to avoid multiples when using 'overlay'
					$c.$node().bind( 'mousedown', { params : $d, caller : $c }, this.dragHandler );
				}
			},
			
			// Mouse dragging handler
			dragHandler : function( $event ) {
				var sk = $event.shiftKey,
					d = $event.data,
					c = d.caller,
				    m = d.mobile,
					mp = c.mousePosition( $event ),
					p = ( typeof d.params === 'object' ) ? d.params : {},
					t = p.target;
				if ( !t ) t = c.fluxid();
				if ( m !== true ) $event.preventDefault();
				selection.select( sk, t.toString() );
				if ( sk === false ) {
				// Starting positions
					for ( var t = 0; t < selection.length(); t++ ) {
						selection.targetsRelativePos.x[t] = mp.x - parseInt( selection.targets(t).css( 'left' ) );
						selection.targetsRelativePos.y[t] = mp.y - parseInt( selection.targets(t).css( 'top' ) );
						selection.targets(t).trigger( 'dragged' ); // Trigger for each target with an 'onDrag'
					}
					var data = { c : c, sk : sk };
					if ( m === true ) {
						$( 'body' ).bind( 'touchmove', data, c.actions.moveHandler );
						$( 'body' ).bind( 'touchend', data, c.actions.dropHandler );
					} else {
						$( 'body' ).bind( 'mousemove', data, c.actions.moveHandler );
						$( 'body' ).bind( 'mouseup', data, c.actions.dropHandler );
					}
				}
				
				if ( $event )
					$event.stopPropagation();
				if ( window.event )
					window.event.cancelBubble = true;
			},
			
			moveHandler : function( $event ) {
				$event.preventDefault();
				var c = $event.data.c, mp = c.mousePosition( $event );
				$( 'body' ).css( 'cursor', 'move' );
				var move = c.actions.move.call( c, mp );
				if ( move === 'drop' )
					c.actions.dropHandler( $event );
			},
			
			dropHandler : function( $event ) {
				var d = $event.data, c = d.c, sk = d.sk;
				if ( sk === false ) {
					for ( var t = 0; t < selection.length(); t++ )
						selection.targets(t).fadeTo( 0, 1 );
					$( 'body' ).unbind( 'touchmove', this.moveHandler );
					$( 'body' ).unbind( 'touchstop', this.dropHandler );
					$( 'body' ).unbind( 'mousemove', this.moveHandler );
					$( 'body' ).unbind( 'mouseup', this.dropHandler );
					$( 'body' ).css( 'cursor', 'default' );
				}
				if ( $event )
					$event.stopPropagation();
				if ( window.event )
					window.event.cancelBubble = true;

				if ( $event.ctrlKey === true ) {
					for ( i = 0; i < 12; i++ )
						c.move( false, false, { x : 40, y : -4 } );
				}
			},
			
			// Moves elements ( also should drop if mouse goes offscreen ) Arguments: restraint (array of left, right,
			// top, bottom), mouse position (relative to document or false), movement (relative to targets or undefined)
			move : function( $mp, $m ) {
				if ( $mp !== false ) {
					for ( var t = 0; t < selection.length(); t++ ) {
						var c = types.element.getInstance( selection.targets(t) );
						c.$node().fadeTo( 0, 0.6 );
						c.x( $mp.x - selection.targetsRelativePos.x[t], 1 );
						c.y( $mp.y - selection.targetsRelativePos.y[t], 1 );
					}
				} else if ( $m )
					for ( var t = 0; t < selection.length(); t++ ) {
						var c = types.element.getInstance( selection.targets(t) );
						c.x( parseInt( selection.targets(t).css( 'left' ) ) + $m.x, 1 );
						c.y( parseInt( selection.targets(t).css( 'top' ) ) + $m.y, 1 );
					}
			}
		},
		statics : {
			/**
			 * Event support
			 * Detect browser support for events ( used to detect mobiles, among other things )
			 * Does not work for detecting 'contextMenu' in Opera as this is too convoluted
			 **/
			
			eventSupport : function( $eventName ) {
				var el = document.createElement('div');
				$eventName = 'on' + $eventName;
				var isSupported = ( $eventName in el );
				if ( !isSupported ) {
					el.setAttribute( $eventName, 'return;' );
					isSupported = typeof el[$eventName] === 'function';
				}
				el = null;
				return isSupported;
			}
		}
	} );
	
} )(jQuery,this);