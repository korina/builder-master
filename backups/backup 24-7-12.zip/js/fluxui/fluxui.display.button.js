/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Button class (Lee, should this have 'fields.markup' as '<button />'?)
	 * Provides for mouse interactivity, complete with button specific states. 
	 * 
	 * Requires:
	 *		fluxui.display.element.js
	 **/
	$class.create( {
		namespace : 'button',
		inherits : types.element,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			this.entity( 'button' );
			this.$node().css( 'cursor', 'pointer' );
			this.$node().bind( 'mouseenter', { element : this, stateName : '_over' }, function( e ) {
				e.data.element.changeFrame( e.data.stateName );
			} ),
			this.$node().bind( 'mouseleave', { element : this, stateName : 'initial' }, function( e ) {
				e.data.element.changeFrame( ( ( e.data.element.isSelected ) ? e.data.element.selectedState : e.data.stateName ) );
			} ),
			this.$node().bind( 'mousedown', { element : this, stateName : '_down' }, function( e ) {
				e.data.element.changeFrame( e.data.stateName );
			} ),
			this.$node().bind( 'mouseup', { element : this, stateName : '_over' }, function( e ) {
				e.data.element.changeFrame( e.data.stateName );
			} );
		},
		fields : {
			isSelected : false,
			selectedState : '_selected'
		},
		methods : {
			selected : function( set ) {
				this.isSelected = set;
				var state = ( set ) ? "_selected" : "initial";
				this.changeFrame( state );
			}
		}
	} );
	
} )(jQuery,this);
