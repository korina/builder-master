/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Dropdown class
	 * Provides for the select HTML tag
	 **/
	$class.create( {
		namespace : 'dropdown',
		inherits : types.input,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			var i = $descriptor.initial;
			if ( !i.attr ) return;
			var a = i.attr;
			if ( a.formName )
				this.$node().attr( 'formName', a.formName );
			for ( i in a.labels ) {
				var elText = a.labels[i];
				this.addItem( elText, a.values[i] )
			}
		},
		fields : {
			markup : '<select />'
		},
		methods : {
			addItem : function( $label, $url ) {
				this.addChild( this.$node(), 'option', $label, $url );
			},
			removeItem : function( $label ) {
				var c = this.$node().children();
				var url;
				for ( var i = 0; i < c.length; i++ )
					if ( $(c[i]).html() == $label ) {
						url = $(c[i]).val();
						$(c[i]).remove();
					}
				return url;
			},
			removeAll : function() {
				this.$node().empty();
			},
			index : function( $i ) {
				if ( !isNaN( $i ) )
					this.$node().selectedIndex = $i;
				return this.$node().selectedIndex;
			},
			value : function( $v ) {
				if ( !!$v )
					this.$node().val( $v );
				return this.$node().val();
			},
			text : function( $t ) {
				if ( !!$t )
					this.$node().find('option:contains(' + $t + ')').attr('selected', 'selected');
				return this.$node().text();
			}
		}
	} );
	
} )(jQuery,this);