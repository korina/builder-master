/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Checkbox class
	 * Provides for the input checkbox HTML tag
	 **/
	$class.create( {
		namespace : 'checkbox',
		inherits : types.input,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			var i = $descriptor.initial;
			this.$node().attr( 'type', 'checkbox' );
			if ( !i.attr ) return;
			var a = i.attr;
			if ( a.formName )
				this.$node().attr( 'formName', a.formName );
			if ( a.checked )
				this.$node().attr( 'checked', 'checked' );
		},
		methods : {
			checked : function() {
				return this.$node().is(':checked');
			}
		}
	} );
	
} )(jQuery,this);