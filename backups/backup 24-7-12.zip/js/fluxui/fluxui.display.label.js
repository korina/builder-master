/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Label class (Given that 'label' is a HTML element, should we change this class' name?)
	 **/
	$class.create( {
		namespace : 'label',
		inherits : types.element,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			this.entity( 'label' );
		},
		props : {
			'overflow' : 'hidden',
			'font-family' : 'arial',
			'font-size' : 12
		},
		methods : {
			text : function( $t ) {
				if ( !!$t ) {
					if ( !!arguments[1] )
						this.states.setAttributeOnCurrentState( 'text', $t );
					this.$node().html( $t );
				}
				return this.$node().html();
			},
			
			attribute : function( attr, value, updateState ) {
				if ( !!value ) {
					if ( !!updateState ) this.states.setAttributeOnCurrentState( attr, value );
					if ( attr == 'text' )
						this.text( value );
					else
						this.$node().attr( attr, value );
				}
				return this.$node().attr( attr );
			},
			
			styleHyjack : function( type, prop, updateState ) {
				return ( type == 'fill' || type.substr( 0, 7 ) == 'border-' ) ? 0 : false;
			}
		}
	} );
	
} )(jQuery,this);