/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Text class
	 * Provides for the input text and password HTML tags. If the 'text' field is not 'password' then its text input
	 **/
	$class.create( {
		namespace : 'textfield',
		inherits : types.input,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			var i = $descriptor.initial;
			if ( !i.attr ) return;
			var a = i.attr;
			if ( !!a.formName )
				this.$node().attr( 'formName', a.formName );
			if ( a.text === "password" ) {
				this.$node().attr( 'type', 'password' );
			} else {
				this.$node().attr( 'type', 'text' );
				if ( !!a.text )
					this.text( a.text );
			}
		},
		fields : {
			markup : '<input />'
		},
		methods : {
			text : function( $t ) {
				if ( !!$t || $t == '' )
					this.$node().val( types.core.htmlEncode( $t ) );
				return this.$node().val();
			}
		}
	} );
	
} )(jQuery,this);