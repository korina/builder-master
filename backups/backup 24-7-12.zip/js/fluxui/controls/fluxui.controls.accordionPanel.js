/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	$class.create( {
		namespace : 'accordionPanel',
		inherits : types.element,
		constructor : function( $id, $data ) {
			this.Super( $id, $data );
			this.style( 'position', 'relative' );
			var attr = $data.initial.attr;
			this.text = attr.text;
			if ( !!assets[attr.icon] )
				this.icon = attr.icon;
		},
		fields : {
			props : {
				position: 'relative'
			},
			text : '',
			icon : ''
		}
	} );
	
} )(jQuery,this);