/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;

	/**
	 * Menu class. Provides the menu interface for the editor
	 * 
	 * Requires:
	 *		fluxui.display.element.js
	 **/
	$class.create( {
		namespace : 'menu',
		inherits : types.element,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
			this.entity( 'menu' );
		},
		methods : {
			initialise : function() {
				var m = this;
				$.post( "data/?action=loggedIn", {}, function( data ) {
					if ( data == '1' )
						m.showOptions();
				} );
			},
			showOptions : function() {
				this.getChildById( 'login-menu' ).visible( false );
				this.getChildById( 'app-menu' ).visible( true );
			}
		}
	} );
	
} )(jQuery,this);