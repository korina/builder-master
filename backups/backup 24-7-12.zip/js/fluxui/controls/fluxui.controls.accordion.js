/**
 * @author Lee Sylvester
 * @contributor Ed Rogers
 * @copyright Influxis
 **/
( function( $ ) {

	var types = $.fn.fluxui.types;
	var fdata = $.fn.fluxui.fdata;
	var assets = $.fn.fluxui.assets;
	var $class = $.fn.fluxui.$class;
	
	$class.create( {
		namespace : 'accordion',
		inherits : types.element,
		constructor : function( $id, $descriptor ) {
			this.Super( $id, $descriptor );
		},
		methods: {
			initialise: function() {
				var i = this.initial;
				if ( !!this.data.hash.button ) {
					var c = this.$node().children();
					for ( var i = 0; i < c.length; i++ ) {
						var inst = types.element.getInstance( c[i] );
						var l = types.serialiser.parse( inst.fluxid() + '-btn', this.data.hash.button );
						l.style( 'position', 'relative' );
						var p = $(c[i]).wrap( '<div></div>' ).parent();
						p.prepend( l.node );
						l.style( 'width', this.width );
						if ( inst.text != '' ) {
							var child = l.getChildById( 'label' );
							child.states.setAttributeOnAllStates( 'text', inst.text );
							child.text( inst.text );
						}
						if ( inst.icon != '' ) {
							child = l.getChildById( 'icon' );
							child.states.setAttributeOnAllStates( 'src', inst.icon );
							child.attribute( 'src', inst.icon );
						}
						$(c[i]).hide();
						if ( !!l.initialise )
							l.initialise( this.data.hash.button );
						var acc = this;
						l.$node().bind( 'click', function( evt ) {
							acc.handleClick( evt.currentTarget );
						} );
					}
				}
			},
			handleClick: function( $btn ) {
				var panel = $($btn).next()[0];
				this.$node().find( "div[entity='accordionPanel']" ).each( function() {
					if ( this == panel ) {
						types.element.getInstance( $btn ).selected( !$(this).is(':visible') );
						$(this).toggle( 'fast' );
					}
				} );
			},
			entity : function() {
				return 'accordion';
			},
			getChildren : function( $selector ) {
				if ( !$selector ) $selector = '[entity=accordionPanel]';
				var t, r = [], c = this.$node().find( $selector );
				if ( c.length > 0 )
					for ( var i = 0; i < c.length; i++ ) {
						t = types.element.getInstance( c[i] );
						if ( !!t )
							r.push( t );
					}
				return r;
			}
		}
	} );
	
} )(jQuery,this);